describe('Purpose Form', () => {
  beforeEach(() => {
    cy.visit('/#purpose-ai');
  });

  it('should submit purpose form successfully', () => {
    cy.get('input[type="date"]').type('1990-01-01');
    cy.get('input[type="time"]').type('12:00');
    cy.get('input[placeholder="Birth Location"]').type('New York, USA');
    
    cy.get('textarea').first().type('Technology, Art, Music');
    cy.get('textarea').last().type('Creating, Teaching, Learning');
    
    cy.get('button').contains(/Generate Purpose Map/i).click();
    
    cy.get('.purpose-map').should('be.visible');
  });

  it('should show validation errors for empty fields', () => {
    cy.get('button').contains(/Generate Purpose Map/i).click();
    cy.get('[data-testid="form-error"]').should('be.visible');
  });
});