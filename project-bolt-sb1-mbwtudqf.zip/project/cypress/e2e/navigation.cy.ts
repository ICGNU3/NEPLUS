describe('Navigation', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('should navigate to all sections', () => {
    cy.get('nav').should('be.visible');
    
    // Test each navigation item
    const sections = ['vision', 'purpose', 'token', 'roadmap', 'get-involved'];
    
    sections.forEach(section => {
      cy.get(`a[href*="${section}"]`).first().click();
      cy.get(`#${section}`).should('be.visible');
    });
  });

  it('should show mobile menu on small screens', () => {
    cy.viewport('iphone-x');
    cy.get('button[aria-label="Toggle menu"]').should('be.visible').click();
    cy.get('nav').should('be.visible');
  });
});