export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      newsletter_subscribers: {
        Row: {
          id: string
          email: string
          subscribed_at: string
          status: string
        }
        Insert: {
          id?: string
          email: string
          subscribed_at?: string
          status?: string
        }
        Update: {
          status?: string
        }
      }
    }
  }
}