export const SUPABASE_CONFIG = {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    storageKey: 'neplus-auth-token'
  },
  realtime: {
    enabled: false
  }
} as const;