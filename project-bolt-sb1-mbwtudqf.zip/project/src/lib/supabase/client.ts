import { createClient } from '@supabase/supabase-js';
import type { Database } from '../database.types';

// Development fallback values
const FALLBACK_URL = 'http://localhost:54321';
const FALLBACK_ANON_KEY = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJzdXBhYmFzZSIsImlhdCI6MTYwMzQ2ODAwMCwiZXhwIjoyNTUwNDY4MDAwLCJhdWQiOiIiLCJzdWIiOiIiLCJyb2xlIjoiYW5vbiJ9.ZopqoUt0d8iZFhBpUZiP0CTWYa9EqG7ZHhRKODCrZTE';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || FALLBACK_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || FALLBACK_ANON_KEY;

if (process.env.NODE_ENV === 'production' && (!supabaseUrl || !supabaseAnonKey)) {
  throw new Error('Missing Supabase environment variables');
}

if (process.env.NODE_ENV === 'development' && (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY)) {
  console.warn(`
⚠️ Supabase environment variables not found. Using development fallbacks.
   Please create a .env file with the following variables:
   
   VITE_SUPABASE_URL=your-project-url
   VITE_SUPABASE_ANON_KEY=your-anon-key
   
   You can find these values in your Supabase project settings.
  `);
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true
  }
});