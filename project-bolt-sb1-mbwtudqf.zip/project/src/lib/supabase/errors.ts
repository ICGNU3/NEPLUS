export class SupabaseError extends Error {
  constructor(
    message: string,
    public code?: string,
    public details?: unknown
  ) {
    super(message);
    this.name = 'SupabaseError';
  }
}

export const handleSupabaseError = (error: unknown): SupabaseError => {
  if (error instanceof SupabaseError) return error;

  const message = error instanceof Error ? error.message : 'An unknown error occurred';
  return new SupabaseError(message);
};