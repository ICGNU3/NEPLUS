import OpenAI from 'openai';

if (!import.meta.env.VITE_OPENAI_API_KEY) {
  console.warn('OpenAI API key not found. AI features will be disabled.');
}

export const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true // Note: In production, API calls should go through your backend
});