import { supabase } from '../lib/supabase/client';
import { handleSupabaseError } from '../lib/supabase/errors';
import type { NewsletterResponse } from '../types/newsletter';

export const subscribeToNewsletter = async (email: string): Promise<NewsletterResponse> => {
  try {
    const { error } = await supabase
      .from('newsletter_subscribers')
      .insert([{ email }]);

    if (error) throw error;
    
    return { 
      success: true, 
      data: { message: 'Neural link established successfully' } 
    };
  } catch (error) {
    const supabaseError = handleSupabaseError(error);
    console.error('Newsletter subscription error:', supabaseError);
    
    return { 
      success: false, 
      error: 'Failed to establish neural link. Please try again.' 
    };
  }
};

export const unsubscribeFromNewsletter = async (email: string): Promise<NewsletterResponse> => {
  try {
    const { error } = await supabase
      .from('newsletter_subscribers')
      .update({ status: 'unsubscribed' })
      .eq('email', email);

    if (error) throw error;

    return {
      success: true,
      data: { message: 'Neural link terminated successfully' }
    };
  } catch (error) {
    const supabaseError = handleSupabaseError(error);
    console.error('Newsletter unsubscribe error:', supabaseError);

    return {
      success: false,
      error: 'Failed to terminate neural link. Please try again.'
    };
  }
};