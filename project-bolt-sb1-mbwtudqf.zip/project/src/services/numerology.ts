import { BirthData } from '../types/purpose';

export const calculateLifePath = (birthDate: string): number => {
  const numbers = birthDate.replace(/\D/g, '').split('').map(Number);
  const sum = numbers.reduce((acc, curr) => acc + curr, 0);
  return sum > 9 ? calculateLifePath(sum.toString()) : sum;
};

export const getNumerologyInsights = (birthData: BirthData) => {
  const lifePath = calculateLifePath(birthData.date);
  // Add numerology logic here
  return {
    system: 'numerology' as const,
    category: 'Life Path',
    insight: `Your life path number ${lifePath} indicates...`,
    suggestion: 'Consider exploring opportunities in...'
  };
};