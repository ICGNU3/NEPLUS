import { openai } from '../../lib/openai';
import type { Protocol } from '../../types/protocols';

export const generateProtocol = async (
  difficulty: 'basic' | 'intermediate' | 'advanced',
  userProgress: any
): Promise<Protocol | null> => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: "You are an advanced AI system that generates training protocols for a cyberpunk-themed reality manipulation system."
        },
        {
          role: "user",
          content: `Generate a ${difficulty} level protocol. Consider user progress: ${JSON.stringify(userProgress)}`
        }
      ],
      temperature: 0.7,
    });

    const generatedContent = response.choices[0]?.message?.content;
    if (!generatedContent) return null;

    // Parse the generated content into a protocol
    const protocol = JSON.parse(generatedContent) as Protocol;
    return protocol;
  } catch (error) {
    console.error('Error generating protocol:', error);
    return null;
  }
};