import axios from 'axios';
import { sanitizeTickerData, filterActiveTokens } from '../../utils/ticker';
import type { TickerData, TickerError } from '../../types/ticker';

const API_URL = 'https://api.coingecko.com/api/v3';

export const fetchTickerData = async (): Promise<{ data: TickerData[]; error: TickerError | null; }> => {
  try {
    const response = await axios.get(`${API_URL}/coins/markets`, {
      params: {
        vs_currency: 'usd',
        category: 'meme-token',
        order: 'volume_desc',
        per_page: 100,
        sparkline: false
      }
    });

    if (!Array.isArray(response.data)) {
      throw new Error('Invalid response format');
    }

    const sanitizedData = response.data.map(sanitizeTickerData);
    const filteredData = filterActiveTokens(sanitizedData);

    return {
      data: filteredData,
      error: null
    };
  } catch (err) {
    const error: TickerError = {
      message: err instanceof Error ? err.message : 'Failed to fetch ticker data',
      code: 'TICKER_FETCH_ERROR'
    };
    return { data: [], error };
  }
};