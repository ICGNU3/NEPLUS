import axios from 'axios';
import type { Memecoin } from '../../types/memecoin';

const BASE_URL = 'https://api.coingecko.com/api/v3';

export const getVerifiedMemecoins = async (): Promise<Memecoin[]> => {
  try {
    const response = await axios.get(`${BASE_URL}/coins/markets`, {
      params: {
        vs_currency: 'usd',
        category: 'meme-token',
        order: 'volume_desc',
        per_page: 100,
        sparkline: false
      }
    });

    // Ensure we only return serializable data
    return response.data
      .filter((coin: any) => 
        coin.market_cap > 1000000 && 
        coin.total_volume > 100000
      )
      .map((coin: any): Memecoin => ({
        id: String(coin.id),
        symbol: String(coin.symbol),
        name: String(coin.name),
        current_price: Number(coin.current_price),
        price_change_percentage_24h: Number(coin.price_change_percentage_24h),
        market_cap: Number(coin.market_cap),
        total_volume: Number(coin.total_volume)
      }));
  } catch (error) {
    console.error('Failed to fetch memecoins:', error);
    return [];
  }
};