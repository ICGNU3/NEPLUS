import React from 'react';
import { Layout } from '../components/Layout';
import { Background } from '../components/Background/Background';
import { AdvancedProtocolsContent } from '../components/AdvancedProtocols/AdvancedProtocolsContent';

const AdvancedProtocols = () => {
  return (
    <Layout>
      <Background />
      <main className="relative min-h-screen pt-24 px-6">
        <div className="max-w-6xl mx-auto">
          <AdvancedProtocolsContent />
        </div>
      </main>
    </Layout>
  );
};

export default AdvancedProtocols;