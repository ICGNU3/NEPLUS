import React from 'react';
import { Layout } from '../components/Layout';
import { Background } from '../components/Background/Background';
import { SubscribeModal } from '../components/common/modals/SubscribeModal';
import Hero from '../components/Hero';
import VisionSection from '../components/Vision/VisionSection';
import RoadmapSection from '../components/Roadmap/RoadmapSection';
import GetInvolvedSection from '../components/GetInvolved/GetInvolvedSection';

const Home = () => {
  return (
    <Layout>
      <Background />
      <main className="relative">
        <section id="hero">
          <Hero />
        </section>
        <section id="vision">
          <VisionSection />
        </section>
        <section id="roadmap">
          <RoadmapSection />
        </section>
        <section id="get-involved">
          <GetInvolvedSection />
        </section>
      </main>
      <SubscribeModal />
    </Layout>
  );
};

export default Home;