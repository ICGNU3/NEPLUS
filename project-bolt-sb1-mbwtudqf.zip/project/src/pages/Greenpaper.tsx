import React from 'react';
import { Layout } from '../components/Layout';
import { GreenpaperHero } from '../components/Greenpaper/GreenpaperHero';
import { GreenpaperContent } from '../components/Greenpaper/GreenpaperContent';
import { Background } from '../components/Background/Background';

const Greenpaper = () => {
  return (
    <Layout>
      <Background />
      <main className="relative">
        <GreenpaperHero />
        <GreenpaperContent />
      </main>
    </Layout>
  );
};

export default Greenpaper;