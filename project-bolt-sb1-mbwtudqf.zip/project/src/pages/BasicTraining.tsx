import React from 'react';
import { Layout } from '../components/Layout';
import { Background } from '../components/Background/Background';
import { TrainingInterface } from '../components/Training/TrainingInterface';

const BasicTraining = () => {
  return (
    <Layout>
      <Background />
      <main className="relative min-h-screen pt-24 px-6">
        <TrainingInterface />
      </main>
    </Layout>
  );
};

export default BasicTraining;