import React from 'react';
import { Layout } from '../components/Layout';
import { Background } from '../components/Background/Background';
import { CommandInterface } from '../components/CommandCenter/CommandInterface';

const CommandCenter = () => {
  return (
    <Layout>
      <Background />
      <main className="relative min-h-screen pt-24 px-6">
        <CommandInterface />
      </main>
    </Layout>
  );
};

export default CommandCenter;