import { Analytics } from '../analytics/core';
import { GlobalErrorHandler, PromiseErrorHandler } from './handlers';

interface ErrorDetails {
  message: string;
  stack?: string;
  context?: Record<string, unknown>;
}

class ErrorLogger {
  private static instance: ErrorLogger;
  
  private constructor() {
    this.initializeGlobalHandlers();
  }

  static getInstance(): ErrorLogger {
    if (!ErrorLogger.instance) {
      ErrorLogger.instance = new ErrorLogger();
    }
    return ErrorLogger.instance;
  }

  private initializeGlobalHandlers() {
    GlobalErrorHandler.initialize();
    PromiseErrorHandler.initialize();
  }

  logError(error: ErrorDetails) {
    console.error('Error:', error.message, error.context);
    Analytics.event('Error', error.message, JSON.stringify(error.context));
  }

  logWarning(message: string, context?: Record<string, unknown>) {
    console.warn('Warning:', message, context);
    Analytics.event('Warning', message, JSON.stringify(context));
  }
}

export const errorLogger = ErrorLogger.getInstance();