import { errorLogger } from '../ErrorLogger';

export class GlobalErrorHandler {
  static initialize() {
    window.onerror = (message, source, lineno, colno, error) => {
      errorLogger.logError({
        message: String(message),
        stack: error?.stack,
        context: { source, lineno, colno }
      });
    };
  }
}