import { errorLogger } from '../ErrorLogger';

export class PromiseErrorHandler {
  static initialize() {
    window.addEventListener('unhandledrejection', (event) => {
      errorLogger.logError({
        message: 'Unhandled Promise Rejection',
        stack: event.reason?.stack,
        context: { reason: event.reason }
      });
    });
  }
}