import React from 'react';
import { motion } from 'framer-motion';

interface Props {
  error: Error | null;
}

export const ErrorFallback = ({ error }: Props) => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    className="min-h-screen flex items-center justify-center bg-matrix-black p-4"
  >
    <div className="text-center space-y-4">
      <h2 className="text-2xl font-bold text-matrix-primary">System Malfunction</h2>
      <p className="text-matrix-primary/80 max-w-md mx-auto">
        A critical error has been detected. The system is attempting to recover.
      </p>
      <button
        onClick={() => window.location.reload()}
        className="px-6 py-3 bg-matrix-dark border border-matrix-primary 
                 hover:bg-matrix-primary/20 rounded-lg font-mono"
      >
        Reinitialize System
      </button>
    </div>
  </motion.div>
);