export const validateEmail = (email: string): boolean => {
  const pattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return pattern.test(email);
};

export const validateInput = (input: string, maxLength = 100): string => {
  return input.slice(0, maxLength).trim();
};