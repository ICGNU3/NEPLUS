export const createRateLimiter = (limit: number, windowMs: number) => {
  const requests = new Map<string, number[]>();

  return (ip: string): boolean => {
    const now = Date.now();
    const windowStart = now - windowMs;
    
    const userRequests = requests.get(ip) || [];
    const recentRequests = userRequests.filter(time => time > windowStart);
    
    if (recentRequests.length >= limit) return false;
    
    recentRequests.push(now);
    requests.set(ip, recentRequests);
    return true;
  };
};