const ALLOWED_TAGS = ['b', 'i', 'em', 'strong'];

export const sanitizeHTML = (html: string): string => {
  const div = document.createElement('div');
  div.innerHTML = html;

  const walk = document.createTreeWalker(
    div,
    NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT
  );

  let node;
  while (node = walk.nextNode()) {
    if (node.nodeType === Node.ELEMENT_NODE) {
      const element = node as Element;
      if (!ALLOWED_TAGS.includes(element.tagName.toLowerCase())) {
        element.replaceWith(document.createTextNode(element.textContent || ''));
      }
    }
  }

  return div.innerHTML;
};