import { PurposeMap } from '../types/purpose';

// Simple analytics implementation
export const Analytics = {
  pageView: (path: string) => {
    if (typeof window !== 'undefined') {
      // Send to your analytics service
      console.log('Page View:', path);
    }
  },

  event: (category: string, action: string, label?: string) => {
    if (typeof window !== 'undefined') {
      // Send to your analytics service
      console.log('Event:', { category, action, label });
    }
  },

  purposeMapGenerated: (purposeMap: PurposeMap) => {
    Analytics.event('PurposeAI', 'MapGenerated', JSON.stringify(purposeMap));
  }
};