export const Performance = {
  mark: (name: string) => {
    if (typeof performance !== 'undefined') {
      performance.mark(name);
    }
  },

  measure: (name: string, startMark: string, endMark: string) => {
    if (typeof performance !== 'undefined') {
      try {
        performance.measure(name, startMark, endMark);
        const measure = performance.getEntriesByName(name).pop();
        if (measure) {
          console.log(`${name}:`, measure.duration.toFixed(2), 'ms');
        }
      } catch (e) {
        console.error('Performance measurement error:', e);
      }
    }
  }
};