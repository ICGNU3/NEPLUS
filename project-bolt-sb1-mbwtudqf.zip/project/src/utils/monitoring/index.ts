import { errorLogger } from '../error/ErrorLogger';
import { performanceMonitor } from './PerformanceMonitor';

export const initializeMonitoring = () => {
  try {
    // Initialize error logging
    errorLogger;
    
    // Initialize performance monitoring
    performanceMonitor;
    
    // Measure page load performance
    window.addEventListener('load', () => {
      performanceMonitor.measurePageLoad();
    });
  } catch (error) {
    console.warn('Monitoring initialization failed:', error);
  }
};