export { LCPMonitor } from './LCPMonitor';
export { FIDMonitor } from './FIDMonitor';
export { PageLoadMonitor } from './PageLoadMonitor';