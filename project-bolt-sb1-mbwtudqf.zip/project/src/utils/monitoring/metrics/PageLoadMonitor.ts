import { Analytics } from '../../analytics/core';

export class PageLoadMonitor {
  static measure() {
    if (!window.performance) return;

    try {
      const timing = performance.timing;
      const loadTime = timing.loadEventEnd - timing.navigationStart;
      Analytics.timing('Performance', 'PageLoad', loadTime);
    } catch (e) {
      console.warn('Page load monitoring failed:', e);
    }
  }
}