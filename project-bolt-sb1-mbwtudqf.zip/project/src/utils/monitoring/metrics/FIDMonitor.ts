import { Analytics } from '../../analytics/core';

export class FIDMonitor {
  static initialize() {
    if (!('PerformanceObserver' in window)) return;

    try {
      const observer = new PerformanceObserver((list) => {
        list.getEntries().forEach((entry) => {
          Analytics.timing('Performance', 'FID', entry.duration);
        });
      });
      
      observer.observe({ entryTypes: ['first-input'] });
    } catch (e) {
      console.warn('FID monitoring failed:', e);
    }
  }
}