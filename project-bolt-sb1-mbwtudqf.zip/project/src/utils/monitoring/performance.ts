export const Performance = {
  measure: (name: string, startMark: string, endMark: string) => {
    try {
      performance.measure(name, startMark, endMark);
      const entries = performance.getEntriesByName(name);
      const duration = entries[entries.length - 1]?.duration || 0;
      
      if (duration > 1000) {
        console.warn(`Performance warning: ${name} took ${duration}ms`);
      }
    } catch (error) {
      console.error('Performance measurement error:', error);
    }
  },

  track: (callback: () => void, name: string) => {
    const start = performance.now();
    callback();
    const duration = performance.now() - start;
    
    Analytics.timing('performance', name, duration);
  }
};