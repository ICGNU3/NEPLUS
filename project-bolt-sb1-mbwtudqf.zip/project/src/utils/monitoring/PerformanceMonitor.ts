import { LCPMonitor, FIDMonitor, PageLoadMonitor } from './metrics';

export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  
  private constructor() {
    this.initializeObservers();
  }

  static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  private initializeObservers() {
    LCPMonitor.initialize();
    FIDMonitor.initialize();
  }

  measurePageLoad() {
    PageLoadMonitor.measure();
  }
}

export const performanceMonitor = PerformanceMonitor.getInstance();