import type { TickerData } from '../types/ticker';

export const sanitizeTickerData = (rawData: any): TickerData => ({
  id: String(rawData.id || ''),
  symbol: String(rawData.symbol || '').toUpperCase(),
  name: String(rawData.name || ''),
  price: Number(rawData.current_price) || 0,
  priceChange: Number(rawData.price_change_percentage_24h) || 0,
  volume: Number(rawData.total_volume) || 0,
  marketCap: Number(rawData.market_cap) || 0
});

export const filterActiveTokens = (data: TickerData[]): TickerData[] => {
  return data
    .filter(token => 
      token.marketCap > 1000000 && 
      token.volume > 100000
    )
    .sort((a, b) => b.volume - a.volume)
    .slice(0, 15);
};