import { TRANSITIONS } from '../constants/common';

export const withTransition = (animation: object, speed: keyof typeof TRANSITIONS = 'DEFAULT') => ({
  ...animation,
  transition: TRANSITIONS[speed]
});

export const combineAnimations = (...animations: object[]) => 
  animations.reduce((combined, animation) => ({ ...combined, ...animation }), {});

export const createVariants = (variants: Record<string, object>) =>
  Object.entries(variants).reduce((acc, [key, value]) => ({
    ...acc,
    [key]: withTransition(value)
  }), {});