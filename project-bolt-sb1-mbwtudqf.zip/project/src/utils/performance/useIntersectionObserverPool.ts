import { useRef, useEffect } from 'react';

export const useIntersectionObserverPool = () => {
  const observerPool = useRef<Map<string, IntersectionObserver>>(new Map());

  const observe = (
    element: Element,
    callback: IntersectionObserverCallback,
    options: IntersectionObserverInit = {}
  ) => {
    const key = JSON.stringify(options);
    
    if (!observerPool.current.has(key)) {
      observerPool.current.set(key, new IntersectionObserver(callback, options));
    }
    
    const observer = observerPool.current.get(key)!;
    observer.observe(element);
    
    return () => {
      observer.unobserve(element);
      if (!observer.takeRecords().length) {
        observer.disconnect();
        observerPool.current.delete(key);
      }
    };
  };

  useEffect(() => {
    return () => {
      observerPool.current.forEach(observer => observer.disconnect());
      observerPool.current.clear();
    };
  }, []);

  return { observe };
};