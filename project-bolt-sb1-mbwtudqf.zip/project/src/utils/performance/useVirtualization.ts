import { useState, useEffect, useCallback } from 'react';
import { debounce } from './debounce';

interface VirtualizationConfig {
  itemHeight: number;
  overscan?: number;
  threshold?: number;
}

export const useVirtualization = <T>(
  items: T[],
  { itemHeight, overscan = 3, threshold = 100 }: VirtualizationConfig
) => {
  const [visibleItems, setVisibleItems] = useState<T[]>([]);
  const [scrollTop, setScrollTop] = useState(0);

  const updateVisibleItems = useCallback(
    debounce((scrollPosition: number) => {
      const start = Math.max(0, Math.floor(scrollPosition / itemHeight) - overscan);
      const end = Math.min(
        items.length,
        Math.ceil((scrollPosition + window.innerHeight) / itemHeight) + overscan
      );
      setVisibleItems(items.slice(start, end));
    }, threshold),
    [items, itemHeight, overscan]
  );

  useEffect(() => {
    const handleScroll = () => {
      const newScrollTop = window.scrollY;
      setScrollTop(newScrollTop);
      updateVisibleItems(newScrollTop);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [updateVisibleItems]);

  return {
    visibleItems,
    scrollTop,
    totalHeight: items.length * itemHeight
  };
};