interface ErrorDetails {
  message: string;
  stack?: string;
  context?: Record<string, unknown>;
}

export const ErrorTracking = {
  init: () => {
    window.onerror = (message, source, lineno, colno, error) => {
      ErrorTracking.captureError({
        message: String(message),
        stack: error?.stack,
        context: { source, lineno, colno }
      });
    };
  },

  captureError: (error: ErrorDetails) => {
    // Send to your error tracking service
    console.error('Error captured:', error);
  }
};