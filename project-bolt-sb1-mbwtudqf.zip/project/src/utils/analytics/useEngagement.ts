import { useEffect } from 'react';
import { throttle } from '../performance/throttle';

export const useEngagement = () => {
  useEffect(() => {
    let startTime = Date.now();
    let scrollDepth = 0;
    let interactions = 0;

    const trackScroll = throttle(() => {
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrolled = window.scrollY;
      scrollDepth = Math.max(scrollDepth, (scrolled / docHeight) * 100);
    }, 100);

    const trackInteraction = throttle(() => {
      interactions++;
    }, 100);

    window.addEventListener('scroll', trackScroll);
    window.addEventListener('click', trackInteraction);
    window.addEventListener('keypress', trackInteraction);

    return () => {
      const duration = (Date.now() - startTime) / 1000;
      
      // Send engagement data
      console.info('Engagement Metrics:', {
        duration,
        scrollDepth: Math.round(scrollDepth),
        interactions
      });

      window.removeEventListener('scroll', trackScroll);
      window.removeEventListener('click', trackInteraction);
      window.removeEventListener('keypress', trackInteraction);
    };
  }, []);
};