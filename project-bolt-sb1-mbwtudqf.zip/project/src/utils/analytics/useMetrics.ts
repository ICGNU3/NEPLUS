import { useEffect } from 'react';
import { Performance } from '../performance';

interface MetricConfig {
  name: string;
  threshold?: number;
}

export const useMetrics = ({ name, threshold = 3000 }: MetricConfig) => {
  useEffect(() => {
    const start = performance.now();
    Performance.mark(`${name}-start`);

    return () => {
      const end = performance.now();
      const duration = end - start;
      
      Performance.mark(`${name}-end`);
      Performance.measure(name, `${name}-start`, `${name}-end`);

      if (duration > threshold) {
        console.warn(`[Performance] ${name} took ${duration.toFixed(2)}ms`);
      }
    };
  }, [name, threshold]);
};