export const Analytics = {
  pageView: (path: string) => {
    try {
      // Send to analytics service
      console.info('Page View:', path);
    } catch (error) {
      console.error('Analytics Error:', error);
    }
  },

  event: (category: string, action: string, label?: string) => {
    try {
      // Send to analytics service
      console.info('Event:', { category, action, label });
    } catch (error) {
      console.error('Analytics Error:', error);
    }
  },

  timing: (category: string, variable: string, time: number) => {
    try {
      // Send to analytics service
      console.info('Timing:', { category, variable, time });
    } catch (error) {
      console.error('Analytics Error:', error);
    }
  }
};