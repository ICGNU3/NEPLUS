import { create } from 'zustand';
import type { NewsletterStore } from '../types/newsletter';
import { subscribeToNewsletter } from '../services/api/newsletter';

export const useNewsletterStore = create<NewsletterStore>((set) => ({
  isOpen: false,
  loading: false,
  error: null,
  success: false,
  showSubscribeModal: () => set({ isOpen: true }),
  hideSubscribeModal: () => set({ isOpen: false, error: null }),
  subscribe: async (email: string) => {
    try {
      set({ loading: true, error: null });
      const result = await subscribeToNewsletter(email);
      
      if (!result.success) {
        set({ error: result.error, loading: false });
        return false;
      }
      
      set({ success: true, loading: false });
      return true;
    } catch (err) {
      set({ 
        error: 'Neural link initialization failed. Please try again.',
        loading: false 
      });
      return false;
    }
  }
}));