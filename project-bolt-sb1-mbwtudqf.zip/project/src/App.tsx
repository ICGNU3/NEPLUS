import React, { Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
import { MatrixLoader } from './components/common/MatrixLoader';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { AuthProvider } from './contexts/AuthContext';

// Lazy load pages
const Home = React.lazy(() => import('./pages/Home'));
const Greenpaper = React.lazy(() => import('./pages/Greenpaper'));
const CommandCenter = React.lazy(() => import('./pages/CommandCenter'));
const BasicTraining = React.lazy(() => import('./pages/BasicTraining'));
const AdvancedProtocols = React.lazy(() => import('./pages/AdvancedProtocols'));

function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Suspense fallback={<MatrixLoader />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/greenpaper" element={<Greenpaper />} />
            <Route path="/command-center" element={<CommandCenter />} />
            <Route path="/basic-training" element={<BasicTraining />} />
            <Route path="/advanced-protocols" element={<AdvancedProtocols />} />
          </Routes>
        </Suspense>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;