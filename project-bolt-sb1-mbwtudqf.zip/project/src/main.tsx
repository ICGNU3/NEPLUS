import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { initializeMonitoring } from './utils/monitoring';
import './index.css';

// Initialize monitoring
initializeMonitoring();

// Add error boundary for development
if (process.env.NODE_ENV === 'development') {
  const rootElement = document.getElementById('root');
  if (!rootElement) {
    console.error('Failed to find root element');
    document.body.innerHTML = '<div style="color: red; padding: 20px;">Failed to find root element</div>';
  } else {
    const root = createRoot(rootElement);
    root.render(
      <React.StrictMode>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </React.StrictMode>
    );
  }
} else {
  // Production rendering
  const root = createRoot(document.getElementById('root')!);
  root.render(
    <React.StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </React.StrictMode>
  );
}