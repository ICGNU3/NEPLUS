import React from 'react';
import { motion } from 'framer-motion';
import { Lock, CheckCircle, ChevronRight } from 'lucide-react';
import type { TrainingModuleData } from './types';

interface Props extends TrainingModuleData {
  isLocked: boolean;
  isCompleted: boolean;
  onStart: () => void;
}

export const TrainingModule = ({ 
  title, 
  description, 
  objectives, 
  isLocked,
  isCompleted,
  onStart 
}: Props) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`
        bg-gray-900/50 backdrop-blur-sm border rounded-lg p-6
        ${isCompleted ? 'border-matrix-primary/50' : 'border-matrix-primary/30'}
      `}
    >
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center space-x-2 mb-2">
            <h2 className="text-xl font-bold text-matrix-primary">{title}</h2>
            {isCompleted && (
              <CheckCircle className="w-5 h-5 text-matrix-primary" />
            )}
          </div>
          <p className="text-matrix-primary/80 mb-4">{description}</p>
          
          <div className="space-y-2">
            {objectives.map((objective, index) => (
              <div key={index} className="flex items-center space-x-2">
                <CheckCircle className={`w-4 h-4 ${
                  isCompleted ? 'text-matrix-primary' : 'text-matrix-primary/40'
                }`} />
                <span className="text-matrix-primary/80 text-sm">{objective}</span>
              </div>
            ))}
          </div>
        </div>
        
        {isLocked ? (
          <Lock className="w-6 h-6 text-matrix-primary/40" />
        ) : (
          <motion.button
            whileHover={{ x: 5 }}
            onClick={onStart}
            className="flex items-center space-x-2 text-matrix-primary hover:text-matrix-light"
          >
            <span>{isCompleted ? 'Review' : 'Begin Training'}</span>
            <ChevronRight className="w-5 h-5" />
          </motion.button>
        )}
      </div>
    </motion.div>
  );
};