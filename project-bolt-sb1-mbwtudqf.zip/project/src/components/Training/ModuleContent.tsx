import React from 'react';
import { motion } from 'framer-motion';
import { Terminal, Zap } from 'lucide-react';
import { TrainingExercise } from './TrainingExercise';
import type { TrainingModuleData } from './types';

interface Props {
  module: TrainingModuleData;
  onComplete: () => void;
}

export const ModuleContent = ({ module, onComplete }: Props) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      <div className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Terminal className="w-6 h-6 text-matrix-primary" />
          <h3 className="text-xl font-bold text-matrix-primary">Training Protocol</h3>
        </div>
        
        <div className="prose prose-invert max-w-none">
          <p className="text-matrix-primary/80">{module.description}</p>
          
          <h4 className="text-matrix-primary">Objectives:</h4>
          <ul className="space-y-2">
            {module.objectives.map((objective, index) => (
              <li key={index} className="text-matrix-primary/80">{objective}</li>
            ))}
          </ul>
        </div>
      </div>

      <TrainingExercise module={module} onComplete={onComplete} />

      <div className="flex items-center justify-between p-4 bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg">
        <div className="flex items-center space-x-2">
          <Zap className="w-5 h-5 text-matrix-primary" />
          <span className="text-matrix-primary/80">Module Progress</span>
        </div>
        <div className="text-matrix-primary">In Progress</div>
      </div>
    </motion.div>
  );
};