export interface TrainingModuleData {
  id: string;
  title: string;
  description: string;
  objectives: string[];
  difficulty: 'basic' | 'intermediate' | 'advanced';
  exercises: Exercise[];
  requiredScore: number;
}

export interface Exercise {
  id: string;
  type: 'command' | 'puzzle' | 'simulation';
  question: string;
  hints: string[];
  solution: string;
  points: number;
}

export interface TrainingProgress {
  completedModules: string[];
  currentModule: string;
  scores: Record<string, number>;
  achievements: string[];
}

export interface ModuleStats {
  attempts: number;
  timeSpent: number;
  score: number;
  completedAt?: string;
}