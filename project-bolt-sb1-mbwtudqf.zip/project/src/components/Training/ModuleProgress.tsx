import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Award, BarChart2 } from 'lucide-react';
import type { ModuleStats } from './types';

interface Props {
  stats: ModuleStats;
}

export const ModuleProgress = ({ stats }: Props) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="grid grid-cols-3 gap-4"
    >
      <div className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-2">
          <Clock className="w-4 h-4 text-matrix-primary" />
          <span className="text-matrix-primary/80">Time</span>
        </div>
        <div className="text-xl font-bold text-matrix-primary">
          {formatTime(stats.timeSpent)}
        </div>
      </div>

      <div className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-2">
          <BarChart2 className="w-4 h-4 text-matrix-primary" />
          <span className="text-matrix-primary/80">Attempts</span>
        </div>
        <div className="text-xl font-bold text-matrix-primary">
          {stats.attempts}
        </div>
      </div>

      <div className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-2">
          <Award className="w-4 h-4 text-matrix-primary" />
          <span className="text-matrix-primary/80">Score</span>
        </div>
        <div className="text-xl font-bold text-matrix-primary">
          {stats.score}
        </div>
      </div>
    </motion.div>
  );
};