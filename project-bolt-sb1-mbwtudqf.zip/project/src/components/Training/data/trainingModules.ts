import type { TrainingModuleData } from '../types';

export const trainingModules: TrainingModuleData[] = [
  {
    id: 'basics',
    title: 'Matrix Fundamentals',
    description: 'Learn to perceive and interact with the base layer of reality.',
    difficulty: 'basic',
    objectives: [
      'Understand the matrix structure',
      'Develop basic perception skills',
      'Practice energy manipulation',
      'Master foundational protocols'
    ],
    exercises: [
      {
        id: 'basics-1',
        type: 'command',
        question: 'Initialize the matrix perception protocol by entering the correct command sequence.',
        hints: [
          'The command starts with "perceive"',
          'Include the module ID in your command'
        ],
        solution: 'perceive --matrix basics --init',
        points: 100
      },
      {
        id: 'basics-2',
        type: 'puzzle',
        question: 'Decode the following matrix pattern: [◆ ■ ▲ ◆ ■]. What comes next?',
        hints: [
          'Look for repeating patterns',
          'Consider the sequence of shapes'
        ],
        solution: '▲',
        points: 150
      }
    ],
    requiredScore: 200
  },
  {
    id: 'perception',
    title: 'Enhanced Perception',
    description: 'Expand your awareness beyond normal reality constraints.',
    difficulty: 'basic',
    objectives: [
      'See through matrix illusions',
      'Detect system vulnerabilities',
      'Read energy signatures',
      'Map reality distortions'
    ],
    exercises: [
      {
        id: 'perception-1',
        type: 'simulation',
        question: 'Identify the glitch in the following pattern: [1010▓1010]',
        hints: [
          'Focus on anomalies in the pattern',
          'Consider what breaks the sequence'
        ],
        solution: '▓',
        points: 200
      }
    ],
    requiredScore: 150
  },
  {
    id: 'manipulation',
    title: 'Reality Manipulation',
    description: 'Learn to bend and reshape the fabric of reality.',
    difficulty: 'intermediate',
    objectives: [
      'Basic reality alterations',
      'Energy field manipulation',
      'Local matrix modifications',
      'Stability maintenance'
    ],
    exercises: [
      {
        id: 'manipulation-1',
        type: 'command',
        question: 'Execute a basic reality modification command.',
        hints: [
          'Use the "modify" command',
          'Include target and parameter flags'
        ],
        solution: 'modify --reality local --param energy=1.21',
        points: 250
      }
    ],
    requiredScore: 300
  },
  {
    id: 'integration',
    title: 'System Integration',
    description: 'Connect directly with matrix systems and protocols.',
    difficulty: 'advanced',
    objectives: [
      'Neural interface basics',
      'System access protocols',
      'Data stream interpretation',
      'Matrix code execution'
    ],
    exercises: [
      {
        id: 'integration-1',
        type: 'simulation',
        question: 'Establish a neural connection with the matrix. Format: [frequency:amplitude]',
        hints: [
          'Frequency should be in Hz',
          'Amplitude ranges from 0-1'
        ],
        solution: '432:0.618',
        points: 300
      }
    ],
    requiredScore: 400
  }
];