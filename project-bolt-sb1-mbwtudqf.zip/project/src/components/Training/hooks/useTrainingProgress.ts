import { useState, useEffect } from 'react';
import { trainingModules } from '../data/trainingModules';
import type { TrainingProgress } from '../types';

export const useTrainingProgress = () => {
  const [progress, setProgress] = useState<TrainingProgress>(() => {
    const saved = localStorage.getItem('training-progress');
    return saved ? JSON.parse(saved) : {
      completedModules: [],
      currentModule: 'basics'
    };
  });

  useEffect(() => {
    localStorage.setItem('training-progress', JSON.stringify(progress));
  }, [progress]);

  const completeModule = (moduleId: string) => {
    setProgress(prev => ({
      completedModules: [...prev.completedModules, moduleId],
      currentModule: moduleId
    }));
  };

  const isModuleCompleted = (moduleId: string) => 
    progress.completedModules.includes(moduleId);

  const isModuleLocked = (moduleId: string, index: number) => 
    index > 0 && !isModuleCompleted(trainingModules[index - 1].id);

  return {
    progress,
    completeModule,
    isModuleCompleted,
    isModuleLocked
  };
};