import { useState, useEffect } from 'react';
import { ACHIEVEMENTS } from '../types/achievements';
import type { Achievement } from '../types/achievements';
import type { ModuleStats } from '../types';

export const useAchievements = () => {
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(() => {
    const saved = localStorage.getItem('training-achievements');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('training-achievements', JSON.stringify(unlockedAchievements));
  }, [unlockedAchievements]);

  const checkAchievements = (stats: ModuleStats, completedModules: string[]) => {
    const newAchievements: Achievement[] = [];

    // Check each achievement condition
    ACHIEVEMENTS.forEach(achievement => {
      if (!unlockedAchievements.includes(achievement.id)) {
        switch (achievement.id) {
          case 'first-step':
            if (completedModules.length > 0) {
              newAchievements.push(achievement);
            }
            break;
          case 'quick-learner':
            if (stats.timeSpent < 300) { // 5 minutes
              newAchievements.push(achievement);
            }
            break;
          case 'perfect-score':
            if (stats.attempts === 1) {
              newAchievements.push(achievement);
            }
            break;
          case 'master-hacker':
            if (completedModules.length >= 4) {
              newAchievements.push(achievement);
            }
            break;
        }
      }
    });

    if (newAchievements.length > 0) {
      setUnlockedAchievements(prev => [
        ...prev,
        ...newAchievements.map(a => a.id)
      ]);
      return newAchievements;
    }

    return [];
  };

  const getAchievement = (id: string) => 
    ACHIEVEMENTS.find(a => a.id === id);

  return {
    unlockedAchievements,
    checkAchievements,
    getAchievement
  };
};