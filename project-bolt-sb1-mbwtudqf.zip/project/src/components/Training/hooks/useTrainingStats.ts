import { useState, useEffect } from 'react';
import type { ModuleStats } from '../types';

export const useTrainingStats = (moduleId: string) => {
  const [stats, setStats] = useState<ModuleStats>(() => {
    const saved = localStorage.getItem(`training-stats-${moduleId}`);
    return saved ? JSON.parse(saved) : {
      attempts: 0,
      timeSpent: 0,
      score: 0
    };
  });

  const startTime = Date.now();

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        timeSpent: Math.floor((Date.now() - startTime) / 1000)
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    localStorage.setItem(`training-stats-${moduleId}`, JSON.stringify(stats));
  }, [moduleId, stats]);

  const updateScore = (points: number) => {
    setStats(prev => ({
      ...prev,
      score: prev.score + points,
      attempts: prev.attempts + 1
    }));
  };

  const completeModule = () => {
    setStats(prev => ({
      ...prev,
      completedAt: new Date().toISOString()
    }));
  };

  return { stats, updateScore, completeModule };
};