import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, HelpCircle, CheckCircle, Terminal, Puzzle, Cpu } from 'lucide-react';
import type { TrainingModuleData, Exercise } from './types';

interface Props {
  module: TrainingModuleData;
  onComplete: () => void;
}

export const TrainingExercise = ({ module, onComplete }: Props) => {
  const [currentExercise, setCurrentExercise] = useState<Exercise>(module.exercises[0]);
  const [answer, setAnswer] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  // Map exercise types to their corresponding icons using PascalCase
  const ExerciseIcon = {
    command: Terminal,
    puzzle: Puzzle,
    simulation: Cpu
  }[currentExercise.type];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAttempts(prev => prev + 1);

    if (answer.toLowerCase() === currentExercise.solution.toLowerCase()) {
      setIsCorrect(true);
      setTimeout(onComplete, 1500);
    }
  };

  if (isCorrect) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-matrix-primary/10 border border-matrix-primary/30 rounded-lg p-6 text-center"
      >
        <CheckCircle className="w-12 h-12 text-matrix-primary mx-auto mb-4" />
        <h4 className="text-xl font-bold text-matrix-primary mb-2">Exercise Complete</h4>
        <p className="text-matrix-primary/80">
          {currentExercise.points} points earned. Neural pathways strengthened.
        </p>
      </motion.div>
    );
  }

  return (
    <div className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        {ExerciseIcon && <ExerciseIcon className="w-6 h-6 text-matrix-primary" />}
        <h4 className="text-lg font-bold text-matrix-primary">
          {currentExercise.type.charAt(0).toUpperCase() + currentExercise.type.slice(1)} Exercise
        </h4>
      </div>

      <div className="space-y-6">
        <p className="text-matrix-primary/80">{currentExercise.question}</p>

        {showHint && currentExercise.hints.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-matrix-primary/5 border border-matrix-primary/20 rounded-lg p-4"
          >
            <div className="flex items-center space-x-2 mb-2">
              <HelpCircle className="w-4 h-4 text-matrix-primary" />
              <span className="text-matrix-primary/80 text-sm">Hint</span>
            </div>
            <ul className="list-disc list-inside space-y-1">
              {currentExercise.hints.map((hint, index) => (
                <li key={index} className="text-matrix-primary/70 text-sm">{hint}</li>
              ))}
            </ul>
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <textarea
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              className="w-full bg-gray-900/50 border border-matrix-primary/30 rounded-lg p-4 text-matrix-primary focus:border-matrix-primary focus:ring-1 focus:ring-matrix-primary"
              rows={4}
              placeholder="Enter your solution..."
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-x-4">
              <button
                type="button"
                onClick={() => setShowHint(!showHint)}
                className="text-matrix-primary/60 text-sm hover:text-matrix-primary"
              >
                {showHint ? 'Hide Hint' : 'Show Hint'}
              </button>
              <span className="text-matrix-primary/60 text-sm">
                Attempts: {attempts}
              </span>
            </div>
            <button
              type="submit"
              className="flex items-center space-x-2 px-4 py-2 bg-matrix-primary/10 border border-matrix-primary/30 rounded-lg hover:bg-matrix-primary/20"
            >
              <span className="text-matrix-primary">Execute</span>
              <Send className="w-4 h-4 text-matrix-primary" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};