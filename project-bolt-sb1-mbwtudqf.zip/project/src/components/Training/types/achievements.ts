export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  condition: string;
  points: number;
  unlockedAt?: string;
}

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first-step',
    title: 'First Step',
    description: 'Complete your first training module',
    icon: '🎯',
    condition: 'Complete any module',
    points: 100
  },
  {
    id: 'quick-learner',
    title: 'Quick Learner',
    description: 'Complete a module in under 5 minutes',
    icon: '⚡',
    condition: 'Complete module < 5min',
    points: 250
  },
  {
    id: 'perfect-score',
    title: 'Perfect Execution',
    description: 'Complete a module with no failed attempts',
    icon: '✨',
    condition: 'No failed attempts',
    points: 500
  },
  {
    id: 'master-hacker',
    title: 'Master Hacker',
    description: 'Complete all basic training modules',
    icon: '👑',
    condition: 'Complete all modules',
    points: 1000
  }
];