import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { Achievement } from './types/achievements';

interface Props {
  achievement: Achievement;
  onClose: () => void;
}

export const AchievementNotification = ({ achievement, onClose }: Props) => {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="fixed bottom-4 right-4 bg-matrix-primary/10 border border-matrix-primary/30 
                   rounded-lg p-4 shadow-lg backdrop-blur-sm max-w-sm"
      >
        <div className="flex items-start space-x-3">
          <div className="text-2xl">{achievement.icon}</div>
          <div>
            <h4 className="text-lg font-bold text-matrix-primary mb-1">
              Achievement Unlocked!
            </h4>
            <p className="text-matrix-primary/80 font-medium mb-1">
              {achievement.title}
            </p>
            <p className="text-sm text-matrix-primary/60">
              {achievement.description}
            </p>
            <p className="text-sm text-matrix-primary/80 mt-2">
              +{achievement.points} points
            </p>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};