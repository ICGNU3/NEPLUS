import React, { useState } from 'react';
import { TrainingModule } from './TrainingModule';
import { ModuleContent } from './ModuleContent';
import { trainingModules } from './data/trainingModules';
import { useTrainingProgress } from './hooks/useTrainingProgress';

export const TrainingInterface = () => {
  const { progress, completeModule, isModuleCompleted, isModuleLocked } = useTrainingProgress();
  const [activeModule, setActiveModule] = useState<string | null>(null);

  const currentModule = trainingModules.find(m => m.id === activeModule);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold text-matrix-primary mb-4">Basic Training Protocol</h1>
        <p className="text-matrix-primary/80 max-w-2xl mx-auto">
          Master the fundamental techniques of reality manipulation. Complete each module to unlock advanced capabilities.
        </p>
      </header>
      
      <div className="space-y-6">
        {currentModule ? (
          <ModuleContent 
            module={currentModule}
            onComplete={() => {
              completeModule(currentModule.id);
              setActiveModule(null);
            }}
          />
        ) : (
          trainingModules.map((module, index) => (
            <TrainingModule 
              key={module.id}
              {...module}
              isLocked={isModuleLocked(module.id, index)}
              isCompleted={isModuleCompleted(module.id)}
              onStart={() => setActiveModule(module.id)}
            />
          ))
        )}
      </div>
    </div>
  );
};