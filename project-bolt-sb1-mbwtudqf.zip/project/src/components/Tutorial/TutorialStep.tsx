import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

interface TutorialStepProps {
  title: string;
  description: string;
  completed: boolean;
  onComplete: () => void;
  children: React.ReactNode;
}

export const TutorialStep = ({
  title,
  description,
  completed,
  onComplete,
  children
}: TutorialStepProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`p-6 rounded-xl border ${
        completed 
          ? 'border-matrix-primary bg-matrix-primary/10' 
          : 'border-gray-700/50 bg-gray-800/50'
      }`}
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-bold text-matrix-primary">{title}</h3>
          <p className="text-matrix-primary/60">{description}</p>
        </div>
        {completed && (
          <div className="p-1 bg-matrix-primary/20 rounded-full">
            <Check className="w-5 h-5 text-matrix-primary" />
          </div>
        )}
      </div>
      
      <div className="space-y-4">
        {children}
        {!completed && (
          <button
            onClick={onComplete}
            className="w-full py-2 bg-matrix-primary/10 rounded-lg
                     border border-matrix-primary/30 text-matrix-primary
                     hover:bg-matrix-primary/20 transition-colors"
          >
            Complete Step
          </button>
        )}
      </div>
    </motion.div>
  );
};