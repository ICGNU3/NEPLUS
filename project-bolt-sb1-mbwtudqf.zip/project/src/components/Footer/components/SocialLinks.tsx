import React from 'react';
import { MessageCircle, Twitter, Globe } from 'lucide-react';

const socials = [
  { 
    icon: MessageCircle, 
    label: 'Telegram', 
    href: 'https://t.me/neplusofficial',
    className: 'hover:text-matrix-primary'
  },
  { 
    icon: Twitter, 
    label: 'Twitter', 
    href: 'https://x.com/neplus',
    className: 'hover:text-matrix-primary'
  },
  { 
    icon: Globe, 
    label: 'Resources', 
    href: 'https://resources.neplus.xyz',
    className: 'hover:text-matrix-primary'
  },
];

export const SocialLinks = () => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Connect With Us</h3>
      <div className="flex space-x-6">
        {socials.map(({ icon: Icon, label, href, className }) => (
          <a
            key={label}
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className={`text-gray-300 transition-colors duration-300 ${className}`}
            aria-label={label}
          >
            <Icon className="w-6 h-6" />
          </a>
        ))}
      </div>
    </div>
  );
};