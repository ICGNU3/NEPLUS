import React from 'react';
import { motion } from 'framer-motion';
import { fadeInUp } from '../../animations/variants';
import { SocialLinks } from './SocialLinks';
import { QuickLinks } from './QuickLinks';
import { Newsletter } from './Newsletter';

export const FooterSection = () => {
  return (
    <motion.div 
      {...fadeInUp}
      className="max-w-7xl mx-auto px-4 py-12"
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="space-y-4">
          <h3 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
            NEPLUS
          </h3>
          <p className="text-gray-400">
            Empowering the digital Renaissance through creativity, innovation, and cultural preservation.
          </p>
          <SocialLinks />
        </div>
        <QuickLinks />
        <Newsletter />
      </div>
      <div className="mt-12 pt-8 border-t border-gray-800">
        <p className="text-gray-400 text-center">
          © {new Date().getFullYear()} NEPLUS. All rights reserved.
        </p>
      </div>
    </motion.div>
  );
};