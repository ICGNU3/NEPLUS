import React from 'react';
import { useNewsletter } from '../../../hooks/useNewsletter';
import { SubscribeButton } from '../../common/buttons/SubscribeButton';

export const Newsletter = () => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Stay Connected</h3>
      <p className="text-gray-300">Join the resistance. Receive system updates.</p>
      <SubscribeButton className="w-full" />
    </div>
  );
};