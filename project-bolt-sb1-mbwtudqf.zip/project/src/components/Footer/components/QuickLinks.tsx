import React from 'react';

const links = [
  { label: 'About', targetId: 'hero' },
  { label: 'Vision', targetId: 'vision' },
  { label: 'Token', targetId: 'token' },
  { label: 'Roadmap', targetId: 'roadmap' },
  { label: 'Community', targetId: 'get-involved' },
  { label: 'Disclaimer', href: '/disclaimer' }
];

export const QuickLinks = () => {
  const handleClick = (targetId?: string, href?: string) => {
    if (href) {
      window.location.href = href;
    } else if (targetId) {
      document.getElementById(targetId)?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Quick Access</h3>
      <ul className="space-y-2">
        {links.map(({ label, targetId, href }) => (
          <li key={label}>
            <button
              onClick={() => handleClick(targetId, href)}
              className="text-gray-300 hover:text-matrix-primary transition-colors"
            >
              {label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};