import React from 'react';
import { FooterSection } from './components/FooterSection';

export const Footer = () => {
  return (
    <footer className="bg-gray-900 border-t border-gray-800">
      <FooterSection />
    </footer>
  );
};