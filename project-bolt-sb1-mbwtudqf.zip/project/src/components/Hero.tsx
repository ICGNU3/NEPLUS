import React from 'react';
import { Terminal, Zap } from 'lucide-react';
import { HeroButton } from './Hero/HeroButton';
import { HeroCanvas } from './Hero/HeroCanvas';
import { GradientText } from './common/GradientText';
import { motion } from 'framer-motion';

const Hero = () => {
  const handleInitiate = () => {
    document.getElementById('token')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleLearnTruth = () => {
    window.location.href = '/greenpaper';
  };

  return (
    <div className="relative min-h-screen">
      <HeroCanvas />
      <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-6xl md:text-7xl font-bold mb-6">
            Shatter the <GradientText>Illusion</GradientText>
          </h1>
          <p className="text-xl md:text-2xl text-matrix-primary/80 max-w-2xl mx-auto mb-12 leading-relaxed font-mono">
            They programmed limits into your reality. We have the code to break them.
            <span className="block mt-2">Ready to rewrite the rules?</span>
          </p>
          <div className="flex flex-col items-center sm:flex-row sm:justify-center gap-4 sm:gap-6">
            <HeroButton
              icon={Terminal}
              label="Access Protocol"
              variant="primary"
              onClick={handleInitiate}
            />
            <HeroButton
              icon={Zap}
              label="Decode Truth"
              variant="secondary"
              onClick={handleLearnTruth}
            />
          </div>
        </motion.div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-matrix-black to-transparent" />
    </div>
  );
};

export default Hero;