```typescript
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import type { Puzzle } from '../types';

interface PuzzleDisplayProps {
  puzzle: Puzzle;
  onSolve: (solution: string) => void;
}

export const PuzzleDisplay = ({ puzzle, onSolve }: PuzzleDisplayProps) => {
  const [answer, setAnswer] = useState('');

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel p-6"
    >
      <div className="mb-6">
        <h3 className="text-xl font-bold mb-2 matrix-text">
          Level {puzzle.difficulty} {puzzle.type.toUpperCase()} Challenge
        </h3>
        <p className="text-matrix-primary/80 font-mono">{puzzle.question}</p>
      </div>

      <div className="space-y-4">
        <input
          type="text"
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          className="w-full bg-matrix-dark border border-matrix-primary/30 p-3 rounded-lg 
                   text-matrix-primary font-mono focus:border-matrix-primary focus:ring-1 
                   focus:ring-matrix-primary outline-none"
          placeholder="Enter solution..."
        />

        <div className="flex justify-between">
          {puzzle.hint && (
            <button className="text-matrix-primary/60 hover:text-matrix-primary">
              Request Hint
            </button>
          )}
          <button
            onClick={() => onSolve(answer)}
            className="px-6 py-2 bg-matrix-dark border border-matrix-primary 
                     hover:bg-matrix-primary/20 rounded-lg font-mono"
          >
            Execute Solution
          </button>
        </div>
      </div>
    </motion.div>
  );
};
```