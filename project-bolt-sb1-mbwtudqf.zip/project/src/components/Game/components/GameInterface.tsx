```typescript
import React from 'react';
import { Terminal } from 'lucide-react';
import { PuzzleDisplay } from './PuzzleDisplay';
import { GameControls } from './GameControls';
import { ScoreDisplay } from './ScoreDisplay';
import { useGameState } from '../hooks/useGameState';
import { usePuzzleGenerator } from '../hooks/usePuzzleGenerator';

export const GameInterface = () => {
  const { gameState, progress, startGame, pauseGame, completeLevel } = useGameState();
  const { generatePuzzle } = usePuzzleGenerator();

  return (
    <div className="min-h-screen bg-matrix-black text-matrix-primary p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center space-x-4 mb-8">
          <Terminal className="w-8 h-8" />
          <h1 className="text-3xl font-bold matrix-text">Protocol Override</h1>
        </div>

        <div className="glass-panel p-6 mb-8">
          <ScoreDisplay score={progress.totalScore} level={gameState.level} />
        </div>

        {gameState.currentPuzzle ? (
          <PuzzleDisplay
            puzzle={gameState.currentPuzzle}
            onSolve={(solution) => {
              if (solution === gameState.currentPuzzle?.solution) {
                completeLevel(gameState.currentPuzzle, 10); // Add actual time tracking
              }
            }}
          />
        ) : (
          <GameControls
            status={gameState.status}
            onStart={startGame}
            onPause={pauseGame}
          />
        )}
      </div>
    </div>
  );
};
```