```typescript
import React from 'react';
import { motion } from 'framer-motion';
import { Award, Zap } from 'lucide-react';

interface ScoreDisplayProps {
  score: number;
  level: number;
}

export const ScoreDisplay = ({ score, level }: ScoreDisplayProps) => {
  return (
    <div className="flex justify-between items-center">
      <div className="flex items-center space-x-4">
        <Zap className="w-6 h-6 text-matrix-primary" />
        <div>
          <p className="text-sm text-matrix-primary/70">Current Level</p>
          <p className="text-2xl font-bold matrix-text">{level}</p>
        </div>
      </div>

      <motion.div
        initial={{ scale: 1 }}
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 0.3 }}
        className="flex items-center space-x-4"
      >
        <Award className="w-6 h-6 text-matrix-primary" />
        <div>
          <p className="text-sm text-matrix-primary/70">Protocol Score</p>
          <p className="text-2xl font-bold matrix-text">{score.toLocaleString()}</p>
        </div>
      </motion.div>
    </div>
  );
};
```