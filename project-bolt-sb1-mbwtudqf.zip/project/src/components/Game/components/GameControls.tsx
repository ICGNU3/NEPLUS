```typescript
import React from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, RotateCcw } from 'lucide-react';
import type { GameState } from '../types';

interface GameControlsProps {
  status: GameState['status'];
  onStart: () => void;
  onPause: () => void;
}

export const GameControls = ({ status, onStart, onPause }: GameControlsProps) => {
  return (
    <div className="flex justify-center space-x-4">
      {status === 'idle' && (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onStart}
          className="px-8 py-3 bg-matrix-dark border border-matrix-primary 
                   hover:bg-matrix-primary/20 rounded-lg font-mono flex items-center space-x-2"
        >
          <Play className="w-5 h-5" />
          <span>Initialize Sequence</span>
        </motion.button>
      )}

      {status === 'playing' && (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onPause}
          className="px-8 py-3 bg-matrix-dark border border-matrix-primary/50 
                   hover:bg-matrix-primary/20 rounded-lg font-mono flex items-center space-x-2"
        >
          <Pause className="w-5 h-5" />
          <span>Suspend Protocol</span>
        </motion.button>
      )}

      {status === 'paused' && (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onStart}
          className="px-8 py-3 bg-matrix-dark border border-matrix-primary/50 
                   hover:bg-matrix-primary/20 rounded-lg font-mono flex items-center space-x-2"
        >
          <RotateCcw className="w-5 h-5" />
          <span>Resume Protocol</span>
        </motion.button>
      )}
    </div>
  );
};
```