```typescript
export interface GameState {
  level: number;
  score: number;
  status: 'idle' | 'playing' | 'paused' | 'complete';
  currentPuzzle: Puzzle | null;
}

export interface Puzzle {
  id: string;
  type: 'cipher' | 'pattern' | 'sequence' | 'hack';
  difficulty: 1 | 2 | 3;
  question: string;
  hint?: string;
  solution: string;
  timeLimit: number;
}

export interface PlayerProgress {
  solvedPuzzles: string[];
  unlockedLevels: number[];
  totalScore: number;
  bestTimes: Record<string, number>;
}
```