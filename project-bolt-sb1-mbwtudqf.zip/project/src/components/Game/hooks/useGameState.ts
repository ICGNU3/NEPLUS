```typescript
import { useState, useCallback } from 'react';
import type { GameState, Puzzle, PlayerProgress } from '../types';

export const useGameState = () => {
  const [gameState, setGameState] = useState<GameState>({
    level: 1,
    score: 0,
    status: 'idle',
    currentPuzzle: null
  });

  const [progress, setProgress] = useState<PlayerProgress>({
    solvedPuzzles: [],
    unlockedLevels: [1],
    totalScore: 0,
    bestTimes: {}
  });

  const startGame = useCallback(() => {
    setGameState(prev => ({ ...prev, status: 'playing' }));
  }, []);

  const pauseGame = useCallback(() => {
    setGameState(prev => ({ ...prev, status: 'paused' }));
  }, []);

  const completeLevel = useCallback((puzzle: Puzzle, timeElapsed: number) => {
    setProgress(prev => ({
      ...prev,
      solvedPuzzles: [...prev.solvedPuzzles, puzzle.id],
      unlockedLevels: [...new Set([...prev.unlockedLevels, gameState.level + 1])],
      totalScore: prev.totalScore + calculateScore(puzzle.difficulty, timeElapsed),
      bestTimes: {
        ...prev.bestTimes,
        [puzzle.id]: Math.min(timeElapsed, prev.bestTimes[puzzle.id] || Infinity)
      }
    }));
  }, [gameState.level]);

  return {
    gameState,
    progress,
    startGame,
    pauseGame,
    completeLevel
  };
};

const calculateScore = (difficulty: number, timeElapsed: number): number => {
  const baseScore = difficulty * 1000;
  const timeBonus = Math.max(0, 30 - timeElapsed) * 100;
  return baseScore + timeBonus;
};
```