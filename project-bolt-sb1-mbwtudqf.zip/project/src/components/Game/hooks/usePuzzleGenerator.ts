```typescript
import { useCallback } from 'react';
import type { Puzzle } from '../types';

export const usePuzzleGenerator = () => {
  const generatePuzzle = useCallback((level: number): Puzzle => {
    const puzzleTypes = ['cipher', 'pattern', 'sequence', 'hack'] as const;
    const difficulty = Math.min(Math.ceil(level / 3), 3) as 1 | 2 | 3;
    
    const puzzles: Record<string, () => Puzzle> = {
      cipher: () => generateCipherPuzzle(difficulty),
      pattern: () => generatePatternPuzzle(difficulty),
      sequence: () => generateSequencePuzzle(difficulty),
      hack: () => generateHackPuzzle(difficulty)
    };

    const type = puzzleTypes[level % puzzleTypes.length];
    return puzzles[type]();
  }, []);

  return { generatePuzzle };
};

const generateCipherPuzzle = (difficulty: number): Puzzle => ({
  id: `cipher-${Date.now()}`,
  type: 'cipher',
  difficulty,
  question: generateCipherQuestion(difficulty),
  solution: generateCipherSolution(difficulty),
  timeLimit: 300 - (difficulty * 60),
  hint: difficulty < 3 ? 'Look for patterns in the matrix code' : undefined
});

// Add other puzzle generators here
const generatePatternPuzzle = (difficulty: number): Puzzle => ({
  id: `pattern-${Date.now()}`,
  type: 'pattern',
  difficulty,
  question: generatePatternQuestion(difficulty),
  solution: generatePatternSolution(difficulty),
  timeLimit: 240 - (difficulty * 45)
});

// Implementation details for puzzle generation...
const generateCipherQuestion = (difficulty: number): string => {
  // Implement cipher generation logic
  return 'Decode the matrix transmission: [Example Cipher]';
};

const generateCipherSolution = (difficulty: number): string => {
  // Implement solution generation logic
  return 'EXAMPLE_SOLUTION';
};

const generatePatternQuestion = (difficulty: number): string => {
  return 'Complete the sequence: [Example Pattern]';
};

const generatePatternSolution = (difficulty: number): string => {
  return 'PATTERN_SOLUTION';
};

const generateSequencePuzzle = (difficulty: number): Puzzle => ({
  id: `sequence-${Date.now()}`,
  type: 'sequence',
  difficulty,
  question: 'Identify the next number in the sequence',
  solution: '42',
  timeLimit: 180 - (difficulty * 30)
});

const generateHackPuzzle = (difficulty: number): Puzzle => ({
  id: `hack-${Date.now()}`,
  type: 'hack',
  difficulty,
  question: 'Break through the firewall',
  solution: 'OVERRIDE_CODE',
  timeLimit: 360 - (difficulty * 60)
});
```