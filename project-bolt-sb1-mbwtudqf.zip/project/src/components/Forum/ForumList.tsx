import React from 'react';
import { MessageSquare, Users, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

const forumCategories = [
  {
    id: 'training',
    icon: Zap,
    title: 'Training & Development',
    description: 'Discuss training protocols and development strategies'
  },
  {
    id: 'network',
    icon: Users,
    title: 'Network Operations',
    description: 'Connect with other operators and share experiences'
  },
  {
    id: 'tech',
    icon: MessageSquare,
    title: 'Technical Discussion',
    description: 'Deep dive into technical aspects and implementation'
  }
];

export const ForumList = () => {
  return (
    <div className="space-y-6">
      {forumCategories.map(({ id, icon: Icon, title, description }) => (
        <Link
          key={id}
          to={`/forum/${id}`}
          className="block bg-gray-800/50 rounded-xl p-6 hover:bg-gray-700/50 
                   transition-colors border border-matrix-primary/20 
                   hover:border-matrix-primary/40"
        >
          <div className="flex items-start space-x-4">
            <div className="p-2 bg-matrix-primary/10 rounded-lg">
              <Icon className="w-6 h-6 text-matrix-primary" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-matrix-primary">{title}</h3>
              <p className="text-matrix-primary/60">{description}</p>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
};