import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send } from 'lucide-react';

interface CreatePostProps {
  categoryId: string;
  onSubmit: (data: { title: string; content: string }) => Promise<void>;
}

export const CreatePost = ({ categoryId, onSubmit }: CreatePostProps) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    try {
      setIsSubmitting(true);
      await onSubmit({ title, content });
      setTitle('');
      setContent('');
    } catch (error) {
      console.error('Error creating post:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-800/50 rounded-xl p-6 border border-matrix-primary/20"
      onSubmit={handleSubmit}
    >
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Post title"
        className="w-full bg-gray-900/50 rounded-lg px-4 py-2 mb-4
                 border border-matrix-primary/30 text-matrix-primary
                 placeholder:text-matrix-primary/40 focus:border-matrix-primary"
        required
      />
      
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Write your post..."
        className="w-full bg-gray-900/50 rounded-lg px-4 py-2 mb-4
                 border border-matrix-primary/30 text-matrix-primary
                 placeholder:text-matrix-primary/40 focus:border-matrix-primary
                 min-h-[150px]"
        required
      />
      
      <button
        type="submit"
        disabled={isSubmitting}
        className="flex items-center justify-center space-x-2 w-full
                 bg-matrix-primary/10 rounded-lg px-4 py-2
                 border border-matrix-primary/30 text-matrix-primary
                 hover:bg-matrix-primary/20 disabled:opacity-50
                 disabled:cursor-not-allowed transition-colors"
      >
        <Send className="w-4 h-4" />
        <span>{isSubmitting ? 'Creating...' : 'Create Post'}</span>
      </button>
    </motion.form>
  );
};