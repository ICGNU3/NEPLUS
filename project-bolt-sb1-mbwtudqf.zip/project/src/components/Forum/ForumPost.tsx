import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, ThumbsUp, Award } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';

interface ForumPostProps {
  id: string;
  title: string;
  content: string;
  author: {
    name: string;
    avatar?: string;
  };
  createdAt: string;
  commentCount: number;
  reactionCount: number;
}

export const ForumPost = ({
  id,
  title,
  content,
  author,
  createdAt,
  commentCount,
  reactionCount
}: ForumPostProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-800/50 rounded-xl p-6 border border-matrix-primary/20"
    >
      <Link to={`/forum/post/${id}`}>
        <h3 className="text-xl font-bold text-matrix-primary mb-2">{title}</h3>
      </Link>
      
      <p className="text-matrix-primary/70 mb-4 line-clamp-2">{content}</p>
      
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <MessageSquare className="w-4 h-4 text-matrix-primary/60" />
            <span className="text-matrix-primary/60">{commentCount}</span>
          </div>
          <div className="flex items-center space-x-2">
            <ThumbsUp className="w-4 h-4 text-matrix-primary/60" />
            <span className="text-matrix-primary/60">{reactionCount}</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <span className="text-matrix-primary/60">
            {formatDistanceToNow(new Date(createdAt), { addSuffix: true })}
          </span>
          <span className="text-matrix-primary/60">•</span>
          <span className="text-matrix-primary">{author.name}</span>
        </div>
      </div>
    </motion.div>
  );
};