import React from 'react';
import { motion } from 'framer-motion';
import { ThumbsUp, Flag } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface ForumCommentProps {
  content: string;
  author: {
    name: string;
    avatar?: string;
  };
  createdAt: string;
  reactionCount: number;
  onReact: () => void;
  onReport: () => void;
}

export const ForumComment = ({
  content,
  author,
  createdAt,
  reactionCount,
  onReact,
  onReport
}: ForumCommentProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-800/30 rounded-lg p-4 border border-matrix-primary/10"
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center space-x-2">
          <span className="font-bold text-matrix-primary">{author.name}</span>
          <span className="text-sm text-matrix-primary/60">
            {formatDistanceToNow(new Date(createdAt), { addSuffix: true })}
          </span>
        </div>
        
        <button
          onClick={onReport}
          className="p-1 text-matrix-primary/40 hover:text-matrix-primary/60"
        >
          <Flag className="w-4 h-4" />
        </button>
      </div>
      
      <p className="text-matrix-primary/80 mb-3">{content}</p>
      
      <div className="flex items-center space-x-4">
        <button
          onClick={onReact}
          className="flex items-center space-x-1 text-matrix-primary/60 hover:text-matrix-primary"
        >
          <ThumbsUp className="w-4 h-4" />
          <span>{reactionCount}</span>
        </button>
      </div>
    </motion.div>
  );
};