import React from 'react';
import { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface SupportCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
}

export const SupportCard = ({ icon: Icon, title, description, href }: SupportCardProps) => {
  return (
    <motion.a
      href={href}
      whileHover={{ y: -5 }}
      className="flex flex-col items-center p-6 bg-gray-800/50 rounded-xl border border-matrix-primary/20 
                 hover:border-matrix-primary/40 hover:bg-gray-700/50 transition-all duration-300"
    >
      <Icon className="w-8 h-8 text-matrix-primary mb-4" />
      <h3 className="text-xl font-medium text-white mb-2">{title}</h3>
      <p className="text-gray-300 text-sm text-center">{description}</p>
    </motion.a>
  );
};