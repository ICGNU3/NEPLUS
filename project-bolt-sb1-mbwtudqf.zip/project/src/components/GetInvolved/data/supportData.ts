import { Clock, Book, MessageCircle, Newspaper } from 'lucide-react';

export const supportOptions = [
  {
    icon: Clock,
    label: "Daily Office Hours",
    description: "Join our daily support sessions with experts and mentors. Monday through Friday.",
    href: "#"
  },
  {
    icon: Book,
    label: "Resource Library",
    description: "Access our comprehensive collection of guides, tools, and educational materials.",
    href: "#"
  },
  {
    icon: MessageCircle,
    label: "Support Network",
    description: "Connect with our community of creators, mentors, and innovators.",
    href: "#"
  },
  {
    icon: Newspaper,
    label: "Digital Renaissance",
    description: "Subscribe to our newsletter for weekly insights and opportunities.",
    href: "#"
  }
];