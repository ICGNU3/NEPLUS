import React from 'react';
import { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface SocialLinkProps {
  icon: LucideIcon;
  label: string;
  href: string;
}

export const SocialLink = ({ icon: Icon, label, href }: SocialLinkProps) => {
  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      whileHover={{ 
        scale: 1.05,
        boxShadow: '0 0 20px rgba(96, 165, 250, 0.5)'
      }}
      whileTap={{ scale: 0.95 }}
      className="flex items-center justify-center space-x-3 px-6 py-4 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-all duration-300 border border-blue-500/20"
    >
      <Icon className="w-6 h-6 text-blue-400" />
      <span className="text-lg font-medium bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
        {label}
      </span>
    </motion.a>
  );
};