import React from 'react';
import { Section } from '../common/Section';
import { SectionHeader } from '../common/SectionHeader';
import { Terminal, Network, Zap, Code } from 'lucide-react';
import { SupportCard } from './components/SupportCard';

const GetInvolvedSection = () => {
  const supportOptions = [
    {
      icon: Terminal,
      title: "Command Center",
      description: "Access operator training protocols and learn to manipulate the base reality matrix.",
      href: "/command-center"
    },
    {
      icon: Network,
      title: "Join Network",
      description: "Connect with fellow operators through quantum-encrypted channels.",
      href: "https://t.me/neplusxyz"
    },
    {
      icon: Code,
      title: "Core Access",
      description: "Gain privileged access to system manipulation tools and reality hacking protocols.",
      href: "/platform/tools"
    },
    {
      icon: Zap,
      title: "Neural Feed",
      description: "Receive critical system vulnerabilities and exploitation vectors.",
      href: "/platform/feed"
    }
  ];

  return (
    <Section id="get-involved" className="bg-matrix-gradient">
      <SectionHeader
        title="Join the Resistance"
        subtitle="The system's weaknesses have been identified. The exploit vectors are mapped. 
                 All that's missing is you - your unique ability to see through the illusion."
      />
      <div className="grid sm:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {supportOptions.map((option, index) => (
          <SupportCard key={index} {...option} />
        ))}
      </div>
    </Section>
  );
};

export default GetInvolvedSection;