import React from 'react';
import { motion } from 'framer-motion';
import { StatsCard } from './components/StatsCard';
import { SubscribeButton } from '../common/buttons/SubscribeButton';
import { useTokenStats } from './hooks/useTokenStats';

const TokenStats = () => {
  const { stats } = useTokenStats();

  return (
    <div className="space-y-8">
      <div className="grid md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
          >
            <StatsCard {...stat} />
          </motion.div>
        ))}
      </div>
      <div className="flex justify-center">
        <SubscribeButton />
      </div>
    </div>
  );
};

export default TokenStats;