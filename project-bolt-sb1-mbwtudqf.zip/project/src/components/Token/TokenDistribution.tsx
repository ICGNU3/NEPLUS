import React from 'react';
import { TokenChart } from './components/TokenChart';
import { useTokenDistribution } from './hooks/useTokenDistribution';
import { motion } from 'framer-motion';

const TokenDistribution = () => {
  const { distribution } = useTokenDistribution();

  return (
    <div className="glass-panel rounded-xl p-8">
      <h3 className="text-2xl font-bold mb-8 text-center matrix-text">Protocol Distribution</h3>
      <div className="flex flex-col md:flex-row items-center justify-between">
        <TokenChart distribution={distribution} />
        <div className="mt-8 md:mt-0 md:ml-8 space-y-4">
          {distribution.map(({ label, percentage, color }) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              whileHover={{ x: 5 }}
              className="flex items-center justify-between p-2 rounded-lg hover:bg-matrix-dark/30"
            >
              <div className="flex items-center space-x-3">
                <div 
                  className="w-4 h-4 rounded-full" 
                  style={{ backgroundColor: color, boxShadow: `0 0 10px ${color}` }} 
                />
                <span className="text-matrix-primary font-mono">{label}</span>
              </div>
              <span className="font-mono text-matrix-primary ml-4">{percentage}%</span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TokenDistribution;