import React, { useEffect, useRef } from 'react';
import type { TokenDistributionItem } from '../hooks/useTokenDistribution';

interface TokenChartProps {
  distribution: TokenDistributionItem[];
}

export const TokenChart = ({ distribution }: TokenChartProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 200;
    canvas.width = size * 2;
    canvas.height = size * 2;
    ctx.scale(2, 2);

    let startAngle = 0;
    distribution.forEach(({ percentage, color }) => {
      const slice = (percentage / 100) * Math.PI * 2;
      
      ctx.beginPath();
      ctx.moveTo(size / 2, size / 2);
      ctx.arc(size / 2, size / 2, size / 2 - 10, startAngle, startAngle + slice);
      ctx.fillStyle = color;
      ctx.fill();
      
      startAngle += slice;
    });

    // Inner circle
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, size / 4, 0, Math.PI * 2);
    ctx.fillStyle = '#1F2937';
    ctx.fill();
  }, [distribution]);

  return (
    <canvas
      ref={canvasRef}
      className="w-[200px] h-[200px]"
    />
  );
};