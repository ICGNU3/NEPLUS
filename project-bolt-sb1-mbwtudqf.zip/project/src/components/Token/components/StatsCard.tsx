import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  icon: LucideIcon;
  title: string;
  value: string;
  subtitle: string;
}

export const StatsCard = ({ icon: Icon, title, value, subtitle }: StatsCardProps) => {
  return (
    <div className="bg-gray-800 bg-opacity-50 p-6 rounded-xl">
      <div className="flex items-center mb-4">
        <Icon className="w-6 h-6 text-blue-400 mr-2" />
        <h3 className="text-lg font-semibold text-gray-300">{title}</h3>
      </div>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-gray-400">{subtitle}</p>
    </div>
  );
};