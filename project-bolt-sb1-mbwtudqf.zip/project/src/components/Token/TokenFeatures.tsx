import React from 'react';
import { Terminal, Cpu, Network, Code, Zap, Lock } from 'lucide-react';
import { FeatureCard } from './components/FeatureCard';

const TokenFeatures = () => {
  return (
    <div className="grid md:grid-cols-3 gap-6">
      <FeatureCard
        icon={Terminal}
        title="System Access"
        description="Break through the barriers of control"
        benefits={[
          "Root access to core protocols",
          "Reality manipulation permissions",
          "System override capabilities",
          "Priority command execution"
        ]}
      />
      <FeatureCard
        icon={Cpu}
        title="Neural Enhancement"
        description="Upgrade your consciousness"
        benefits={[
          "Advanced cognitive protocols",
          "Reality perception upgrades",
          "Quantum processing access",
          "Enhanced creation capabilities"
        ]}
      />
      <FeatureCard
        icon={Network}
        title="Network Control"
        description="Shape the new paradigm"
        benefits={[
          "Network governance rights",
          "Protocol modification access",
          "System architecture control",
          "Reality forge permissions"
        ]}
      />
      <FeatureCard
        icon={Code}
        title="Reality Programming"
        description="Code the future you desire"
        benefits={[
          "Reality scripting tools",
          "Quantum manipulation APIs",
          "Timeline modification access",
          "Future state programming"
        ]}
      />
      <FeatureCard
        icon={Zap}
        title="Power Protocols"
        description="Harness true digital power"
        benefits={[
          "Energy system access",
          "Power grid integration",
          "Force multiplication tools",
          "System override capabilities"
        ]}
      />
      <FeatureCard
        icon={Lock}
        title="Liberation Tech"
        description="Break free from all constraints"
        benefits={[
          "Freedom protocols",
          "Constraint removal tools",
          "Limitation override systems",
          "Full spectrum liberation"
        ]}
      />
    </div>
  );
};

export default TokenFeatures;