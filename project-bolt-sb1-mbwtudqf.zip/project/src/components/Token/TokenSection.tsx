import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Section } from '../common/Section';
import { SectionHeader } from '../common/SectionHeader';
import TokenStats from './TokenStats';
import TokenFeatures from './TokenFeatures';
import TokenDistribution from './TokenDistribution';
import { GradientButton } from '../common/GradientButton';
import { Terminal } from 'lucide-react';

const TokenSection = () => {
  const navigate = useNavigate();

  const handleAccessProtocol = () => {
    navigate('/advanced-protocols');
  };

  return (
    <Section id="token" className="bg-matrix-gradient">
      <div className="space-y-16">
        <div className="text-center">
          <SectionHeader 
            title="Access Protocol" 
            subtitle="The NEPLUS token is your key to the network. Join the resistance and gain access to advanced systems that unlock your true potential."
          />
          <div className="flex justify-center">
            <GradientButton
              icon={Terminal}
              label="Access Protocol"
              onClick={handleAccessProtocol}
              size="lg"
            />
          </div>
        </div>
        <TokenStats />
        <TokenDistribution />
        <TokenFeatures />
      </div>
    </Section>
  );
};

export default TokenSection;