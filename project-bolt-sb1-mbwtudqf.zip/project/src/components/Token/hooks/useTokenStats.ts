import { useMemo } from 'react';
import { Coins, Timer, Lock } from 'lucide-react';

export const useTokenStats = () => {
  const stats = useMemo(() => [
    {
      icon: Coins,
      title: 'Total Supply',
      value: '1,000,000,000',
      subtitle: 'NEPLUS Tokens'
    },
    {
      icon: Timer,
      title: 'System Launch',
      value: 'January 11, 2025',
      subtitle: 'Protocol Initialization'
    },
    {
      icon: Lock,
      title: 'Core Team Vesting',
      value: '6 Months',
      subtitle: '75% Locked • 25% Active'
    }
  ], []);

  return { stats };
};