import { useMemo } from 'react';

export interface TokenDistributionItem {
  label: string;
  percentage: number;
  color: string;
}

export const useTokenDistribution = () => {
  const distribution = useMemo<TokenDistributionItem[]>(() => [
    { 
      label: 'Network Operators', 
      percentage: 40, 
      color: '#00ff41' // Matrix green
    },
    { 
      label: 'System Evolution', 
      percentage: 20, 
      color: '#39ff14' // Bright matrix green
    },
    { 
      label: 'Core Protocol (Locked)', 
      percentage: 11.25, 
      color: '#32CD32' // Lime green
    },
    { 
      label: 'Core Protocol (Active)', 
      percentage: 3.75, 
      color: '#98FB98' // Pale green
    },
    { 
      label: 'Liberation Fund', 
      percentage: 15, 
      color: '#50C878' // Emerald green
    },
    { 
      label: 'System Reserve', 
      percentage: 10, 
      color: '#90EE90' // Light green
    }
  ], []);

  return { distribution };
};