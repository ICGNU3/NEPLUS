import React from 'react';
import { motion } from 'framer-motion';

interface ProgressBarProps {
  progress: number;
  total: number;
  label?: string;
}

export const ProgressBar = ({ progress, total, label }: ProgressBarProps) => {
  const percentage = Math.min(100, (progress / total) * 100);

  return (
    <div className="space-y-2">
      {label && (
        <div className="flex justify-between text-sm text-matrix-primary/80">
          <span>{label}</span>
          <span>{`${progress}/${total}`}</span>
        </div>
      )}
      <div className="h-2 bg-matrix-primary/10 rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-matrix-primary"
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>
    </div>
  );
};