import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

interface LogoProps {
  className?: string;
}

export const NeplusLogo = ({ className = '' }: LogoProps) => {
  return (
    <Link to="/" className={`inline-block ${className}`}>
      <motion.div
        whileHover={{ scale: 1.05 }}
        className="relative font-bold text-2xl"
      >
        <span className="text-matrix-primary relative z-10">
          N<span className="text-lg">+</span>
        </span>
        <motion.div
          className="absolute inset-0 bg-matrix-primary/20 blur-lg -z-10"
          animate={{
            opacity: [0.5, 0.8, 0.5],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      </motion.div>
    </Link>
  );
};