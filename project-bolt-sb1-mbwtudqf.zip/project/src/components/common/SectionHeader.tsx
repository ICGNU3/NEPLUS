import React from 'react';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
}

export function SectionHeader({ title, subtitle }: SectionHeaderProps) {
  return (
    <header className="text-center mb-16">
      <h2 
        id={`${title.toLowerCase().replace(/\s+/g, '-')}-title`}
        className="text-4xl font-bold matrix-text mb-4"
      >
        {title}
      </h2>
      {subtitle && (
        <p className="text-lg text-matrix-primary/80 max-w-3xl mx-auto">
          {subtitle}
        </p>
      )}
    </header>
  );
}