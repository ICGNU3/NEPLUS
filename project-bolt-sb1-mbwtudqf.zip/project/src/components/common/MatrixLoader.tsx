import React from 'react';
import { motion } from 'framer-motion';

export const MatrixLoader = () => {
  return (
    <div className="fixed inset-0 bg-matrix-black flex items-center justify-center z-50">
      <motion.div 
        animate={{ 
          opacity: [0.5, 1, 0.5],
          scale: [0.98, 1, 0.98]
        }}
        transition={{ 
          duration: 1.5,
          repeat: Infinity,
          ease: "linear"
        }}
        className="text-center"
      >
        <div className="text-matrix-primary text-2xl font-mono mb-4">
          Loading System...
        </div>
        <div className="w-32 h-1 bg-matrix-dark mx-auto rounded-full overflow-hidden">
          <motion.div
            animate={{
              x: [-128, 128]
            }}
            transition={{
              duration: 1,
              repeat: Infinity,
              ease: "linear"
            }}
            className="w-16 h-full bg-matrix-primary"
          />
        </div>
      </motion.div>
    </div>
  );
};