import React from 'react';
import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
}

export const Breadcrumbs = ({ items }: BreadcrumbsProps) => {
  return (
    <nav className="flex items-center space-x-2 text-sm">
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {index > 0 && <ChevronRight className="w-4 h-4 text-matrix-primary/50" />}
          {item.href ? (
            <Link 
              to={item.href}
              className="text-matrix-primary/80 hover:text-matrix-primary transition-colors"
            >
              {item.label}
            </Link>
          ) : (
            <span className="text-matrix-primary">{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
};