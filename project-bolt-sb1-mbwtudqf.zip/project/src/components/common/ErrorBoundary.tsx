import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Error caught by boundary:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-matrix-black p-4">
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-bold text-matrix-primary">System Malfunction</h2>
            <p className="text-matrix-primary/80 max-w-md mx-auto">
              {this.state.error?.message || 'A critical error has been detected. The system is attempting to recover.'}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-matrix-dark border border-matrix-primary 
                       hover:bg-matrix-primary/20 rounded-lg font-mono"
            >
              Reinitialize System
            </button>
            {process.env.NODE_ENV === 'development' && (
              <pre className="mt-4 p-4 bg-matrix-dark/50 rounded-lg text-left overflow-auto max-w-2xl mx-auto text-sm">
                {this.state.error?.stack}
              </pre>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}