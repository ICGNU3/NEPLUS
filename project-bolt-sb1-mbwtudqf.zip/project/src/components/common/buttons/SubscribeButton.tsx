import React from 'react';
import { motion } from 'framer-motion';
import { Send } from 'lucide-react';

interface SubscribeButtonProps {
  className?: string;
}

export const SubscribeButton = ({ className = '' }: SubscribeButtonProps) => {
  const handleClick = () => {
    window.open('https://t.me/neplusxyz', '_blank');
  };

  return (
    <motion.button
      onClick={handleClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={`
        group flex items-center space-x-2 px-6 py-3 
        bg-matrix-dark border border-matrix-primary 
        hover:bg-matrix-primary/20 rounded-lg font-mono
        transition-all duration-300
        ${className}
      `}
    >
      <Send className="w-5 h-5 text-matrix-primary group-hover:translate-x-1 transition-transform" />
      <span className="text-matrix-primary">Initialize Connection</span>
    </motion.button>
  );
};