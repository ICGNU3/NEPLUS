import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUp } from 'lucide-react';
import { useScrollPosition } from '../../../hooks/useScrollPosition';

export const ScrollToTop = () => {
  const { isVisible } = useScrollPosition(300);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
      onClick={scrollToTop}
      className="fixed bottom-8 right-8 p-3 rounded-full bg-matrix-dark 
                 border border-matrix-primary/30 hover:bg-matrix-primary/20 
                 transition-all duration-300 z-50"
      aria-label="Scroll to top"
    >
      <ArrowUp className="w-5 h-5 text-matrix-primary" />
    </motion.button>
  );
};