import React from 'react';
import { CheckCircle } from 'lucide-react';

interface SuccessMessageProps {
  message: string;
  onDismiss?: () => void;
}

export const SuccessMessage = ({ message, onDismiss }: SuccessMessageProps) => {
  return (
    <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4 text-center">
      <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
      <p className="text-green-500 mb-4">{message}</p>
      {onDismiss && (
        <button
          onClick={onDismiss}
          className="px-4 py-2 bg-green-500/10 border border-green-500/30 
                   rounded-lg text-green-500 hover:bg-green-500/20"
        >
          Dismiss
        </button>
      )}
    </div>
  );
};