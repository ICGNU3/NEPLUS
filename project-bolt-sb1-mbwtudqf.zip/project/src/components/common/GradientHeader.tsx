import React from 'react';
import { motion } from 'framer-motion';

interface GradientHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export const GradientHeader = ({ children, className = '' }: GradientHeaderProps) => {
  return (
    <motion.h2
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`
        relative text-4xl font-bold
        bg-clip-text text-transparent
        bg-gradient-to-r from-matrix-primary via-matrix-light to-matrix-primary
        animate-gradient
        after:absolute after:inset-0
        after:bg-gradient-to-r after:from-matrix-primary after:via-matrix-light after:to-matrix-primary
        after:translate-y-[0.15em] after:translate-x-[0.15em] after:-z-10
        after:bg-clip-text after:text-transparent
        after:blur-sm
        ${className}
      `}
    >
      {children}
    </motion.h2>
  );
};