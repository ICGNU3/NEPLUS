import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '../../../test/utils/test-utils';
import { GradientButton } from '../GradientButton';
import { Rocket } from 'lucide-react';

describe('GradientButton', () => {
  it('renders with icon and label', () => {
    const onClick = vi.fn();
    render(
      <GradientButton
        icon={Rocket}
        label="Launch"
        onClick={onClick}
      />
    );

    expect(screen.getByText('Launch')).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeInTheDocument();
  });

  it('calls onClick when clicked', () => {
    const onClick = vi.fn();
    render(
      <GradientButton
        icon={Rocket}
        label="Launch"
        onClick={onClick}
      />
    );

    fireEvent.click(screen.getByRole('button'));
    expect(onClick).toHaveBeenCalledTimes(1);
  });
});