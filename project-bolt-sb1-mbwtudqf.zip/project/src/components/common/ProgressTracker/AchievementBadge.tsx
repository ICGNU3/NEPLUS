import React from 'react';
import { motion } from 'framer-motion';
import { Award } from 'lucide-react';

interface AchievementBadgeProps {
  title: string;
  description: string;
  unlocked: boolean;
}

export const AchievementBadge = ({ title, description, unlocked }: AchievementBadgeProps) => {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className={`p-4 rounded-lg border ${
        unlocked 
          ? 'border-matrix-primary bg-matrix-primary/10' 
          : 'border-gray-700/50 bg-gray-800/50'
      }`}
    >
      <div className="flex items-center space-x-3">
        <Award className={`w-6 h-6 ${unlocked ? 'text-matrix-primary' : 'text-gray-500'}`} />
        <div>
          <h4 className={`font-bold ${unlocked ? 'text-matrix-primary' : 'text-gray-400'}`}>
            {title}
          </h4>
          <p className="text-sm text-gray-400">{description}</p>
        </div>
      </div>
    </motion.div>
  );
};