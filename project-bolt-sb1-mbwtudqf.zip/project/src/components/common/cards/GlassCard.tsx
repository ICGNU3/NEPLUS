import React from 'react';
import { motion } from 'framer-motion';
import { hoverScale } from '../../../constants/animations';
import type { LayoutProps } from '../../../types/layout';

export const GlassCard = ({ children, className = '' }: LayoutProps) => {
  return (
    <motion.div
      {...hoverScale}
      className={`bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 
                 rounded-xl p-6 hover:border-matrix-primary/30 
                 transition-all duration-300 ${className}`}
    >
      {children}
    </motion.div>
  );
};