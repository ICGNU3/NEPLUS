import React from 'react';
import { motion } from 'framer-motion';
import { fadeInUp } from '../animations/variants';

interface SectionWrapperProps {
  children: React.ReactNode;
  id: string;
  className?: string;
}

export const SectionWrapper = ({ children, id, className = '' }: SectionWrapperProps) => {
  return (
    <motion.section
      id={id}
      {...fadeInUp}
      className={`min-h-screen py-24 px-4 relative ${className}`}
    >
      {children}
    </motion.section>
  );
};