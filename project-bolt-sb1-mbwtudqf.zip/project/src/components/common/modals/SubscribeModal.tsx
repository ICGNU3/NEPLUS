import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send } from 'lucide-react';
import { useNewsletter } from '../../../hooks/useNewsletter';
import { Toast } from '../Toast';

export const SubscribeModal = () => {
  const [email, setEmail] = useState('');
  const [showToast, setShowToast] = useState(false);
  const { isOpen, loading, error, subscribe, hideSubscribeModal } = useNewsletter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await subscribe(email);
    if (success) {
      setEmail('');
      setShowToast(true);
      setTimeout(() => {
        setShowToast(false);
        hideSubscribeModal();
      }, 2000);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-md p-6 bg-gray-800/90 rounded-xl border border-matrix-primary/30"
          >
            <button
              onClick={hideSubscribeModal}
              className="absolute top-4 right-4 text-gray-400 hover:text-matrix-primary"
            >
              <X className="w-6 h-6" />
            </button>

            <h2 className="text-2xl font-bold mb-6 text-center text-matrix-primary">
              Initialize Neural Link
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your neural interface ID"
                className="w-full px-4 py-2 bg-gray-700/50 border border-matrix-primary/30 
                         rounded-lg text-white focus:border-matrix-primary focus:ring-1 
                         focus:ring-matrix-primary outline-none"
                required
                disabled={loading}
              />

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center space-x-2 px-6 py-3 
                         bg-matrix-dark border border-matrix-primary text-matrix-primary 
                         rounded-lg hover:bg-matrix-primary/20 transition-all duration-300
                         disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
                <span>{loading ? 'Initializing...' : 'Initialize Connection'}</span>
              </button>

              {error && (
                <p className="text-red-500 text-sm text-center">{error}</p>
              )}
            </form>
          </motion.div>

          <Toast
            message="Neural link established successfully!"
            type="success"
            isVisible={showToast}
            onClose={() => setShowToast(false)}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
};