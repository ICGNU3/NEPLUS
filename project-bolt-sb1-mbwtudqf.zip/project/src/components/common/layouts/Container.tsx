import React from 'react';
import type { ContainerProps } from '../../../types/layout';

const maxWidthClasses = {
  sm: 'max-w-screen-sm',
  md: 'max-w-screen-md',
  lg: 'max-w-screen-lg',
  xl: 'max-w-screen-xl',
  '2xl': 'max-w-screen-2xl'
};

export const Container = ({ children, maxWidth = 'xl', className = '' }: ContainerProps) => {
  return (
    <div className={`mx-auto px-8 ${maxWidthClasses[maxWidth]} ${className}`}>
      {children}
    </div>
  );
};