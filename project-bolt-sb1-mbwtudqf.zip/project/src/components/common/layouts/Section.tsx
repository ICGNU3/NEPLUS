import React from 'react';
import { BaseSection } from './BaseSection';
import { Container } from './Container';
import type { SectionProps } from '../../../types/layout';

export const Section = ({ id, children, className = '' }: SectionProps) => {
  return (
    <BaseSection id={id} className={className}>
      <Container>
        {/* Add semantic HTML5 elements for better SEO */}
        <article role="article" aria-labelledby={`${id}-title`}>
          {children}
        </article>
      </Container>
    </BaseSection>
  );
};