import React from 'react';
import { motion } from 'framer-motion';
import { fadeInUp } from '../../../constants/animations';
import type { SectionProps } from '../../../types/layout';

export const BaseSection = ({ id, children, className = '' }: SectionProps) => {
  return (
    <motion.section
      id={id}
      {...fadeInUp}
      className={`min-h-screen py-24 relative ${className}`}
    >
      {children}
    </motion.section>
  );
};