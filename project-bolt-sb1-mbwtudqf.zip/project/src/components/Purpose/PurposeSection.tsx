import React from 'react';
import { Section } from '../common/Section';
import { SectionHeader } from '../common/SectionHeader';
import { PurposeCard } from './components/PurposeCard';
import { Rocket, Users, Sparkles } from 'lucide-react';

const PurposeSection = () => {
  return (
    <Section id="purpose" className="bg-gray-900">
      <SectionHeader
        title="Why NEPLUS?"
        subtitle="Empowering the next generation of Web3 founders to build, grow, and succeed. We're creating an ecosystem where innovation thrives and visionaries find their path to success."
      />

      <div className="grid md:grid-cols-3 gap-8">
        <PurposeCard
          icon={Rocket}
          title="Founder First"
          description="Supporting ambitious founders with the tools, resources, and connections they need to succeed in Web3."
          features={[
            "Access to funding opportunities",
            "Technical infrastructure",
            "Growth resources"
          ]}
        />
        
        <PurposeCard
          icon={Users}
          title="Network Effect"
          description="Building a powerful network of founders, mentors, and supporters to accelerate growth and innovation."
          features={[
            "Mentor matching",
            "Peer collaboration",
            "Industry connections"
          ]}
        />
        
        <PurposeCard
          icon={Sparkles}
          title="Market Impact"
          description="Creating pathways for innovative projects to find their market and achieve sustainable growth."
          features={[
            "Market access strategies",
            "Community building",
            "Growth frameworks"
          ]}
        />
      </div>
    </Section>
  );
};

export default PurposeSection;