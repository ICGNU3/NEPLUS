import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon, Check } from 'lucide-react';

interface PurposeCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  features: string[];
}

export const PurposeCard = ({ icon: Icon, title, description, features }: PurposeCardProps) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-gray-800 bg-opacity-50 rounded-xl p-6 border border-gray-700 hover:border-blue-500/50 transition-colors"
    >
      <div className="bg-blue-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
        <Icon className="w-6 h-6 text-blue-400" />
      </div>
      
      <h3 className="text-xl font-semibold text-white mb-3">{title}</h3>
      <p className="text-gray-300 mb-6">{description}</p>
      
      <ul className="space-y-2">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center text-gray-300">
            <Check className="w-4 h-4 text-blue-400 mr-2 flex-shrink-0" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </motion.div>
  );
};