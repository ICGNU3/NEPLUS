import React from 'react';
import { Share2 } from 'lucide-react';

interface ShareButtonProps {
  title: string;
  url: string;
}

export const ShareButton = ({ title, url }: ShareButtonProps) => {
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          url
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(url);
    }
  };

  return (
    <button
      onClick={handleShare}
      className="flex items-center space-x-2 px-4 py-2 rounded-lg
                 bg-matrix-dark border border-matrix-primary/30
                 hover:bg-matrix-primary/10 transition-colors"
    >
      <Share2 className="w-4 h-4 text-matrix-primary" />
      <span className="text-matrix-primary">Share</span>
    </button>
  );
};