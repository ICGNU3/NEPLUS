import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface HeroButtonProps {
  icon: LucideIcon;
  label: string;
  variant: 'primary' | 'secondary';
  onClick: () => void;
}

export const HeroButton = ({ icon: Icon, label, variant, onClick }: HeroButtonProps) => {
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        flex items-center space-x-2 px-8 py-3 rounded-full font-renaissance
        transition-all duration-300 transform matrix-border uppercase tracking-wider
        ${variant === 'primary' 
          ? 'bg-matrix-dark hover:bg-matrix-light text-matrix-primary' 
          : 'border-matrix-primary/50 text-matrix-primary hover:bg-matrix-dark/50'}
      `}
    >
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </motion.button>
  );
};