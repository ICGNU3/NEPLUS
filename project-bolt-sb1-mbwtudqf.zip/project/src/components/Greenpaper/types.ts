export interface GreenpaperSectionData {
  id: string;
  title: string;
  content: string[];
}