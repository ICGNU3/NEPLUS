import React from 'react';
import { motion } from 'framer-motion';
import { Container } from '../common/layouts/Container';

export const GreenpaperHero = () => {
  return (
    <section className="min-h-[60vh] flex items-center justify-center relative pt-24">
      <Container>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-6"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-matrix-primary">
            NEPLUS: THE MEMECOIN RESISTANCE
          </h1>
          <p className="text-xl md:text-2xl text-matrix-primary/80 max-w-3xl mx-auto italic">
            "Follow the White Rabbit and Recode Reality."
          </p>
        </motion.div>
      </Container>
    </section>
  );
};