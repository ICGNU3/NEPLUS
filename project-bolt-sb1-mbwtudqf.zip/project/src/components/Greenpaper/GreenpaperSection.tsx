import React from 'react';
import { motion } from 'framer-motion';
import type { GreenpaperSectionData } from './types';

interface Props extends GreenpaperSectionData {
  delay?: number;
}

export const GreenpaperSection = ({ title, content, delay = 0 }: Props) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="mb-16"
    >
      <h2 className="text-3xl font-bold text-matrix-primary mb-8 text-center">{title}</h2>
      <div className="space-y-6 text-matrix-primary/80">
        {content.map((paragraph, index) => (
          <p key={index} className="leading-relaxed text-center">
            {paragraph}
          </p>
        ))}
      </div>
    </motion.div>
  );
};