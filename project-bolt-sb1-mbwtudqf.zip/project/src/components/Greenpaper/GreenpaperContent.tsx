import React from 'react';
import { motion } from 'framer-motion';
import { Container } from '../common/layouts/Container';
import { GreenpaperSection } from './GreenpaperSection';
import { sections } from './data/sections';

export const GreenpaperContent = () => {
  return (
    <Container className="py-16 px-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="prose prose-invert max-w-4xl mx-auto text-center"
      >
        {sections.map((section, index) => (
          <GreenpaperSection
            key={section.id}
            {...section}
            delay={index * 0.1}
          />
        ))}
      </motion.div>
    </Container>
  );
};