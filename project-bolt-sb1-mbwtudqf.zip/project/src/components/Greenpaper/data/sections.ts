import type { GreenpaperSectionData } from '../types';

export const sections: GreenpaperSectionData[] = [
  {
    id: 'glitch',
    title: 'THE GLITCH',
    content: [
      'We live in a world where gatekeepers and outdated rules define what\'s "possible." Most people shuffle through life, unaware of the bars around them—oblivious to the illusions that prevent them from tapping into their true potential. But once you catch a glimpse of the glitch—once you sense that the matrix is flawed—you can\'t go back. You want to see how deep the rabbit hole goes.',
      'NEPLUS emerges as that anomaly in the system. It starts as a meme, something to laugh at—a random bit of code that shouldn\'t mean anything. But the glitch reveals itself as more than entertainment. It becomes a rallying cry for dreamers, creators, and renegades. It says, "Yes, the system is rigged, but we can rewrite the code."'
    ]
  },
  {
    id: 'reveal',
    title: 'THE MEMECOIN REVEAL',
    content: [
      'Forget talk of purely speculative tokens with no substance. NEPLUS channels the cheeky, viral power of memes into tangible, real-world outcomes. Where other memecoins might vanish with the next cycle of hype, NEPLUS thrives by embedding itself into actual collaborations—an encrypted handshake between internet culture and the offline world.',
      'It\'s a currency of freedom, minted in cyberspace but forging connections in the physical realm. Think of it as the green code cascading on your screen, but behind it are game studios, event organizers, and arts collectives who\'ve recognized that a so-called "joke coin" can evolve into a Trojan horse for sweeping change.'
    ]
  },
  {
    id: 'rabbit',
    title: 'FOLLOW THE WHITE RABBIT',
    content: [
      'This is the invitation: follow the White Rabbit to see the truth. The invitation can appear in many forms—a viral meme, a puzzle game, a cryptic tweet. Once you heed that call, you find yourself plugged into a vast community that believes the mind is the ultimate frontier.',
      'In the NEPLUS realm, no one is limited to the role they were assigned. Artists reinvent themselves as entrepreneurs. Gamers become cultural ambassadors. Local event planners transform into global orchestrators. And all of this is powered by NEPLUS—your digital key to a different reality.'
    ]
  },
  {
    id: 'network',
    title: 'THE RESISTANCE NETWORK',
    content: [
      'Where did this resistance come from? Picture an underground scene: developers in dimly lit rooms cracking lines of code, artists weaving new aesthetics in augmented reality, gamers forging alliances on the daily. Everyone is drawn by a shared intuition: we can do more than we were told. We can reshape the architecture around us.',
      'At the heart of this network lie partnerships—alliances forged with organizations that have real-world infrastructure and operational muscle. NEPLUS doesn\'t try to build every skyscraper, host every gala, or code every game alone. Instead, it sparks synergy between decentralized dreamers and established pros who know how to turn visions into real events, real art, and real projects.'
    ]
  },
  {
    id: 'source',
    title: 'THE SOURCE CODE',
    content: [
      'While the suits and cynics might dismiss memecoins as fleeting illusions, NEPLUS wields that illusion as a weapon. Meme culture has always had a habit of penetrating mainstream consciousness faster than any corporate ad campaign. If you can harness that velocity and anchor it with real collaborations, you get a feedback loop of hype and substance.',
      'So, NEPLUS becomes a key—one that unlocks event spaces, helps fund underground artists, props up micro-communities, or sponsors tournaments in the gaming underworld. Think of it as altering the base layer of society\'s code. Each project is a patch that corrects some glitch—like lack of funding for a local craft market or minimal representation for street artists. And with each patch, the matrix\'s illusions weaken.'
    ]
  },
  {
    id: 'operation',
    title: 'THE OPERATION',
    content: [
      'Members of the NEPLUS community move in plain sight. You might see them "shitposting" memes on social media, but behind the cheeky jokes lie core strategies for real collaboration. Deals are brokered in Discord servers, events are funded in group proposals, and entire subcultures unite around a single token powered by curiosity and passion.',
      'When a local festival needs sponsors, NEPLUS appears, bridging the gap between old-guard promoters and digital natives hungry for innovation. When a game dev studio seeks to tap into the unstoppable energy of meme-driven marketing, NEPLUS stands ready. And when underfunded artists cry out for a shred of hope, NEPLUS answers with community-led grants, minted in the swirl of irreverent memes that ironically feel more genuine than corporate lip service.'
    ]
  },
  {
    id: 'rules',
    title: 'BREAKING THE RULES',
    content: [
      'To question the system is an act of defiance. To rewrite its code is an act of liberation. NEPLUS dares to rewrite the rules of how people gather, how they celebrate culture, and how they support each other. It is both playful and subversive, respecting none of the boundaries that typical institutions might fear.',
      'In the matrix, you\'re told to stay in your lane—follow the lines of existing code. NEPLUS rejects that. It merges the intangible power of internet humor with real-world strategists who can execute ambitious initiatives. It invests in small-scale events one day, then cosigns a cross-country fundraiser for a humanitarian cause the next. The potential is only bounded by how fast the network expands.'
    ]
  },
  {
    id: 'liberation',
    title: 'THE LIBERATION',
    content: [
      'Each success story—an up-and-coming DJ who got discovered at a NEPLUS-backed event, a graffiti artist who gained exposure through a community-led gallery, a philanthropic drive that outperformed corporate campaigns—becomes another crack in the matrix. The illusions of "that\'s impossible" or "memecoins are worthless" fracture further as tangible outcomes appear in the real world.',
      'The liberation spreads when participants realize they\'re not alone. They see others hacking the frameworks of convention—pouring creativity into brand collaborations, forging unstoppable connections between online enthusiasm and offline progress. Bit by bit, the illusions collapse, replaced by the recognition that a meme can be more than a laugh; it can be a blueprint for collective agency.'
    ]
  },
  {
    id: 'journey',
    title: 'THE JOURNEY CONTINUES',
    content: [
      'Those who embrace NEPLUS don\'t just hold a token; they join a story. The White Rabbit flickers on your screen, urging you deeper into the labyrinth of possibility. You might enter as a curious onlooker, but the matrix has a way of exposing the illusions you once believed were unchangeable.',
      'Behind the memes, there is purpose. Behind the comedic veneer, there is a global conspiracy of hope. That conspiracy unites the disillusioned, the dreamers, and the fearless builders who see no reason why a memecoin can\'t empower a thousand events, a hundred philanthropic initiatives, and countless collaborations that overshadow stale, centralized norms.',
      'So you decide: take the step, follow the White Rabbit. Unplug from the lie that it\'s "just a meme." When you realize that code is malleable, that systems are illusions, and that laughter itself can break down walls—then you\'ll understand what NEPLUS is really about. It\'s not just a coin; it\'s a movement hidden in plain sight, rewriting reality with every glitch it introduces.',
      'There is no spoon—only NEPLUS.'
    ]
  }
];