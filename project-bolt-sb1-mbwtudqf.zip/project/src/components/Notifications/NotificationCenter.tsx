import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X } from 'lucide-react';
import { useNotifications } from '../../hooks/useNotifications';

export const NotificationCenter = () => {
  const { notifications, markAsRead, clearAll } = useNotifications();
  const [isOpen, setIsOpen] = React.useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-lg hover:bg-matrix-primary/10 transition-colors"
      >
        <Bell className="w-6 h-6 text-matrix-primary" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-matrix-primary 
                         rounded-full text-xs flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute right-0 mt-2 w-80 bg-gray-800/90 rounded-xl 
                     border border-matrix-primary/20 shadow-xl"
          >
            <div className="flex items-center justify-between p-4 border-b border-matrix-primary/20">
              <h3 className="font-bold text-matrix-primary">Notifications</h3>
              <button
                onClick={clearAll}
                className="text-sm text-matrix-primary/60 hover:text-matrix-primary"
              >
                Clear All
              </button>
            </div>

            <div className="max-h-96 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-4 text-center text-matrix-primary/60">
                  No notifications
                </div>
              ) : (
                notifications.map(notification => (
                  <div
                    key={notification.id}
                    className={`p-4 border-b border-matrix-primary/10 last:border-0
                              ${notification.read ? 'opacity-60' : ''}`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-matrix-primary">{notification.message}</p>
                        <p className="text-sm text-matrix-primary/60">
                          {new Date(notification.timestamp).toLocaleString()}
                        </p>
                      </div>
                      {!notification.read && (
                        <button
                          onClick={() => markAsRead(notification.id)}
                          className="p-1 hover:bg-matrix-primary/10 rounded"
                        >
                          <X className="w-4 h-4 text-matrix-primary" />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};