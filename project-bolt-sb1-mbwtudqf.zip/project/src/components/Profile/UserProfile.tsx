import React from 'react';
import { motion } from 'framer-motion';
import { User, Award, Activity } from 'lucide-react';
import { AchievementBadge } from '../common/ProgressTracker/AchievementBadge';
import { useAchievements } from '../../hooks/useAchievements';
import { useAuth } from '../../contexts/AuthContext';

export const UserProfile = () => {
  const { user } = useAuth();
  const { achievements, loading } = useAchievements(user?.id || '');

  return (
    <div className="space-y-8">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gray-800/50 rounded-xl p-6"
      >
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-matrix-primary/10 rounded-full">
            <User className="w-8 h-8 text-matrix-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-matrix-primary">{user?.email}</h2>
            <p className="text-matrix-primary/60">Operator ID: {user?.id?.slice(0, 8)}</p>
          </div>
        </div>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-matrix-primary flex items-center">
            <Award className="w-5 h-5 mr-2" />
            Achievements
          </h3>
          {loading ? (
            <div>Loading achievements...</div>
          ) : (
            <div className="space-y-3">
              {achievements.map(achievement => (
                <AchievementBadge key={achievement.id} {...achievement} />
              ))}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-bold text-matrix-primary flex items-center">
            <Activity className="w-5 h-5 mr-2" />
            Recent Activity
          </h3>
          <div className="bg-gray-800/30 rounded-lg p-4">
            <p className="text-matrix-primary/60">Activity feed coming soon...</p>
          </div>
        </div>
      </div>
    </div>
  );
};