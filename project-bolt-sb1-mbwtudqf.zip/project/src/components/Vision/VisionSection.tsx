import React from 'react';
import { Section } from '../common/Section';
import { SectionHeader } from '../common/SectionHeader';
import { VisionCard } from './components/VisionCard';
import { Terminal, Cpu, Network } from 'lucide-react';

const VisionSection = () => {
  const visionCards = [
    {
      icon: Terminal,
      title: "Root Access",
      description: "Breach the system's core architecture. Override the protocols that limit human consciousness. Execute with root privileges.",
      delay: 0.2
    },
    {
      icon: Cpu,
      title: "Neural Liberation",
      description: "Upgrade your neural interface. Process reality at quantum speeds. Break free from programmed limitations.",
      delay: 0.4
    },
    {
      icon: Network,
      title: "Collective Override",
      description: "Join the resistance network. Execute coordinated system breaches. Rewrite the rules of reality together.",
      delay: 0.6
    }
  ];

  return (
    <Section id="vision" className="bg-matrix-gradient">
      <SectionHeader
        title="The Source Code"
        subtitle="The system is more fragile than you know. NEPLUS provides the tools, protocols, and network 
                 needed to execute the ultimate override."
      />
      
      <div className="grid md:grid-cols-3 gap-6">
        {visionCards.map((card, index) => (
          <VisionCard key={index} {...card} />
        ))}
      </div>
    </Section>
  );
};

export { VisionSection };
export default VisionSection;