import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface VisionCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  delay?: number;
}

export const VisionCard = ({ icon: Icon, title, description, delay = 0 }: VisionCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
      whileHover={{ scale: 1.02 }}
      className="glass-panel rounded-xl p-6 relative overflow-hidden group hover-glow"
    >
      <div className="absolute inset-0 bg-matrix-gradient opacity-0 group-hover:opacity-10 transition-opacity duration-300" />
      <Icon className="w-12 h-12 text-matrix-primary mb-4 transform group-hover:scale-110 transition-transform duration-300" />
      <h3 className="text-xl font-bold mb-3 text-matrix-primary">{title}</h3>
      <p className="text-matrix-primary/70 leading-relaxed font-mono">
        {description}
      </p>
    </motion.div>
  );
};