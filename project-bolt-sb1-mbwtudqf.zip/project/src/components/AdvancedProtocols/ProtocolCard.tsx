import React from 'react';
import { motion } from 'framer-motion';
import { Lock, Check } from 'lucide-react';
import type { Protocol } from '../../types/protocols';

export const ProtocolCard = ({ 
  title, 
  description, 
  difficulty, 
  unlocked, 
  completed,
  icon: Icon 
}: Protocol) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className={`p-6 rounded-xl border ${
        unlocked 
          ? 'border-matrix-primary/30 bg-gray-800/50' 
          : 'border-gray-700/50 bg-gray-800/30'
      }`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="p-2 bg-matrix-primary/10 rounded-lg">
          <Icon className="w-6 h-6 text-matrix-primary" />
        </div>
        {!unlocked && (
          <Lock className="w-5 h-5 text-matrix-primary/40" />
        )}
        {completed && (
          <div className="p-1 bg-matrix-primary/20 rounded-full">
            <Check className="w-4 h-4 text-matrix-primary" />
          </div>
        )}
      </div>

      <h3 className="text-lg font-bold text-matrix-primary mb-2">{title}</h3>
      <p className="text-matrix-primary/60 text-sm mb-4">{description}</p>

      <div className="flex items-center justify-between">
        <span className={`text-sm ${
          difficulty === 'advanced' ? 'text-red-400' :
          difficulty === 'intermediate' ? 'text-yellow-400' :
          'text-green-400'
        }`}>
          {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
        </span>
        {unlocked && !completed && (
          <button className="text-sm text-matrix-primary hover:text-matrix-primary/80">
            Start Protocol
          </button>
        )}
      </div>
    </motion.div>
  );
};