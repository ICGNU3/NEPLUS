import React from 'react';
import { ProtocolHeader } from './components/ProtocolHeader';
import { ProtocolFilters } from './components/ProtocolFilters';
import { ProtocolList } from './components/ProtocolList';
import { AIProtocolSection } from './components/AIProtocolSection';
import { useProtocols } from '../../hooks/useProtocols';
import { useProtocolFilters } from '../../hooks/useProtocolFilters';

export const AdvancedProtocolsContent = () => {
  const { protocols, loading, error } = useProtocols();
  const {
    search,
    setSearch,
    difficulty,
    setDifficulty,
    showCompleted,
    setShowCompleted,
    filteredProtocols
  } = useProtocolFilters(protocols);

  return (
    <div className="space-y-12">
      <ProtocolHeader />
      
      <AIProtocolSection />
      
      <div className="space-y-8">
        <h2 className="text-2xl font-bold text-matrix-primary">Standard Protocols</h2>
        
        <ProtocolFilters
          search={search}
          onSearchChange={setSearch}
          difficulty={difficulty}
          onDifficultyChange={setDifficulty}
          showCompleted={showCompleted}
          onCompletedChange={setShowCompleted}
        />
        
        <ProtocolList 
          protocols={filteredProtocols} 
          loading={loading}
          error={error}
        />
      </div>
    </div>
  );
};