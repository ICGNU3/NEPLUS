import React from 'react';
import { ProgressBar } from '../../common/Progress/ProgressBar';
import { useProgress } from '../../../hooks/useProgress';
import { useAuth } from '../../../contexts/AuthContext';

export const ProtocolMetrics = () => {
  const { user } = useAuth();
  const { progress } = useProgress(user?.id || '');
  
  return (
    <div className="space-y-4">
      <h2 className="text-lg font-bold text-matrix-primary">Protocol Metrics</h2>
      <div className="space-y-6">
        <ProgressBar 
          progress={progress.completedProtocols.length} 
          total={12} 
          label="Protocols Completed" 
        />
        <ProgressBar 
          progress={Math.round(progress.successRate * 100)} 
          total={100} 
          label="Success Rate" 
        />
      </div>
    </div>
  );
};