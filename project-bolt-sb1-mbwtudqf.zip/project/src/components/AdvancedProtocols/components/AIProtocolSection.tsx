import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Cpu, Network } from 'lucide-react';
import { useAuth } from '../../../contexts/AuthContext';
import { useProtocolProgress } from '../../../hooks/useProtocolProgress';

const aiFeatures = [
  {
    icon: Brain,
    title: 'Neural Network Training',
    description: 'Train your neural pathways using advanced AI algorithms. Adapt and evolve your consciousness.',
    status: 'active'
  },
  {
    icon: Cpu,
    title: 'AI Protocol Generation',
    description: 'Dynamically generate custom protocols based on your performance and learning patterns.',
    status: 'coming-soon'
  },
  {
    icon: Network,
    title: 'Adaptive Learning System',
    description: 'AI-powered system that evolves with you, adjusting difficulty and challenges in real-time.',
    status: 'experimental'
  }
];

export const AIProtocolSection = () => {
  const { user } = useAuth();
  const { progress } = useProtocolProgress('ai-training', user?.id || '');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-matrix-primary">AI Protocols</h2>
        <span className="text-matrix-primary/60">System Status: Online</span>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {aiFeatures.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-6 rounded-xl border border-matrix-primary/30 bg-gray-800/50"
            >
              <div className="p-2 bg-matrix-primary/10 rounded-lg w-fit mb-4">
                <Icon className="w-6 h-6 text-matrix-primary" />
              </div>
              <h3 className="text-lg font-bold text-matrix-primary mb-2">{feature.title}</h3>
              <p className="text-matrix-primary/60 text-sm mb-4">{feature.description}</p>
              <div className="flex items-center justify-between">
                <span className={`text-sm ${
                  feature.status === 'active' ? 'text-green-400' :
                  feature.status === 'coming-soon' ? 'text-yellow-400' :
                  'text-blue-400'
                }`}>
                  {feature.status.split('-').map(word => 
                    word.charAt(0).toUpperCase() + word.slice(1)
                  ).join(' ')}
                </span>
                {feature.status === 'active' && (
                  <button className="text-sm text-matrix-primary hover:text-matrix-primary/80">
                    Initialize
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};