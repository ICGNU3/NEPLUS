import React from 'react';
import { Search, Filter } from 'lucide-react';

interface ProtocolFiltersProps {
  search: string;
  onSearchChange: (value: string) => void;
  difficulty: string;
  onDifficultyChange: (value: string) => void;
  showCompleted: boolean;
  onCompletedChange: (value: boolean) => void;
}

export const ProtocolFilters = ({
  search,
  onSearchChange,
  difficulty,
  onDifficultyChange,
  showCompleted,
  onCompletedChange
}: ProtocolFiltersProps) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-matrix-primary/40" />
          <input
            type="text"
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search protocols..."
            className="w-full pl-10 pr-4 py-2 bg-gray-800/50 rounded-lg
                     border border-matrix-primary/30 text-matrix-primary
                     placeholder:text-matrix-primary/40 focus:border-matrix-primary"
          />
        </div>
        
        <select
          value={difficulty}
          onChange={(e) => onDifficultyChange(e.target.value)}
          className="px-4 py-2 bg-gray-800/50 rounded-lg
                   border border-matrix-primary/30 text-matrix-primary
                   focus:border-matrix-primary"
        >
          <option value="">All Difficulties</option>
          <option value="basic">Basic</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
        </select>
      </div>

      <div className="flex items-center space-x-4">
        <label className="flex items-center space-x-2 text-matrix-primary/80">
          <input
            type="checkbox"
            checked={showCompleted}
            onChange={(e) => onCompletedChange(e.target.checked)}
            className="rounded border-matrix-primary/30 bg-gray-800/50
                     text-matrix-primary focus:ring-matrix-primary"
          />
          <span>Show Completed</span>
        </label>
      </div>
    </div>
  );
};