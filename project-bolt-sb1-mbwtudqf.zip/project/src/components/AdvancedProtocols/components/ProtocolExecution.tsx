import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Terminal, Check, AlertCircle } from 'lucide-react';
import { LoadingDots } from '../../common/LoadingStates/LoadingDots';

interface ProtocolExecutionProps {
  protocolId: string;
  onComplete: (success: boolean) => void;
}

export const ProtocolExecution = ({ protocolId, onComplete }: ProtocolExecutionProps) => {
  const [command, setCommand] = useState('');
  const [output, setOutput] = useState<string[]>([]);
  const [executing, setExecuting] = useState(false);

  const handleExecute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim() || executing) return;

    setExecuting(true);
    setOutput(prev => [...prev, `> ${command}`]);

    // Simulate protocol execution
    await new Promise(resolve => setTimeout(resolve, 2000));

    const success = command.toLowerCase().includes('execute') && 
                   command.toLowerCase().includes(protocolId);

    setOutput(prev => [
      ...prev,
      success ? 'Protocol executed successfully.' : 'Protocol execution failed.',
      success ? 'System access granted.' : 'Access denied. Try again.'
    ]);

    setExecuting(false);
    if (success) {
      onComplete(true);
    }
  };

  return (
    <div className="bg-gray-900/50 rounded-xl border border-matrix-primary/30 p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Terminal className="w-5 h-5 text-matrix-primary" />
        <h3 className="text-lg font-bold text-matrix-primary">Protocol Terminal</h3>
      </div>

      <div className="font-mono space-y-2 mb-4 h-48 overflow-y-auto">
        {output.map((line, i) => (
          <div key={i} className="text-matrix-primary/80">{line}</div>
        ))}
        {executing && <LoadingDots />}
      </div>

      <form onSubmit={handleExecute} className="flex space-x-2">
        <input
          type="text"
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          placeholder="Enter command..."
          className="flex-1 bg-gray-800/50 rounded-lg px-4 py-2
                   border border-matrix-primary/30 text-matrix-primary
                   focus:border-matrix-primary"
          disabled={executing}
        />
        <button
          type="submit"
          disabled={executing}
          className="px-4 py-2 bg-matrix-primary/10 rounded-lg
                   border border-matrix-primary/30 text-matrix-primary
                   hover:bg-matrix-primary/20 disabled:opacity-50"
        >
          Execute
        </button>
      </form>
    </div>
  );
};