import React from 'react';
import { Breadcrumbs } from '../../common/Navigation/Breadcrumbs';

export const ProtocolHeader = () => {
  const breadcrumbItems = [
    { label: 'Command Center', href: '/command-center' },
    { label: 'Advanced Protocols' }
  ];

  return (
    <header className="space-y-4">
      <Breadcrumbs items={breadcrumbItems} />
      <h1 className="text-4xl font-bold text-matrix-primary">Advanced Protocols</h1>
      <p className="text-matrix-primary/80 max-w-2xl">
        Master system override sequences and advanced reality manipulation techniques. 
        Complete each protocol to unlock deeper levels of system access.
      </p>
    </header>
  );
};