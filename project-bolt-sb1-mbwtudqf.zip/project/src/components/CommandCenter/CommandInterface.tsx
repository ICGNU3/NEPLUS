import React from 'react';
import { Terminal } from '../CommandCenter/Terminal';
import { TrainingModules } from '../CommandCenter/TrainingModules';
import { SystemStatus } from '../CommandCenter/SystemStatus';

export const CommandInterface = () => {
  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold text-matrix-primary mb-4">Command Center</h1>
        <p className="text-matrix-primary/80 max-w-2xl mx-auto">
          Access advanced training protocols and system manipulation tools. Learn to bend reality to your will.
        </p>
      </header>
      
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Terminal />
        </div>
        <div className="space-y-6">
          <SystemStatus />
          <TrainingModules />
        </div>
      </div>
    </div>
  );
};