import React from 'react';
import { motion } from 'framer-motion';
import { Activity, Signal, Shield, Zap } from 'lucide-react';

export const SystemStatus = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg p-4"
    >
      <h2 className="text-lg font-bold text-matrix-primary mb-4">System Status</h2>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-matrix-primary" />
            <span className="text-matrix-primary/80">System Health</span>
          </div>
          <span className="text-matrix-primary">98%</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Signal className="w-4 h-4 text-matrix-primary" />
            <span className="text-matrix-primary/80">Network Status</span>
          </div>
          <span className="text-matrix-primary">ONLINE</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-matrix-primary" />
            <span className="text-matrix-primary/80">Security Level</span>
          </div>
          <span className="text-matrix-primary">ALPHA</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-matrix-primary" />
            <span className="text-matrix-primary/80">Power Output</span>
          </div>
          <span className="text-matrix-primary">1.21 GW</span>
        </div>
      </div>
    </motion.div>
  );
};