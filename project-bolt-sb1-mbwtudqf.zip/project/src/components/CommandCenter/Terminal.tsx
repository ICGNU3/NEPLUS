import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Terminal as TerminalIcon, Send } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const Terminal = () => {
  const [command, setCommand] = useState('');
  const [output, setOutput] = useState<string[]>([
    'Main Terminal v1.0',
    'Type "help" for available commands',
    '> _'
  ]);

  const navigate = useNavigate();

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim()) return;

    const newOutput = [...output];
    newOutput.pop(); // Remove the cursor
    newOutput.push(`> ${command}`);
    
    // Add command response
    switch (command.toLowerCase()) {
      case 'help':
        newOutput.push(
          'Available commands:',
          '  status    - Check system status',
          '  train     - Access training modules',
          '  advanced  - Access advanced protocols',
          '  clear     - Clear terminal',
          '  exit      - Return to matrix'
        );
        break;
      case 'status':
        newOutput.push('System Status: OPERATIONAL', 'Reality Manipulation: ENABLED');
        break;
      case 'train':
        newOutput.push('Initializing training protocols...');
        setTimeout(() => navigate('/basic-training'), 1000);
        break;
      case 'advanced':
        newOutput.push('Accessing advanced protocols...');
        setTimeout(() => navigate('/advanced-protocols'), 1000);
        break;
      case 'clear':
        setOutput(['Main Terminal v1.0', '> _']);
        setCommand('');
        return;
      case 'exit':
        newOutput.push('Returning to matrix...');
        setTimeout(() => navigate('/'), 1000);
        break;
      default:
        newOutput.push('Command not recognized. Type "help" for available commands.');
    }
    
    newOutput.push('> _'); // Add back the cursor
    setOutput(newOutput);
    setCommand('');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg p-4 h-[500px] flex flex-col"
    >
      <div className="flex items-center space-x-2 mb-4 px-2">
        <TerminalIcon className="w-5 h-5 text-matrix-primary" />
        <span className="text-matrix-primary font-mono">Main Terminal</span>
      </div>
      
      <div className="flex-1 overflow-auto font-mono text-sm space-y-1 mb-4">
        {output.map((line, i) => (
          <div key={i} className="text-matrix-primary whitespace-pre-wrap">{line}</div>
        ))}
      </div>

      <form onSubmit={handleCommand} className="flex items-center space-x-2">
        <input
          type="text"
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          className="flex-1 bg-transparent border border-matrix-primary/30 rounded px-3 py-2 text-matrix-primary font-mono focus:outline-none focus:border-matrix-primary"
          placeholder="Enter command..."
          autoFocus
        />
        <button
          type="submit"
          className="p-2 bg-matrix-primary/10 border border-matrix-primary/30 rounded hover:bg-matrix-primary/20 transition-colors"
        >
          <Send className="w-5 h-5 text-matrix-primary" />
        </button>
      </form>
    </motion.div>
  );
};