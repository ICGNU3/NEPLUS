import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Code, Network, Cpu } from 'lucide-react';
import { Link } from 'react-router-dom';

const modules = [
  {
    icon: BookOpen,
    title: 'Basic Training',
    description: 'Learn fundamental reality manipulation techniques',
    href: '/basic-training'
  },
  {
    icon: Code,
    title: 'Advanced Protocols',
    description: 'Master system override sequences',
    href: '/advanced-protocols'
  },
  {
    icon: Network,
    title: 'Network Operations',
    description: 'Connect with the resistance network',
    href: '#'
  },
  {
    icon: Cpu,
    title: 'Core Systems',
    description: 'Access deep matrix architecture',
    href: '#'
  }
];

export const TrainingModules = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/30 rounded-lg p-4"
    >
      <h2 className="text-lg font-bold text-matrix-primary mb-4">Training Modules</h2>
      <div className="space-y-3">
        {modules.map(({ icon: Icon, title, description, href }, index) => (
          <Link
            key={index}
            to={href}
            className="block w-full"
          >
            <motion.div
              whileHover={{ x: 5 }}
              className="flex items-start space-x-3 p-3 rounded-lg hover:bg-matrix-primary/10 transition-colors text-left"
            >
              <Icon className="w-5 h-5 text-matrix-primary mt-0.5" />
              <div>
                <div className="font-medium text-matrix-primary">{title}</div>
                <div className="text-sm text-matrix-primary/70">{description}</div>
              </div>
            </motion.div>
          </Link>
        ))}
      </div>
    </motion.div>
  );
};