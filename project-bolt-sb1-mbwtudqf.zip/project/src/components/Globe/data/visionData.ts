import { Palette, Users, Sparkles } from 'lucide-react';

export const visionCards = [
  {
    icon: Palette,
    title: "Creator Support",
    description: "Daily office hours, resources, and tools to help creators build and grow"
  },
  {
    icon: Users,
    title: "Connections",
    description: "Connect with mentors, peers, and supporters in our global creative network"
  },
  {
    icon: Sparkles,
    title: "Cultural Impact",
    description: "Shape the future of digital culture through innovation and collaboration"
  }
];