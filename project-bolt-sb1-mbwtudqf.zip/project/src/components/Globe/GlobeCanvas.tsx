import React, { useEffect, useRef } from 'react';
import { useGlobeAnimation } from './useGlobeAnimation';

const GlobeCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { initGlobe } = useGlobeAnimation();

  useEffect(() => {
    if (!canvasRef.current) return;
    initGlobe(canvasRef.current);
  }, [initGlobe]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full opacity-80"
      style={{ filter: 'blur(1px)' }}
    />
  );
};

export default GlobeCanvas;