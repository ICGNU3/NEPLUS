import React from 'react';
import { LucideIcon } from 'lucide-react';

interface VisionCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

export const VisionCard = ({ icon: Icon, title, description }: VisionCardProps) => (
  <div className="bg-gray-800 bg-opacity-50 p-6 rounded-xl transform hover:scale-105 transition-transform">
    <div className="flex items-center justify-center mb-4">
      <Icon className="w-8 h-8 text-blue-400" />
    </div>
    <h3 className="text-xl font-semibold mb-2 text-white">{title}</h3>
    <p className="text-gray-300 text-sm">{description}</p>
  </div>
);