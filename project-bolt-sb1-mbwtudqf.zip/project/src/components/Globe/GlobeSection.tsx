import React from 'react';
import GlobeCanvas from './GlobeCanvas';
import { VisionCard } from './components/VisionCard';
import { visionCards } from './data/visionData';

export const GlobeSection = () => {
  return (
    <div className="relative h-screen bg-gray-900">
      <GlobeCanvas />
      <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4">
        <div className="bg-gray-800 bg-opacity-50 backdrop-blur-lg p-8 rounded-2xl max-w-3xl">
          <h2 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
            The Vision
          </h2>
          <p className="text-lg text-gray-300 mb-8">
            NEPLUS empowers creators and innovators through comprehensive support, resources, and connections. 
            We're building a renaissance of digital culture where creativity thrives and visionaries succeed.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {visionCards.map((card, index) => (
              <VisionCard key={index} {...card} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GlobeSection;