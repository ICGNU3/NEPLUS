import React from 'react';
import { motion } from 'framer-motion';
import type { RoadmapPhaseData } from '../types';

const RoadmapPhase: React.FC<RoadmapPhaseData> = ({ 
  icon: Icon, 
  phase, 
  items 
}) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-xl p-5 hover:border-matrix-primary/30 transition-all duration-300"
    >
      <div className="flex items-center mb-3">
        <div className="bg-matrix-primary/10 p-2.5 rounded-lg mr-3">
          <Icon className="w-5 h-5 text-matrix-primary" />
        </div>
        <h3 className="text-lg font-bold text-matrix-primary">{phase}</h3>
      </div>
      <ul className="space-y-2 ml-3">
        {items.map((item, index) => (
          <motion.li
            key={index}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="text-matrix-primary/80 flex items-center space-x-2 font-mono text-sm"
          >
            <span className="text-matrix-primary">•</span>
            <span>{item}</span>
          </motion.li>
        ))}
      </ul>
    </motion.div>
  );
};

export { RoadmapPhase };
export default RoadmapPhase;