import React from 'react';
import { Section } from '../common/Section';
import { SectionHeader } from '../common/SectionHeader';
import { RoadmapPhase } from './components/RoadmapPhase';
import { roadmapPhases } from './data/roadmapPhases';

const RoadmapSection = () => {
  return (
    <Section id="roadmap" className="bg-matrix-dark">
      <div className="max-w-5xl mx-auto">
        <SectionHeader 
          title="System Override Protocol" 
          subtitle="The path to liberation is coded in truth. Each phase unlocks new capabilities in the war against control systems."
        />
        <div className="space-y-6">
          {roadmapPhases.map((phase) => (
            <RoadmapPhase
              key={phase.id}
              {...phase}
            />
          ))}
        </div>
      </div>
    </Section>
  );
};

export { RoadmapSection };
export default RoadmapSection;