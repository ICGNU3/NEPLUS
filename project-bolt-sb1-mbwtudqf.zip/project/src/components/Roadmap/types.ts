```typescript
import { LucideIcon } from 'lucide-react';

export interface RoadmapPhaseData {
  id: string;
  icon: LucideIcon;
  phase: string;
  items: string[];
}
```