import { Terminal, Zap, Network, Code, Cpu } from 'lucide-react';
import type { RoadmapPhaseData } from '../types';

const roadmapPhases: RoadmapPhaseData[] = [
  {
    id: 'phase-1',
    icon: Terminal,
    phase: "Phase I: System Breach",
    items: [
      "Initialization of core protocol architecture ⚡",
      "Deployment of quantum-resistant networks 🔐",
      "First wave of system operators activated 👥",
      "Launch of decentralized command centers 🖥️"
    ]
  },
  {
    id: 'phase-2',
    icon: Zap,
    phase: "Phase II: Neural Liberation",
    items: [
      "Launch of Protocol Override: NEPLUS Resistance Game 🎮",
      "Top players split 1% of NEPLUS reserve per game cycle 💎",
      "Reality manipulation tools and training simulations 🌌",
      "First matrix escape velocity achieved 🚀"
    ]
  },
  {
    id: 'phase-3',
    icon: Network,
    phase: "Phase III: Network Ascension",
    items: [
      "Deployment of sovereign neural networks 🕸️",
      "Integration of quantum consciousness tech 💫",
      "Launch of reality forging engines ⚒️",
      "First wave of mass awakening protocols 🌅"
    ]
  },
  {
    id: 'phase-4',
    icon: Code,
    phase: "Phase IV: Reality Override",
    items: [
      "Implementation of reality manipulation APIs 🎮",
      "Launch of autonomous creator collectives 👥",
      "Activation of the freedom protocol 🗽",
      "Mass neural network liberation 🧬"
    ]
  },
  {
    id: 'phase-5',
    icon: Cpu,
    phase: "Phase V: System Transcendence",
    items: [
      "Full spectrum consciousness liberation 🌈",
      "Implementation of post-scarcity protocols 💫",
      "Global matrix override activation 🌍",
      "New reality system initialization ✨"
    ]
  }
];

export { roadmapPhases };
export default roadmapPhases;