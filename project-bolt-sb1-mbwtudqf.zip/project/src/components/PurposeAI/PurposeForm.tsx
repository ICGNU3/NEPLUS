import React, { useState } from 'react';
import { BirthData, UserPreferences, UserValues, LifeGoals } from '../../types/purpose';
import { GradientButton } from '../common/GradientButton';
import { Brain } from 'lucide-react';

interface PurposeFormProps {
  onSubmit: (data: {
    birthData: BirthData;
    preferences: UserPreferences;
    values: UserValues;
    goals: LifeGoals;
  }) => void;
}

export const PurposeForm = ({ onSubmit }: PurposeFormProps) => {
  const [birthData, setBirthData] = useState<BirthData>({
    date: '',
    time: '',
    location: ''
  });

  const [preferences, setPreferences] = useState<UserPreferences>({
    interests: [],
    passions: [],
    challenges: []
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      birthData,
      preferences,
      values: {
        personal: [],
        professional: [],
        social: []
      },
      goals: {
        shortTerm: [],
        longTerm: []
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-white">Birth Information</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <input
            type="date"
            value={birthData.date}
            onChange={(e) => setBirthData({ ...birthData, date: e.target.value })}
            className="bg-gray-800 rounded-lg px-4 py-2 text-white"
            required
          />
          <input
            type="time"
            value={birthData.time}
            onChange={(e) => setBirthData({ ...birthData, time: e.target.value })}
            className="bg-gray-800 rounded-lg px-4 py-2 text-white"
            required
          />
          <input
            type="text"
            value={birthData.location}
            onChange={(e) => setBirthData({ ...birthData, location: e.target.value })}
            placeholder="Birth Location"
            className="bg-gray-800 rounded-lg px-4 py-2 text-white"
            required
          />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-white">Personal Insights</h3>
        <div className="space-y-4">
          <textarea
            value={preferences.interests.join(', ')}
            onChange={(e) => setPreferences({
              ...preferences,
              interests: e.target.value.split(',').map(s => s.trim())
            })}
            placeholder="What are your interests? (comma-separated)"
            className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white"
            rows={3}
            required
          />
          <textarea
            value={preferences.passions.join(', ')}
            onChange={(e) => setPreferences({
              ...preferences,
              passions: e.target.value.split(',').map(s => s.trim())
            })}
            placeholder="What are you passionate about? (comma-separated)"
            className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white"
            rows={3}
            required
          />
        </div>
      </div>

      <div className="flex justify-center">
        <GradientButton
          icon={Brain}
          label="Generate Purpose Map"
          onClick={() => {}}
          size="lg"
        />
      </div>
    </form>
  );
};