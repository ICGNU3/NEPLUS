import React from 'react';
import { Section } from '../common/Section';
import { SectionHeader } from '../common/SectionHeader';
import { PurposeForm } from './PurposeForm';
import { PurposeMap } from './PurposeMap';
import { usePurposeAI } from '../../hooks/usePurposeAI';
import { LoadingSpinner } from '../common/LoadingSpinner';

const PurposeAISection = () => {
  const { loading, purposeMap, generateInsights } = usePurposeAI();

  return (
    <Section id="purpose-ai" className="bg-gray-900">
      <SectionHeader
        title="Discover Your Purpose"
        subtitle="Our AI-powered system combines ancient wisdom with modern insights to help you uncover your true purpose."
      />

      {loading ? (
        <LoadingSpinner />
      ) : purposeMap ? (
        <PurposeMap purposeMap={purposeMap} />
      ) : (
        <PurposeForm onSubmit={generateInsights} />
      )}
    </Section>
  );
};

export default PurposeAISection;