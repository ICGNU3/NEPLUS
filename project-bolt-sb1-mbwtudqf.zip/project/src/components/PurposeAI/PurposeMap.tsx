import React from 'react';
import { motion } from 'framer-motion';
import { PurposeMap as PurposeMapType } from '../../types/purpose';

interface PurposeMapProps {
  purposeMap: PurposeMapType;
}

export const PurposeMap = ({ purposeMap }: PurposeMapProps) => {
  return (
    <div className="grid md:grid-cols-2 gap-8">
      {Object.entries(purposeMap).map(([key, insights]) => (
        <motion.div
          key={key}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-800 bg-opacity-50 rounded-xl p-6"
        >
          <h3 className="text-xl font-semibold mb-4 capitalize">
            {key.replace(/([A-Z])/g, ' $1').trim()}
          </h3>
          <div className="space-y-4">
            {insights.map((insight, index) => (
              <div key={index} className="space-y-2">
                <p className="text-gray-300">{insight.insight}</p>
                <p className="text-blue-400 text-sm">{insight.suggestion}</p>
              </div>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  );
};