import React from 'react';
import { TrendingUp, TrendingDown, Volume2, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatPrice, formatPercentage, formatVolume } from '../../../utils/formatters';
import type { TickerData } from '../../../types/ticker';

interface TickerItemProps {
  token: TickerData;
}

export const TickerItem = ({ token }: TickerItemProps) => {
  if (!token) return null;

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      whileHover={{ scale: 1.05, backgroundColor: 'rgba(0, 255, 65, 0.1)' }}
      className="flex items-center space-x-4 px-8 border-r border-matrix-primary/30 cursor-pointer h-12"
      onClick={() => window.open(`https://www.coingecko.com/en/coins/${token.id}`, '_blank')}
    >
      <div className="flex items-center space-x-2">
        <Zap className="w-4 h-4 text-matrix-primary" />
        <span className="font-bold text-matrix-primary tracking-wider">
          {token.symbol}
        </span>
      </div>
      <span className="font-mono text-white tracking-wider">
        {formatPrice(token.price)}
      </span>
      <span className={`flex items-center space-x-1 ${
        token.priceChange >= 0 
          ? 'text-[#39ff14]' 
          : 'text-red-500'
      }`}>
        {token.priceChange >= 0 ? (
          <TrendingUp className="w-4 h-4" />
        ) : (
          <TrendingDown className="w-4 h-4" />
        )}
        <span>{formatPercentage(token.priceChange)}</span>
      </span>
      <span className="flex items-center space-x-1 text-matrix-primary/80">
        <Volume2 className="w-4 h-4" />
        <span>{formatVolume(token.volume)}</span>
      </span>
    </motion.div>
  );
};