export class MatrixRain {
  private fontSize: number = 14;
  private drops: number[] = [];
  private symbols: string[];

  constructor() {
    this.symbols = Array.from("ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%");
  }

  initialize(width: number, height: number) {
    const columns = Math.floor(width / this.fontSize);
    this.drops = new Array(columns).fill(1);
  }

  draw(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.fillStyle = "rgba(12, 23, 20, 0.05)";
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = "#00ff41";
    ctx.font = `${this.fontSize}px monospace`;

    for (let i = 0; i < this.drops.length; i++) {
      const symbol = this.symbols[Math.floor(Math.random() * this.symbols.length)];
      const x = i * this.fontSize;
      const y = this.drops[i] * this.fontSize;
      
      // Add glow effect
      ctx.shadowColor = "#00ff41";
      ctx.shadowBlur = 10;
      ctx.fillText(symbol, x, y);
      ctx.shadowBlur = 0;

      if (y > height && Math.random() > 0.975) {
        this.drops[i] = 0;
      }
      this.drops[i]++;
    }
  }
}