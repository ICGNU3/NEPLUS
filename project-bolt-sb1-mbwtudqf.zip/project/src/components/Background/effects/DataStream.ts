export class DataStream {
  private streams: {
    x: number;
    y: number;
    speed: number;
    length: number;
    opacity: number;
  }[] = [];

  constructor(private numStreams = 50) {
    this.initializeStreams();
  }

  private initializeStreams() {
    this.streams = Array.from({ length: this.numStreams }, () => ({
      x: Math.random(),
      y: Math.random(),
      speed: Math.random() * 2 + 1,
      length: Math.random() * 0.2 + 0.1,
      opacity: Math.random() * 0.5 + 0.1
    }));
  }

  draw(ctx: CanvasRenderingContext2D, width: number, height: number) {
    this.streams.forEach(stream => {
      const gradient = ctx.createLinearGradient(
        stream.x * width,
        stream.y * height,
        stream.x * width,
        (stream.y + stream.length) * height
      );

      gradient.addColorStop(0, `rgba(0, 255, 65, ${stream.opacity})`);
      gradient.addColorStop(1, 'rgba(0, 255, 65, 0)');

      ctx.beginPath();
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 1;
      ctx.moveTo(stream.x * width, stream.y * height);
      ctx.lineTo(stream.x * width, (stream.y + stream.length) * height);
      ctx.stroke();

      // Update stream position
      stream.y += stream.speed * 0.001;

      // Reset stream when it goes off screen
      if (stream.y > 1) {
        stream.y = -stream.length;
        stream.x = Math.random();
      }
    });
  }
}