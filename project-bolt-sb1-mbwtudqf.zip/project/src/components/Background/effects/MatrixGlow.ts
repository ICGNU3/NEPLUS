export class MatrixGlow {
  private glowPoints: { x: number; y: number; intensity: number; }[] = [];
  private maxPoints = 5;

  constructor() {
    for (let i = 0; i < this.maxPoints; i++) {
      this.glowPoints.push({
        x: Math.random(),
        y: Math.random(),
        intensity: Math.random()
      });
    }
  }

  draw(ctx: CanvasRenderingContext2D, width: number, height: number) {
    this.glowPoints.forEach(point => {
      const gradient = ctx.createRadialGradient(
        point.x * width,
        point.y * height,
        0,
        point.x * width,
        point.y * height,
        Math.min(width, height) * 0.4
      );

      gradient.addColorStop(0, `rgba(0, 255, 65, ${0.1 * point.intensity})`);
      gradient.addColorStop(1, 'rgba(0, 255, 65, 0)');

      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Update point position
      point.x += (Math.random() - 0.5) * 0.001;
      point.y += (Math.random() - 0.5) * 0.001;
      point.intensity = Math.sin(Date.now() * 0.001) * 0.5 + 0.5;

      // Keep points within bounds
      point.x = Math.max(0, Math.min(1, point.x));
      point.y = Math.max(0, Math.min(1, point.y));
    });
  }
}