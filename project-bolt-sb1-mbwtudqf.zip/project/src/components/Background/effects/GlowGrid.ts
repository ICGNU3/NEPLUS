export class GlowGrid {
  private gridSize: number = 50;
  private glowIntensity: number = 0;
  private increasing: boolean = true;

  draw(ctx: CanvasRenderingContext2D, width: number, height: number) {
    // Update glow intensity
    if (this.increasing) {
      this.glowIntensity += 0.01;
      if (this.glowIntensity >= 1) this.increasing = false;
    } else {
      this.glowIntensity -= 0.01;
      if (this.glowIntensity <= 0.3) this.increasing = true;
    }

    // Draw vertical lines
    for (let x = 0; x <= width; x += this.gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.strokeStyle = `rgba(0, 255, 65, ${0.1 * this.glowIntensity})`;
      ctx.stroke();
    }

    // Draw horizontal lines
    for (let y = 0; y <= height; y += this.gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.strokeStyle = `rgba(0, 255, 65, ${0.1 * this.glowIntensity})`;
      ctx.stroke();
    }
  }
}