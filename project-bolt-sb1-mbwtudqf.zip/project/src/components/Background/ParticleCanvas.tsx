import React, { useEffect, useRef, useState } from 'react';
import { useParticleSystem } from './hooks/useParticleSystem';
import { useBackgroundEffects } from './hooks/useBackgroundEffects';
import { useCanvasSetup } from './hooks/useCanvasSetup';
import { useFrameTime } from './hooks/useFrameTime';
import { MousePosition } from './types';

export const ParticleCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { createParticles, updateParticle } = useParticleSystem();
  const { initializeEffects, renderEffects } = useBackgroundEffects();
  const { setupCanvas } = useCanvasSetup();
  const { getDeltaTime } = useFrameTime();
  const [mousePos, setMousePos] = useState<MousePosition>({ x: 0, y: 0 });
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const setup = setupCanvas(canvas, setMousePos);
    if (!setup) return;

    const { ctx, cleanup } = setup;
    const effects = initializeEffects();
    let particles = createParticles(canvas.width, canvas.height);
    let animationFrameId: number;

    const render = (currentTime: number) => {
      const deltaTime = getDeltaTime(currentTime);
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Render background effects
      renderEffects(ctx, canvas.width, canvas.height, effects);

      // Update and render particles
      particles.forEach(particle => {
        updateParticle(particle, canvas.width, canvas.height, mousePos, deltaTime);

        ctx.shadowColor = particle.color;
        ctx.shadowBlur = 15;
        
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `${particle.color}${Math.floor(particle.alpha * 255).toString(16).padStart(2, '0')}`;
        ctx.fill();
        
        ctx.shadowBlur = 0;
      });

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cleanup();
      cancelAnimationFrame(animationFrameId);
    };
  }, [createParticles, updateParticle, initializeEffects, renderEffects, setupCanvas, getDeltaTime]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full"
      style={{ zIndex: -1 }}
    />
  );
};