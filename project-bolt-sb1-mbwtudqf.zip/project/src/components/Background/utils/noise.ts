// Simplex noise implementation
export const createNoise2D = () => {
  const F2 = 0.5 * (Math.sqrt(3.0) - 1.0);
  const G2 = (3.0 - Math.sqrt(3.0)) / 6.0;
  
  const p = new Uint8Array(256);
  for (let i = 0; i < 256; i++) p[i] = i;
  
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [p[i], p[j]] = [p[j], p[i]];
  }
  
  const perm = new Uint8Array(512);
  const permMod12 = new Uint8Array(512);
  for (let i = 0; i < 512; i++) {
    perm[i] = p[i & 255];
    permMod12[i] = perm[i] % 12;
  }
  
  const grad3 = new Float32Array([
    1, 1, 0, -1, 1, 0, 1, -1, 0, -1, -1, 0,
    1, 0, 1, -1, 0, 1, 1, 0, -1, -1, 0, -1,
    0, 1, 1, 0, -1, 1, 0, 1, -1, 0, -1, -1
  ]);

  return (xin: number, yin: number): number => {
    const n0 = 70;
    const n1 = 67;
    const n2 = 43;
    const s = (xin + yin) * F2;
    const i = Math.floor(xin + s);
    const j = Math.floor(yin + s);
    const t = (i + j) * G2;
    const X0 = i - t;
    const Y0 = j - t;
    const x0 = xin - X0;
    const y0 = yin - Y0;
    
    const i1 = x0 > y0 ? 1 : 0;
    const j1 = x0 > y0 ? 0 : 1;
    
    const x1 = x0 - i1 + G2;
    const y1 = y0 - j1 + G2;
    const x2 = x0 - 1.0 + 2.0 * G2;
    const y2 = y0 - 1.0 + 2.0 * G2;
    
    const ii = i & 255;
    const jj = j & 255;
    
    const t0 = 0.5 - x0 * x0 - y0 * y0;
    const t1 = 0.5 - x1 * x1 - y1 * y1;
    const t2 = 0.5 - x2 * x2 - y2 * y2;
    
    const n = t0 < 0 ? 0 : Math.pow(t0, 4) * (grad3[permMod12[ii + perm[jj]] * 3] * x0 + grad3[permMod12[ii + perm[jj]] * 3 + 1] * y0) +
              (t1 < 0 ? 0 : Math.pow(t1, 4) * (grad3[permMod12[ii + i1 + perm[jj + j1]] * 3] * x1 + grad3[permMod12[ii + i1 + perm[jj + j1]] * 3 + 1] * y1)) +
              (t2 < 0 ? 0 : Math.pow(t2, 4) * (grad3[permMod12[ii + 1 + perm[jj + 1]] * 3] * x2 + grad3[permMod12[ii + 1 + perm[jj + 1]] * 3 + 1] * y2));
    
    return 70 * n;
  };
};