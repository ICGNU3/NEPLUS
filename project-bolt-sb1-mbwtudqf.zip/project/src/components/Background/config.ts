export const PARTICLE_CONFIG = {
  count: 100,
  sizeRange: { min: 1, max: 3 },
  speedRange: { min: -0.5, max: 0.5 },
  colors: ['#00ff41', '#39ff14', '#32CD32'],
  connectionDistance: 150,
  pulseSpeed: 0.02,
  mouseRadius: 200,
  mouseForce: 0.1
};