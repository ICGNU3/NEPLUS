export const MATRIX_COLORS = {
  primary: '#00ff41',
  light: '#39ff14',
  dark: '#0D2818',
  black: '#0C1714',
} as const;

export const PARTICLE_CONFIG = {
  count: 100,
  sizeRange: { min: 1, max: 3 },
  speedRange: { min: -0.5, max: 0.5 },
  colors: [MATRIX_COLORS.primary, MATRIX_COLORS.light, '#32CD32'],
  connectionDistance: 150,
  pulseSpeed: 0.02,
  mouseRadius: 200,
  mouseForce: 0.1
} as const;

export const MATRIX_SYMBOLS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%";