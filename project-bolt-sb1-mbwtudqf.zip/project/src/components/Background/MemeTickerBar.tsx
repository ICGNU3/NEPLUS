import React, { useState } from 'react';
import { useTicker } from '../../hooks/useTicker';
import { TickerItem } from './components/TickerItem';
import { LoadingSpinner } from '../common/LoadingSpinner';

export const MemeTickerBar = () => {
  const { data, error, loading } = useTicker();
  const [isHovered, setIsHovered] = useState(false);

  if (loading) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-matrix-dark/90 backdrop-blur-md border-t border-matrix-primary/30 py-3 px-4 text-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-matrix-dark/90 backdrop-blur-md border-t border-matrix-primary/30 py-3 px-4 text-center">
        <span className="text-matrix-primary/80">{error.message}</span>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-matrix-dark/90 backdrop-blur-md border-t border-matrix-primary/30 py-3 px-4 text-center">
        <span className="text-matrix-primary/80">No market data available</span>
      </div>
    );
  }

  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="fixed bottom-0 left-0 right-0 bg-matrix-dark/90 backdrop-blur-md border-t border-matrix-primary/30 overflow-hidden"
    >
      <div 
        className={`flex items-center py-3 ${!isHovered && 'animate-scroll'}`}
        style={{ willChange: 'transform' }}
      >
        {data.map((token) => (
          <TickerItem key={token.id} token={token} />
        ))}
        {/* Duplicate items for seamless scrolling */}
        {data.map((token) => (
          <TickerItem key={`${token.id}-dup`} token={token} />
        ))}
      </div>
    </div>
  );
};