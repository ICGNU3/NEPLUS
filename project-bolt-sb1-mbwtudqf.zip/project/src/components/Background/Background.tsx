import React from 'react';
import { FluidCanvas } from './FluidCanvas';
import { MemeTickerBar } from './MemeTickerBar';
import { usePerformanceMonitor } from '../../hooks/core/usePerformanceMonitor';

export const Background = () => {
  usePerformanceMonitor();

  return (
    <>
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute inset-0 bg-matrix-black opacity-90" />
        <FluidCanvas />
      </div>
      <MemeTickerBar />
    </>
  );
};