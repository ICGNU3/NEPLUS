import { useCallback } from 'react';
import { Particle, MousePosition } from './types';
import { PARTICLE_CONFIG } from './config';

export const useParticleSystem = () => {
  const createParticles = useCallback((width: number, height: number): Particle[] => {
    return Array.from({ length: PARTICLE_CONFIG.count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * (PARTICLE_CONFIG.sizeRange.max - PARTICLE_CONFIG.sizeRange.min) + PARTICLE_CONFIG.sizeRange.min,
      speedX: Math.random() * (PARTICLE_CONFIG.speedRange.max - PARTICLE_CONFIG.speedRange.min) + PARTICLE_CONFIG.speedRange.min,
      speedY: Math.random() * (PARTICLE_CONFIG.speedRange.max - PARTICLE_CONFIG.speedRange.min) + PARTICLE_CONFIG.speedRange.min,
      color: PARTICLE_CONFIG.colors[Math.floor(Math.random() * PARTICLE_CONFIG.colors.length)],
      alpha: Math.random(),
      growing: true
    }));
  }, []);

  const updateParticle = useCallback((particle: Particle, width: number, height: number, mousePos: MousePosition) => {
    // Update position
    particle.x += particle.speedX;
    particle.y += particle.speedY;

    // Mouse interaction
    const dx = mousePos.x - particle.x;
    const dy = mousePos.y - particle.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance < PARTICLE_CONFIG.mouseRadius) {
      const force = (PARTICLE_CONFIG.mouseRadius - distance) / PARTICLE_CONFIG.mouseRadius;
      particle.speedX -= dx * force * PARTICLE_CONFIG.mouseForce;
      particle.speedY -= dy * force * PARTICLE_CONFIG.mouseForce;
    }

    // Bounce off edges
    if (particle.x < 0 || particle.x > width) particle.speedX *= -1;
    if (particle.y < 0 || particle.y > height) particle.speedY *= -1;

    // Pulsing effect
    if (particle.growing) {
      particle.alpha += PARTICLE_CONFIG.pulseSpeed;
      if (particle.alpha >= 1) particle.growing = false;
    } else {
      particle.alpha -= PARTICLE_CONFIG.pulseSpeed;
      if (particle.alpha <= 0.3) particle.growing = true;
    }
  }, []);

  return { createParticles, updateParticle };
};