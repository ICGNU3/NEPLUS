export interface Particle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  color: string;
  alpha: number;
  growing: boolean;
}

export interface MousePosition {
  x: number;
  y: number;
}

export interface BackgroundEffect {
  initialize(width: number, height: number): void;
  draw(ctx: CanvasRenderingContext2D, width: number, height: number): void;
}