import { useCallback } from 'react';
import { useSystemStatus } from '../../../hooks/core/useSystemStatus';
import { CORE_CONFIG } from '../../../effects/core/config';
import { FLUID_CONFIG } from '../../../effects/fluid/config';

export const useOptimizedFluid = () => {
  const { fps, isOptimized } = useSystemStatus();

  const getOptimizedConfig = useCallback(() => {
    if (!isOptimized) return FLUID_CONFIG;

    const performanceRatio = fps / CORE_CONFIG.performance.maxFPS;
    
    return {
      ...FLUID_CONFIG,
      particleCount: {
        ...FLUID_CONFIG.particleCount,
        max: Math.floor(FLUID_CONFIG.particleCount.max * performanceRatio)
      },
      particle: {
        ...FLUID_CONFIG.particle,
        connectionDistance: Math.floor(FLUID_CONFIG.particle.connectionDistance * performanceRatio)
      }
    };
  }, [fps, isOptimized]);

  return { getOptimizedConfig };
};