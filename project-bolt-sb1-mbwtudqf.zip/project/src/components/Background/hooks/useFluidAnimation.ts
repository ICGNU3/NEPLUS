import { useCallback } from 'react';
import { FLUID_CONFIG, BACKGROUND_CONFIG } from '../../../constants/effects';
import { createNoise2D } from '../utils/noise';

interface Point {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  baseRadius: number;
  phase: number;
  color: string;
}

export const useFluidAnimation = () => {
  const initFluid = useCallback((canvas: HTMLCanvasElement) => {
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let points: Point[] = [];
    let mouse = { x: 0, y: 0, active: false };
    let time = 0;
    let animationFrame: number;
    const noise2D = createNoise2D();

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      width = window.innerWidth * dpr;
      height = window.innerHeight * dpr;
      
      canvas.width = width;
      canvas.height = height;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      
      ctx.scale(dpr, dpr);
      points = createPoints();
    };

    const createPoints = () => {
      const points: Point[] = [];
      const area = width * height;
      const count = Math.min(
        Math.max(
          Math.floor(area / FLUID_CONFIG.particleCount.multiplier),
          FLUID_CONFIG.particleCount.min
        ),
        FLUID_CONFIG.particleCount.max
      );
      
      for (let i = 0; i < count; i++) {
        const baseRadius = Math.random() * 
          (FLUID_CONFIG.particle.maxSize - FLUID_CONFIG.particle.minSize) + 
          FLUID_CONFIG.particle.minSize;

        points.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: 0,
          vy: 0,
          radius: baseRadius,
          baseRadius,
          phase: Math.random() * Math.PI * 2,
          color: Math.random() > 0.5 ? 
            FLUID_CONFIG.colors.primary : 
            FLUID_CONFIG.colors.secondary
        });
      }
      
      return points;
    };

    const updatePoint = (point: Point) => {
      // Flow field effect
      if (FLUID_CONFIG.motion.flowField) {
        const noiseX = noise2D(point.x * 0.003, point.y * 0.003 + time * 0.2);
        const noiseY = noise2D(point.x * 0.003 + 40000, point.y * 0.003 + time * 0.2);
        point.vx += noiseX * FLUID_CONFIG.motion.turbulence;
        point.vy += noiseY * FLUID_CONFIG.motion.turbulence;
      }

      // Mouse interaction
      if (mouse.active) {
        const dx = mouse.x - point.x;
        const dy = mouse.y - point.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < FLUID_CONFIG.interaction.radius) {
          const force = (1 - dist / FLUID_CONFIG.interaction.radius) * 
            FLUID_CONFIG.interaction.force;
          point.vx += dx * force;
          point.vy += dy * force;
          point.radius = point.baseRadius * FLUID_CONFIG.interaction.hoverScale;
        } else {
          point.radius = point.baseRadius;
        }
      }

      // Pulsing effect
      point.radius = point.baseRadius * (
        FLUID_CONFIG.particle.pulseRange.min + 
        (Math.sin(point.phase) + 1) * 0.5 * 
        (FLUID_CONFIG.particle.pulseRange.max - FLUID_CONFIG.particle.pulseRange.min)
      );
      point.phase += FLUID_CONFIG.particle.pulseSpeed;

      // Update position with base speed
      point.vx += (Math.random() - 0.5) * FLUID_CONFIG.motion.baseSpeed;
      point.vy += (Math.random() - 0.5) * FLUID_CONFIG.motion.baseSpeed;
      point.x += point.vx;
      point.y += point.vy;
      point.vx *= FLUID_CONFIG.interaction.damping;
      point.vy *= FLUID_CONFIG.interaction.damping;

      // Bounce off edges with energy preservation
      if (point.x < 0) { point.x = 0; point.vx *= -0.8; }
      if (point.x > width) { point.x = width; point.vx *= -0.8; }
      if (point.y < 0) { point.y = 0; point.vy *= -0.8; }
      if (point.y > height) { point.y = height; point.vy *= -0.8; }
    };

    const drawPoint = (point: Point) => {
      const gradient = ctx.createRadialGradient(
        point.x, point.y, 0,
        point.x, point.y, point.radius * 2
      );
      
      gradient.addColorStop(0, point.color);
      gradient.addColorStop(1, FLUID_CONFIG.colors.transparent);
      
      ctx.beginPath();
      ctx.fillStyle = gradient;
      ctx.arc(point.x, point.y, point.radius * 2, 0, Math.PI * 2);
      ctx.fill();
    };

    const drawConnections = () => {
      ctx.beginPath();
      ctx.strokeStyle = FLUID_CONFIG.colors.connection;
      ctx.lineWidth = 1;
      
      points.forEach((point, i) => {
        points.slice(i + 1).forEach(other => {
          const dx = point.x - other.x;
          const dy = point.y - other.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          if (dist < FLUID_CONFIG.particle.connectionDistance) {
            const alpha = (1 - dist / FLUID_CONFIG.particle.connectionDistance) * 
              BACKGROUND_CONFIG.baseOpacity;
            ctx.globalAlpha = alpha;
            ctx.moveTo(point.x, point.y);
            ctx.lineTo(other.x, other.y);
          }
        });
      });
      
      ctx.stroke();
      ctx.globalAlpha = 1;
    };

    const animate = () => {
      // Clear with fade effect
      ctx.fillStyle = `rgba(12, 23, 20, ${BACKGROUND_CONFIG.fadeSpeed})`;
      ctx.fillRect(0, 0, width, height);
      
      // Update and draw
      points.forEach(updatePoint);
      points.forEach(drawPoint);
      drawConnections();
      
      // Update time
      time += 0.001;
      animationFrame = requestAnimationFrame(animate);
    };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      mouse.x = (e.clientX - rect.left) * dpr;
      mouse.y = (e.clientY - rect.top) * dpr;
    };

    const handleMouseEnter = () => {
      mouse.active = true;
    };

    const handleMouseLeave = () => {
      mouse.active = false;
    };

    // Initialize
    resize();
    animate();
    
    // Event listeners
    window.addEventListener('resize', resize);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseenter', handleMouseEnter);
    canvas.addEventListener('mouseleave', handleMouseLeave);

    // Cleanup
    return () => {
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseenter', handleMouseEnter);
      canvas.removeEventListener('mouseleave', handleMouseLeave);
      cancelAnimationFrame(animationFrame);
    };
  }, []);

  return { initFluid };
};