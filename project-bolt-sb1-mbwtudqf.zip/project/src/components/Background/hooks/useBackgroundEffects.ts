import { useCallback } from 'react';
import { MatrixRain, GlowGrid, MatrixGlow, DataStream } from '../effects';

export const useBackgroundEffects = () => {
  const initializeEffects = useCallback(() => ({
    matrixRain: new MatrixRain(),
    glowGrid: new GlowGrid(),
    matrixGlow: new MatrixGlow(),
    dataStream: new DataStream()
  }), []);

  const renderEffects = useCallback((
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    effects: ReturnType<typeof initializeEffects>
  ) => {
    // Layer 1: Matrix glow effect
    effects.matrixGlow.draw(ctx, width, height);
    
    // Layer 2: Data streams
    effects.dataStream.draw(ctx, width, height);
    
    // Layer 3: Glow grid
    effects.glowGrid.draw(ctx, width, height);
    
    // Layer 4: Matrix rain
    effects.matrixRain.draw(ctx, width, height);
  }, []);

  return { initializeEffects, renderEffects };
};