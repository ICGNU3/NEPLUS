import { useRef, useCallback } from 'react';

export const useFrameTime = () => {
  const lastTimeRef = useRef<number>(0);

  const getDeltaTime = useCallback((currentTime: number) => {
    const deltaTime = (currentTime - lastTimeRef.current) / 1000;
    lastTimeRef.current = currentTime;
    return Math.min(deltaTime, 0.1); // Cap at 100ms to prevent huge jumps
  }, []);

  return { getDeltaTime };
};