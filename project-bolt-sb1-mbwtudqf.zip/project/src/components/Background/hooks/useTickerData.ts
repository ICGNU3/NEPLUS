import { useState, useEffect, useCallback } from 'react';
import { getVerifiedMemecoins } from '../../../services/api/coingecko';
import type { Memecoin } from '../../../types/memecoin';

export const useTickerData = () => {
  const [memecoins, setMemecoins] = useState<Memecoin[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      const coins = await getVerifiedMemecoins();
      
      if (!Array.isArray(coins) || coins.length === 0) {
        setError('No active memecoins found');
        return;
      }

      // Ensure we're working with valid numbers
      const activeCoins = coins
        .filter(coin => 
          typeof coin.total_volume === 'number' && 
          !isNaN(coin.total_volume) && 
          coin.total_volume > 500000
        )
        .sort((a, b) => b.total_volume - a.total_volume)
        .slice(0, 15);

      setMemecoins(activeCoins);
      setError(null);
    } catch (err) {
      setError('Failed to load market data');
      console.error('Ticker error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let mounted = true;

    const updateData = async () => {
      if (!mounted) return;
      await fetchData();
    };

    updateData();
    const interval = setInterval(updateData, 30000);

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [fetchData]);

  return { memecoins, error, loading };
};