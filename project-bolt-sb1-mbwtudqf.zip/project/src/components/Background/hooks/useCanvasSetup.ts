import { useCallback } from 'react';
import { MousePosition } from '../types';

export const useCanvasSetup = () => {
  const setupCanvas = useCallback((
    canvas: HTMLCanvasElement,
    onMouseMove: (pos: MousePosition) => void
  ) => {
    const dpr = window.devicePixelRatio;
    const ctx = canvas.getContext('2d', { alpha: true });
    
    if (!ctx) return null;

    const resize = () => {
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.scale(dpr, dpr);
    };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      onMouseMove({
        x: (e.clientX - rect.left) * dpr,
        y: (e.clientY - rect.top) * dpr
      });
    };

    resize();
    window.addEventListener('resize', resize);
    canvas.addEventListener('mousemove', handleMouseMove);

    return {
      ctx,
      cleanup: () => {
        window.removeEventListener('resize', resize);
        canvas.removeEventListener('mousemove', handleMouseMove);
      }
    };
  }, []);

  return { setupCanvas };
};