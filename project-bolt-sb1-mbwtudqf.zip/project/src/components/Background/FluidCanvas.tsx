import React, { useEffect, useRef } from 'react';
import { useFluidAnimation } from './hooks/useFluidAnimation';
import { BACKGROUND_CONFIG } from '../../constants/effects';

export const FluidCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { initFluid } = useFluidAnimation();

  useEffect(() => {
    if (!canvasRef.current) return;
    return initFluid(canvasRef.current);
  }, [initFluid]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full"
      style={{ 
        filter: `blur(${BACKGROUND_CONFIG.blurAmount})`,
        opacity: BACKGROUND_CONFIG.baseOpacity 
      }}
    />
  );
};