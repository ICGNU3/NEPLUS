import React from 'react';
import { TimelineEvent } from './TimelineEvent';
import { Book, GraduationCap, Bitcoin, Palette, Users, Film, MessageSquare, Rocket } from 'lucide-react';
import { storyEvents } from './StoryContent';

const iconMap = {
  "Early Years": Book,
  "Education": GraduationCap,
  "2008": Bitcoin,
  "2018": Palette,
  "2020-2021": Film,
  "2021-2022": Users,
  "2022-2023": MessageSquare, // Changed from Microphone to MessageSquare
  "Present": Rocket
};

export const StoryTimeline = () => {
  return (
    <div className="max-w-4xl mx-auto px-4">
      <div className="space-y-12">
        {storyEvents.map((event, index) => (
          <TimelineEvent
            key={index}
            icon={iconMap[event.period]}
            year={event.period}
            title={event.title}
            content={event.content}
            isLast={index === storyEvents.length - 1}
          />
        ))}
      </div>
    </div>
  );
};