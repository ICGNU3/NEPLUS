export const storyEvents = [
  {
    period: "Early Years",
    title: "The Beginning",
    content: "In elementary school, I excelled academically, reading at three, but my curiosity and an ADHD label moved me from gifted programs to behavioral schools. Later, hustling for basics led me through foster care, juvenile detention, and prison. Through it all, I found inspiration in science fiction, music, and self-help, fueling a determination to bridge the gap between imagination and opportunity."
  },
  {
    period: "Education",
    title: "The Wake-Up Call",
    content: "I earned my GED while in juvenile detention. Scoring perfectly on the reading and comprehension sections should have felt like a triumph, but it didn't. The woman administering the results looked at me with a mix of astonishment and disappointment that stayed with me. Her expression told me everything I needed to know: I had been under-living my potential. That realization lingered, but it wasn't until I was given the chance to go to university that I had my true wake-up call. For the first time, I understood what could happen when someone believed in me and gave me the opportunity to channel that potential."
  },
  {
    period: "2008",
    title: "Bitcoin Discovery",
    content: "In November 2008, I read the Bitcoin whitepaper. It was like opening a door to an entirely new way of thinking. Bitcoin was a vision of how value could exist independently of the institutions that had always controlled it."
  },
  {
    period: "2018",
    title: "NFT Vision",
    content: "At Consensys's Ethereal Summit, I saw the future again—this time in what would later be called NFTs. For the first time, I saw how technology could intersect with creativity in ways that didn't just innovate but empowered."
  },
  {
    period: "2020-2021",
    title: "Industry Breakthrough",
    content: "After a series of pivotal Clubhouse conversations beginning on December 6, 2020, my journey accelerated. I helped shape Web3 culture and education, advocating for the value of community in the crypto space. I joined a company that launched the first licensed TV NFT for American Gods in 2021, demonstrating how storytelling could find new life through blockchain technology. This experience showed me the importance of maintaining creative control and independence in pursuing innovation."
  },
  {
    period: "2021-2022",
    title: "Creative Collaborations",
    content: "My path crossed with cultural icons like Quincy Jones and Jesse Dylan. Working with these visionaries gave me an insider's view of creativity at the highest level while teaching me the importance of self-direction."
  },
  {
    period: "2022-2023",
    title: "Speaking & Growth",
    content: "I shared insights at conferences like NFTLA and NFT NYC. These stages allowed me to connect with creators, technologists, and communities eager to push the boundaries of what NFTs and blockchain could achieve."
  },
  {
    period: "Present",
    title: "IZZO Launch",
    content: "IZZO is a reflection of everything I've learned. It's a foundation for autonomy, a way to bridge art, technology, and community while maintaining independence. This chapter is about taking everything I've learned and using it to create something lasting."
  }
];