import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface TimelineEventProps {
  icon: LucideIcon;
  year: string;
  title: string;
  content: string;
  isLast?: boolean;
}

export const TimelineEvent = ({ icon: Icon, year, title, content, isLast }: TimelineEventProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      className="relative flex items-start"
    >
      <div className="absolute left-8 top-0 h-full w-px bg-blue-400 bg-opacity-20">
        {!isLast && <div className="absolute w-px h-full bg-gradient-to-b from-blue-400 to-transparent" />}
      </div>
      
      <div className="relative flex-shrink-0 w-16 h-16 flex items-center justify-center">
        <div className="absolute w-16 h-16 bg-blue-400 bg-opacity-10 rounded-full" />
        <Icon className="w-8 h-8 text-blue-400" />
      </div>

      <div className="ml-8">
        <div className="text-sm text-blue-400 font-semibold mb-1">{year}</div>
        <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
        <p className="text-gray-300 leading-relaxed">{content}</p>
      </div>
    </motion.div>
  );
};