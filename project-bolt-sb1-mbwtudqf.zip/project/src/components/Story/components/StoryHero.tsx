import React from 'react';
import { motion } from 'framer-motion';

export const StoryHero = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 mb-16">
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-5xl font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400"
      >
        The NEPLUS Story
      </motion.h2>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.2 }}
        className="text-xl text-gray-300 leading-relaxed text-center max-w-2xl mx-auto"
      >
        A journey of transformation, innovation, and cultural renaissance. Every step has led to 
        creating something meaningful with NEPLUS.
      </motion.p>
    </div>
  );
};