import React from 'react';
import { StoryHero } from './components/StoryHero';
import { StoryTimeline } from './components/StoryTimeline';

const StorySection = () => {
  return (
    <div className="min-h-screen bg-gray-900 py-24">
      <StoryHero />
      <StoryTimeline />
    </div>
  );
};

export default StorySection;