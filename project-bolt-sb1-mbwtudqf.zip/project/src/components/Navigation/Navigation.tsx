import React from 'react';
import { MenuButton } from './components/MenuButton';
import { NavMenu } from './components/NavMenu';
import { useMenu } from './hooks/useMenu';

export const Navigation = () => {
  const { isOpen, toggleMenu, menuItems } = useMenu();

  return (
    <nav className="fixed top-0 right-0 z-50 p-4">
      <MenuButton isOpen={isOpen} onClick={toggleMenu} />
      <NavMenu isOpen={isOpen} items={menuItems} />
    </nav>
  );
};