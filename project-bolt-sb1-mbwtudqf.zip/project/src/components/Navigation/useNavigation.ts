import { useState } from 'react';
import { MENU_ITEMS } from './constants';

export const useNavigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  return {
    isOpen,
    setIsOpen,
    menuItems: MENU_ITEMS,
  };
};