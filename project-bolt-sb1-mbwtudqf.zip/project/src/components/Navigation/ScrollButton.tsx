import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ScrollButtonProps {
  icon: LucideIcon;
  label: string;
  targetId?: string;
  href?: string;
  isExpanded: boolean;
}

export const ScrollButton = ({ 
  icon: Icon, 
  label, 
  targetId, 
  href,
  isExpanded 
}: ScrollButtonProps) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (href) {
      navigate(href);
    } else if (targetId) {
      const element = document.getElementById(targetId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={handleClick}
      className="flex items-center w-full px-3 py-2 rounded-lg transition-colors
                 hover:bg-matrix-primary/10 group focus:outline-none 
                 focus:ring-2 focus:ring-matrix-primary/50"
      aria-label={`Navigate to ${label}`}
    >
      <Icon className="w-5 h-5 text-matrix-primary" />
      <motion.span 
        className="ml-3 text-matrix-primary whitespace-nowrap overflow-hidden"
        animate={{ 
          width: isExpanded ? 'auto' : 0,
          opacity: isExpanded ? 1 : 0,
          marginLeft: isExpanded ? '0.75rem' : 0,
          transition: { duration: 0.2 }
        }}
      >
        {label}
      </motion.span>
    </motion.button>
  );
};