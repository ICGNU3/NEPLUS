import { useState } from 'react';
import { MENU_ITEMS } from '../constants';

export const useMenu = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);

  return {
    isOpen,
    toggleMenu,
    menuItems: MENU_ITEMS,
  };
};