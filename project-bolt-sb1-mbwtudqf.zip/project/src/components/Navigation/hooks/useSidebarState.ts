import { useState, useCallback } from 'react';

export const useSidebarState = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = useCallback(() => {
    setIsHovered(true);
  }, []);

  const handleMouseLeave = useCallback(() => {
    setIsHovered(false);
  }, []);

  const toggleSidebar = useCallback(() => {
    setIsExpanded(prev => !prev);
  }, []);

  return {
    isExpanded: isExpanded || isHovered,
    handleMouseEnter,
    handleMouseLeave,
    toggleSidebar
  };
};