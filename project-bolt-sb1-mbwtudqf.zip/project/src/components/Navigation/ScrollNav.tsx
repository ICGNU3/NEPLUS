import React from 'react';
import { ScrollButton } from './ScrollButton';
import { NAV_ITEMS } from '../../constants/navigation';
import { useSidebarState } from './hooks/useSidebarState';
import { ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

export const ScrollNav = () => {
  const { isExpanded, handleMouseEnter, handleMouseLeave } = useSidebarState();

  return (
    <motion.nav 
      role="navigation"
      aria-label="Main navigation"
      className="fixed left-0 top-1/2 -translate-y-1/2 z-50"
      initial={false}
      animate={{ 
        width: isExpanded ? 'auto' : '3rem',
        transition: { duration: 0.2 }
      }}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <motion.div 
        className="bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/10 
                  rounded-lg p-2 shadow-lg hover:border-matrix-primary/30 transition-colors"
        animate={{ 
          width: isExpanded ? 'auto' : '3rem',
          transition: { duration: 0.2 }
        }}
      >
        <div className="space-y-2">
          {NAV_ITEMS.map((item) => (
            <ScrollButton
              key={item.label}
              icon={item.icon}
              label={item.label}
              targetId={item.targetId}
              href={item.href}
              isExpanded={isExpanded}
            />
          ))}
        </div>
      </motion.div>
      
      <motion.div
        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2
                   w-6 h-6 bg-gray-900/50 backdrop-blur-sm border border-matrix-primary/10 
                   rounded-full flex items-center justify-center cursor-pointer
                   hover:border-matrix-primary/30 transition-colors"
        animate={{ 
          rotate: isExpanded ? 180 : 0,
          transition: { duration: 0.2 }
        }}
      >
        <ChevronRight className="w-4 h-4 text-matrix-primary" />
      </motion.div>
    </motion.nav>
  );
};