import React from 'react';
import { Menu, X } from 'lucide-react';
import { useNavigation } from './useNavigation';
import { NavMenuItem } from './NavMenuItem';

const Navigation = () => {
  const { isOpen, setIsOpen, menuItems } = useNavigation();

  return (
    <nav className="fixed top-0 right-0 z-50 p-4">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"
        aria-label={isOpen ? 'Close menu' : 'Open menu'}
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {isOpen && (
        <div className="absolute top-16 right-4 bg-gray-800 rounded-lg p-4 w-48 backdrop-blur-lg bg-opacity-90">
          {menuItems.map((item, index) => (
            <NavMenuItem key={index} {...item} />
          ))}
        </div>
      )}
    </nav>
  );
};

export default Navigation;