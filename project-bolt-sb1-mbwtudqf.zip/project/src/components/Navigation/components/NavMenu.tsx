import React from 'react';
import { NavMenuItem } from './NavMenuItem';
import type { MenuItem } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface NavMenuProps {
  isOpen: boolean;
  items: MenuItem[];
}

export const NavMenu = ({ isOpen, items }: NavMenuProps) => (
  <AnimatePresence>
    {isOpen && (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        className="absolute top-16 right-4 bg-gray-800 rounded-lg p-4 w-48 backdrop-blur-lg bg-opacity-90"
      >
        {items.map((item, index) => (
          <NavMenuItem key={index} {...item} />
        ))}
      </motion.div>
    )}
  </AnimatePresence>
);