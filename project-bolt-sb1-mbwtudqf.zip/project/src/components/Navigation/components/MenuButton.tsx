import React from 'react';
import { Menu, X } from 'lucide-react';

interface MenuButtonProps {
  isOpen: boolean;
  onClick: () => void;
}

export const MenuButton = ({ isOpen, onClick }: MenuButtonProps) => (
  <button
    onClick={onClick}
    className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"
    aria-label={isOpen ? 'Close menu' : 'Open menu'}
  >
    {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
  </button>
);