import React from 'react';
import type { MenuItem } from '../types';
import { motion } from 'framer-motion';

export const NavMenuItem = ({ icon: Icon, label, href }: MenuItem) => (
  <motion.a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    whileHover={{ x: 5 }}
    className="w-full flex items-center space-x-2 p-2 hover:bg-gray-700 rounded-lg transition-colors mb-2"
  >
    <Icon className="w-6 h-6" />
    <span>{label}</span>
  </motion.a>
);