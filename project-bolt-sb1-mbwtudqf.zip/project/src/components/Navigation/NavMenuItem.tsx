import React from 'react';
import type { MenuItem } from './types';

export const NavMenuItem = ({ icon: Icon, label, href }: MenuItem) => (
  <a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    className="w-full flex items-center space-x-2 p-2 hover:bg-gray-700 rounded-lg transition-colors mb-2"
  >
    <Icon className="w-6 h-6" />
    <span>{label}</span>
  </a>
);