import React from 'react';
import { motion } from 'framer-motion';

const navItems = [
  { label: 'Home', targetId: 'hero' },
  { label: 'Vision', targetId: 'vision' },
  { label: 'Token', targetId: 'token' },
  { label: 'Roadmap', targetId: 'roadmap' },
  { label: 'Get Involved', targetId: 'get-involved' },
];

export const TopNav = () => {
  const scrollToSection = (targetId: string) => {
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-900/80 backdrop-blur-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-center h-16 space-x-8">
          {navItems.map((item) => (
            <motion.button
              key={item.targetId}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => scrollToSection(item.targetId)}
              className="text-gray-300 hover:text-white transition-colors font-medium"
            >
              {item.label}
            </motion.button>
          ))}
        </div>
      </div>
    </nav>
  );
};