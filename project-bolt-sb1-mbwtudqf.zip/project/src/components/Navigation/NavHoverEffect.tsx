import React from 'react';
import { motion } from 'framer-motion';

interface NavHoverEffectProps {
  children: React.ReactNode;
}

export const NavHoverEffect = ({ children }: NavHoverEffectProps) => {
  return (
    <motion.div
      whileHover={{ 
        scale: 1.05,
        textShadow: "0 0 8px rgb(0, 255, 65)"
      }}
      className="relative"
    >
      {children}
      <motion.div
        className="absolute inset-0 bg-matrix-primary/10 rounded-lg -z-10"
        initial={false}
        whileHover={{ scale: 1.2, opacity: 0.8 }}
      />
    </motion.div>
  );
};