import { Clock, Globe, MessageCircle, Newspaper, FileText } from 'lucide-react';
import type { MenuItem } from './types';

export const MENU_ITEMS: MenuItem[] = [
  { 
    icon: Clock,
    label: 'Office Hours', 
    href: 'https://calendar.neplus.xyz' 
  },
  { 
    icon: Globe,
    label: 'Resources', 
    href: 'https://resources.neplus.xyz' 
  },
  { 
    icon: MessageCircle,
    label: 'Support Network', 
    href: 'https://t.me/neplusofficial' 
  },
  { 
    icon: Newspaper,
    label: 'Newsletter', 
    href: 'https://www.linkedin.com/newsletters/digital-renaissance-7017934085100552192/' 
  },
  {
    icon: FileText,
    label: 'Disclaimer',
    href: '/disclaimer'
  }
];