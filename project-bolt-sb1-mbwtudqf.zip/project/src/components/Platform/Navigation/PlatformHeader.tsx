import React from 'react';
import { Bell, Settings } from 'lucide-react';
import { UserMenu } from '../../Auth/UserMenu';

export const PlatformHeader = () => {
  return (
    <header className="fixed top-0 right-0 left-64 h-16 bg-gray-800/50 backdrop-blur-sm border-b border-gray-700/50 z-40">
      <div className="flex items-center justify-between h-full px-6">
        <h1 className="text-[#39ff14] text-xl font-bold">NEPLUS Studio</h1>
        <div className="flex items-center space-x-4">
          <button className="p-2 hover:bg-gray-700/50 rounded-lg">
            <Bell className="w-5 h-5 text-gray-300" />
          </button>
          <button className="p-2 hover:bg-gray-700/50 rounded-lg">
            <Settings className="w-5 h-5 text-gray-300" />
          </button>
          <UserMenu />
        </div>
      </div>
    </header>
  );
};