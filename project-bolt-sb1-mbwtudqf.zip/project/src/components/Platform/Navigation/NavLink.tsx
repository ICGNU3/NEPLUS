import React from 'react';
import { LucideIcon } from 'lucide-react';

interface NavLinkProps {
  icon: LucideIcon;
  label: string;
  href: string;
}

export const NavLink = ({ icon: Icon, label, href }: NavLinkProps) => {
  const isActive = window.location.pathname === href;
  
  return (
    <a
      href={href}
      className={`flex items-center space-x-3 px-4 py-2.5 rounded-lg transition-all duration-300 group
        ${isActive 
          ? 'bg-[#39ff14]/10 text-[#39ff14]' 
          : 'text-gray-300 hover:bg-gray-700/50 hover:text-[#39ff14]'}`}
    >
      <Icon className={`w-5 h-5 ${isActive ? 'drop-shadow-[0_0_8px_#39ff14]' : ''}`} />
      <span className="font-medium">{label}</span>
    </a>
  );
};