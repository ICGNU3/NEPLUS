import React from 'react';
import { Home, Palette, Music, Film, Brain, Users, Rocket } from 'lucide-react';
import { NavLink } from './NavLink';

export const PlatformSidebar = () => {
  return (
    <aside className="fixed top-0 left-0 h-screen w-64 bg-gray-800/30 backdrop-blur-sm border-r border-gray-700/50">
      <div className="p-6">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-[#39ff14] drop-shadow-[0_0_8px_#39ff14]">NEPLUS</h2>
        </div>
        <nav className="space-y-1">
          <NavLink icon={Home} label="Dashboard" href="/platform" />
          <NavLink icon={Palette} label="Art Studio" href="/platform/art" />
          <NavLink icon={Music} label="Music Lab" href="/platform/music" />
          <NavLink icon={Film} label="Film Studio" href="/platform/film" />
          <NavLink icon={Brain} label="Purpose AI" href="/platform/purpose" />
          <NavLink icon={Users} label="Community" href="/platform/community" />
          <NavLink icon={Rocket} label="Learn" href="/platform/learn" />
        </nav>
      </div>
    </aside>
  );
};