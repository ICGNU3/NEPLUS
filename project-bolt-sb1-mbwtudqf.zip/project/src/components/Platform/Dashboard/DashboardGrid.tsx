import React from 'react';
import { motion } from 'framer-motion';
import { Palette, Music, Film, Brain, Users, Rocket } from 'lucide-react';

const tools = [
  {
    icon: Palette,
    title: "Creative Studio",
    description: "Create AI-powered artwork and visual pieces",
    href: "/platform/create"
  },
  {
    icon: Music,
    title: "Cultural Hub",
    description: "Collaborate on cultural projects",
    href: "/platform/culture"
  },
  {
    icon: Film,
    title: "Media Studio",
    description: "Create and edit digital content",
    href: "/platform/media"
  },
  {
    icon: Brain,
    title: "Innovation Lab",
    description: "Discover your creative path",
    href: "/platform/innovate"
  },
  {
    icon: Users,
    title: "Network",
    description: "Connect with fellow innovators",
    href: "/platform/network"
  },
  {
    icon: Rocket,
    title: "Resources",
    description: "Access guides and tools",
    href: "/platform/resources"
  }
];

export const DashboardGrid = () => {
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {tools.map(({ icon: Icon, title, description, href }) => (
        <motion.a
          key={href}
          href={href}
          whileHover={{ y: -5 }}
          className="p-6 bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700/50 
                   hover:border-[#39ff14]/30 transition-all duration-300"
        >
          <div className="bg-[#39ff14]/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <Icon className="w-6 h-6 text-[#39ff14]" />
          </div>
          <h3 className="text-xl font-semibold mb-2 text-white">{title}</h3>
          <p className="text-gray-300">{description}</p>
        </motion.a>
      ))}
    </div>
  );
};