import React from 'react';
import { PlatformSidebar } from './Navigation/PlatformSidebar';
import { PlatformHeader } from './Navigation/PlatformHeader';
import { ErrorBoundary } from '../common/ErrorBoundary';

export const PlatformLayout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="min-h-screen bg-gray-900">
      <PlatformHeader />
      <PlatformSidebar />
      <main className="pl-64 pt-16">
        <ErrorBoundary>
          <div className="p-6">{children}</div>
        </ErrorBoundary>
      </main>
    </div>
  );
};