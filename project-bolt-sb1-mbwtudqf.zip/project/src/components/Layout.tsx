import React from 'react';
import { ScrollNav } from './Navigation/ScrollNav';
import { Footer } from './Footer/Footer';
import { BackToTop } from './common/BackToTop';
import { ScrollProgress } from './common/ScrollProgress';
import { NeplusLogo } from './common/Logo/NeplusLogo';

export const Layout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="min-h-screen bg-transparent">
      <div className="fixed inset-0 bg-gradient-to-b from-matrix-black/90 to-matrix-dark/90 -z-10" />
      <ScrollProgress />
      
      {/* Header area */}
      <div className="fixed top-0 left-0 right-0 h-16 z-50 px-6 flex items-center justify-between">
        <NeplusLogo />
        <a 
          href="https://pump.fun/coin/HQkpcnBeiTjYc6hk3P6q4DvdQFnh7muuBxR3Uhoupump"
          target="_blank"
          rel="noopener noreferrer"
          className="text-matrix-primary hover:text-matrix-light transition-colors 
                   font-mono text-sm focus:outline-none focus:ring-2 
                   focus:ring-matrix-primary/50 rounded px-2 py-1"
        >
          CA: HQkpcnBeiTjYc6hk3P6q4DvdQFnh7muuBxR3Uhoupump
        </a>
      </div>

      {/* Main content */}
      <div className="relative z-10 pt-16">
        <ScrollNav />
        <main className="ml-24">
          {children}
        </main>
      </div>

      <Footer />
      <BackToTop />
    </div>
  );
};