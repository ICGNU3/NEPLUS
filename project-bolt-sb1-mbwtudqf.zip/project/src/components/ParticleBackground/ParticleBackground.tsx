import React from 'react';
import { useLazyParticles } from './useLazyParticles';
import { ParticleCanvas } from './ParticleCanvas';

export const ParticleBackground = () => {
  const [ref, shouldRender] = useLazyParticles();

  return (
    <div ref={ref} className="fixed inset-0 pointer-events-none z-0">
      {shouldRender && <ParticleCanvas />}
    </div>
  );
};