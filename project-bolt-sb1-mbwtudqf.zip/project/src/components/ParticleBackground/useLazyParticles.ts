import { useEffect, useState } from 'react';
import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';

export const useLazyParticles = () => {
  const [shouldRender, setShouldRender] = useState(false);
  const [ref, isVisible] = useIntersectionObserver({
    threshold: 0,
    rootMargin: '100px'
  });

  useEffect(() => {
    if (isVisible) {
      setShouldRender(true);
    }
  }, [isVisible]);

  return [ref, shouldRender];
};