import { ParticleBackground } from './ParticleBackground';
export { ParticleBackground };
export default ParticleBackground;