export const PARTICLE_CONFIG = {
  colors: ['#60A5FA', '#A78BFA', '#34D399', '#F472B6'],
  count: 75,
  connectionDistance: 175,
  opacity: 0.4,
  speedRange: 1.5,
  sizeRange: { min: 1, max: 3.5 },
  pulseSpeed: 0.02,
  pulseRange: { min: 0.8, max: 1.2 }
} as const;