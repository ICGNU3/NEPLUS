import React, { useEffect, useRef } from 'react';
import { useParticleSystem } from './useParticleSystem';
import { PARTICLE_CONFIG } from './config';
import type { Particle } from './types';

export const ParticleCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { createParticles, connectParticles, updateParticle } = useParticleSystem();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let particles: Particle[] = [];
    let animationFrameId: number;
    let isActive = true;

    const animate = () => {
      if (!isActive) return;
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach(particle => {
        updateParticle(particle, canvas.width, canvas.height);
        
        ctx.beginPath();
        ctx.arc(
          particle.x, 
          particle.y, 
          particle.currentSize || particle.size, 
          0, 
          Math.PI * 2
        );
        ctx.fillStyle = particle.color;
        ctx.fill();
      });

      connectParticles(ctx, particles);
      animationFrameId = requestAnimationFrame(animate);
    };

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.scale(dpr, dpr);
      particles = createParticles(window.innerWidth, window.innerHeight);
    };

    resize();
    animate();

    window.addEventListener('resize', resize);
    
    return () => {
      isActive = false;
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [createParticles, connectParticles, updateParticle]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="w-full h-full"
      style={{ opacity: PARTICLE_CONFIG.opacity }}
    />
  );
};