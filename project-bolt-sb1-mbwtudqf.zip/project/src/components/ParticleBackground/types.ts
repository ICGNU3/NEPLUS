export interface Particle {
  x: number;
  y: number;
  size: number;
  currentSize?: number;
  speedX: number;
  speedY: number;
  color: string;
  pulse: number;
  pulseSpeed: number;
}