import { useCallback } from 'react';
import { Particle } from './types';
import { PARTICLE_CONFIG } from './config';
import { throttle } from './utils/throttle';

export const useParticleSystem = () => {
  const createParticles = useCallback((width: number, height: number): Particle[] => {
    const particles: Particle[] = [];
    for (let i = 0; i < PARTICLE_CONFIG.count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * (PARTICLE_CONFIG.sizeRange.max - PARTICLE_CONFIG.sizeRange.min) + PARTICLE_CONFIG.sizeRange.min,
        speedX: (Math.random() - 0.5) * PARTICLE_CONFIG.speedRange,
        speedY: (Math.random() - 0.5) * PARTICLE_CONFIG.speedRange,
        color: PARTICLE_CONFIG.colors[Math.floor(Math.random() * PARTICLE_CONFIG.colors.length)],
        pulse: 0,
        pulseSpeed: PARTICLE_CONFIG.pulseSpeed * (Math.random() * 2 - 1)
      });
    }
    return particles;
  }, []);

  const updateParticle = useCallback((particle: Particle, width: number, height: number) => {
    // Update position
    particle.x += particle.speedX;
    particle.y += particle.speedY;

    // Bounce off edges
    if (particle.x < 0 || particle.x > width) {
      particle.speedX *= -1;
    }
    if (particle.y < 0 || particle.y > height) {
      particle.speedY *= -1;
    }

    // Update pulse
    particle.pulse += particle.pulseSpeed;
    particle.currentSize = particle.size * 
      (PARTICLE_CONFIG.pulseRange.min + 
       (Math.sin(particle.pulse) + 1) * 
       (PARTICLE_CONFIG.pulseRange.max - PARTICLE_CONFIG.pulseRange.min) / 2);
  }, []);

  const connectParticles = useCallback(
    throttle((ctx: CanvasRenderingContext2D, particles: Particle[]) => {
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < PARTICLE_CONFIG.connectionDistance) {
            const opacity = 0.15 * (1 - distance / PARTICLE_CONFIG.connectionDistance);
            const gradient = ctx.createLinearGradient(
              particles[i].x, particles[i].y,
              particles[j].x, particles[j].y
            );
            gradient.addColorStop(0, particles[i].color.replace('1)', `${opacity})`));
            gradient.addColorStop(1, particles[j].color.replace('1)', `${opacity})`));
            
            ctx.beginPath();
            ctx.strokeStyle = gradient;
            ctx.lineWidth = 1;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }
    }, 16),
    []
  );

  return {
    createParticles,
    connectParticles,
    updateParticle
  };
};