import React from 'react';
import { Section } from '../common/Section';
import { SectionHeader } from '../common/SectionHeader';
import { DisclaimerContent } from './DisclaimerContent';

const DisclaimerSection = () => {
  return (
    <Section id="disclaimer" className="bg-gray-900">
      <SectionHeader
        title="NEPLUS Disclaimer"
        subtitle="Please read this disclaimer carefully before using our platform or engaging with $NEPLUS."
      />
      <DisclaimerContent />
    </Section>
  );
};

export default DisclaimerSection;