import React from 'react';
import { motion } from 'framer-motion';

interface DisclaimerSectionProps {
  title: string;
  content: string;
  bulletPoints?: string[];
}

export const DisclaimerSection = ({ title, content, bulletPoints }: DisclaimerSectionProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-gray-800 bg-opacity-50 rounded-xl p-6"
    >
      <h3 className="text-xl font-semibold mb-4 text-white">{title}</h3>
      <p className="text-gray-300 mb-4">{content}</p>
      {bulletPoints && bulletPoints.length > 0 && (
        <ul className="list-disc list-inside space-y-2">
          {bulletPoints.map((point, index) => (
            <li key={index} className="text-gray-300">{point}</li>
          ))}
        </ul>
      )}
    </motion.div>
  );
};