export const disclaimerSections = [
  {
    title: "1. General Information",
    content: "NEPLUS is a decentralized platform designed to empower cultural innovation and creative projects. All interactions, including those involving $NEPLUS, are for informational and community-building purposes only.",
    bulletPoints: [
      "NEPLUS does not collect personal data",
      "No privacy policy is maintained",
      "No guarantees of specific value or utility for $NEPLUS or platform-related activities"
    ]
  },
  {
    title: "2. Not Financial Advice",
    content: "Nothing on this platform constitutes professional and/or financial advice. All content is for informational purposes only.",
    bulletPoints: [
      "Users should not interpret any platform content as professional guidance",
      "Consult qualified advisors before making any decisions",
      "$NEPLUS is a utility token, not an investment product"
    ]
  },
  {
    title: "3. Risk Disclosure",
    content: "Participation in decentralized platforms and digital tokens involves inherent risks.",
    bulletPoints: [
      "Digital tokens are subject to high market volatility",
      "Technical vulnerabilities may exist in decentralized systems",
      "Regulatory changes may impact platform functionality",
      "Users participate at their own risk"
    ]
  },
  {
    title: "4. Cultural Patronage",
    content: "$NEPLUS represents cultural patronage rights and community participation, not financial instruments.",
    bulletPoints: [
      "Tokens provide governance and participation rights",
      "No expectation of profit should be assumed",
      "Value derives from cultural contribution and community engagement"
    ]
  },
  {
    title: "5. Intellectual Property",
    content: "All platform content and branding are protected intellectual property.",
    bulletPoints: [
      "Users retain rights to their original content",
      "Platform features and tools are proprietary",
      "Community contributions are governed by open-source principles"
    ]
  }
];