import React from 'react';
import { DisclaimerSection } from './components/DisclaimerSection';
import { disclaimerSections } from './data/disclaimerData';

export const DisclaimerContent = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {disclaimerSections.map((section, index) => (
        <DisclaimerSection
          key={index}
          title={section.title}
          content={section.content}
          bulletPoints={section.bulletPoints}
        />
      ))}
    </div>
  );
};