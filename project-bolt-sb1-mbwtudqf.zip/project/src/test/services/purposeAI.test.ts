import { describe, it, expect, beforeEach } from 'vitest';
import { PurposeAI } from '../../services/purposeAI';

describe('PurposeAI', () => {
  let purposeAI: PurposeAI;
  
  beforeEach(() => {
    purposeAI = new PurposeAI();
  });

  it('generates purpose map with all required sections', async () => {
    const birthData = {
      date: '1990-01-01',
      time: '12:00',
      location: 'New York, USA'
    };

    const preferences = {
      interests: ['technology', 'art'],
      passions: ['creating', 'teaching'],
      challenges: ['time management']
    };

    const values = {
      personal: ['growth', 'creativity'],
      professional: ['innovation', 'leadership'],
      social: ['community', 'impact']
    };

    const goals = {
      shortTerm: ['learn new skills'],
      longTerm: ['build successful platform']
    };

    const purposeMap = await purposeAI.generatePurposeMap(
      birthData,
      preferences,
      values,
      goals
    );

    expect(purposeMap.lifePath).toBeDefined();
    expect(purposeMap.energyType).toBeDefined();
    expect(purposeMap.giftAndShadow).toBeDefined();
    expect(purposeMap.creativeFlow).toBeDefined();
    expect(purposeMap.lifeAlignment).toBeDefined();
  });
});