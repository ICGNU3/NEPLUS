import { describe, it, expect } from 'vitest';
import { render, screen } from '../utils/test-utils';
import Hero from '../../components/Hero';

describe('Hero', () => {
  it('renders hero section with main heading', () => {
    render(<Hero />);
    expect(screen.getByText(/Join/i)).toBeInTheDocument();
    expect(screen.getByText(/IZZO/i)).toBeInTheDocument();
  });

  it('renders call-to-action buttons', () => {
    render(<Hero />);
    expect(screen.getByText(/Get Started/i)).toBeInTheDocument();
    expect(screen.getByText(/Learn More/i)).toBeInTheDocument();
  });
});