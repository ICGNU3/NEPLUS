import { describe, it, expect } from 'vitest';
import { render, screen } from '../utils/test-utils';
import TokenSection from '../../components/Token/TokenSection';

describe('TokenSection', () => {
  it('renders token section with title', () => {
    render(<TokenSection />);
    expect(screen.getByText(/IZZO Token/i)).toBeInTheDocument();
  });

  it('displays token distribution', () => {
    render(<TokenSection />);
    expect(screen.getByText(/Token Distribution/i)).toBeInTheDocument();
  });
});