import { Home, Globe, Rocket, Users, FileText } from 'lucide-react';

export const NAV_ITEMS = [
  { icon: Home, label: 'Home', targetId: 'hero' },
  { icon: Globe, label: 'Vision', targetId: 'vision' },
  { icon: Rocket, label: 'Roadmap', targetId: 'roadmap' },
  { icon: Users, label: 'Get Involved', targetId: 'get-involved' },
  { icon: FileText, label: 'Greenpaper', href: '/greenpaper' }
] as const;