export const COLORS = {
  matrix: {
    primary: '#00ff41',
    light: '#39ff14',
    dark: '#0D2818',
    black: '#0C1714'
  },
  glass: {
    light: 'rgba(255, 255, 255, 0.1)',
    dark: 'rgba(0, 0, 0, 0.8)'
  }
} as const;

export const GRADIENTS = {
  matrix: 'bg-gradient-to-r from-matrix-primary to-matrix-light',
  glass: 'bg-gradient-to-b from-glass-light to-transparent'
} as const;