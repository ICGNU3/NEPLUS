export const TRANSITIONS = {
  DEFAULT: { duration: 0.3 },
  SLOW: { duration: 0.5 },
  FAST: { duration: 0.2 }
} as const;

export const BREAKPOINTS = {
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  '2xl': '1536px'
} as const;

export const Z_INDEX = {
  background: -1,
  base: 0,
  overlay: 10,
  modal: 20,
  toast: 30,
  loader: 40
} as const;