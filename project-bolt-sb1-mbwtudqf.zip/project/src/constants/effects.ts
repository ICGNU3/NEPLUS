export const FLUID_CONFIG = {
  particleCount: {
    multiplier: 20000,
    min: 75,
    max: 250
  },
  colors: {
    primary: 'rgba(0, 255, 65, 0.4)',
    secondary: 'rgba(57, 255, 20, 0.3)',
    transparent: 'rgba(0, 255, 65, 0)',
    connection: 'rgba(0, 255, 65, 0.08)'
  },
  interaction: {
    radius: 250,
    force: 0.03,
    damping: 0.92,
    hoverScale: 1.2
  },
  particle: {
    minSize: 1,
    maxSize: 4,
    connectionDistance: 150,
    pulseSpeed: 0.01,
    pulseRange: { min: 0.8, max: 1.2 }
  },
  motion: {
    baseSpeed: 0.2,
    turbulence: 0.5,
    flowField: true
  }
} as const;

export const GLOW_CONFIG = {
  intensity: 0.4,
  radius: 20,
  color: '#00ff41',
  blur: 15
} as const;

export const BACKGROUND_CONFIG = {
  fadeSpeed: 0.15,
  blurAmount: '1.5px',
  baseOpacity: 0.92,
  noiseIntensity: 0.03
} as const;