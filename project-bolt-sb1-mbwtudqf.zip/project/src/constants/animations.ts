export const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.5 }
};

export const hoverScale = {
  whileHover: { 
    scale: 1.05,
    boxShadow: "0 0 20px rgba(0, 255, 65, 0.3)"
  },
  whileTap: { scale: 0.95 },
  transition: { duration: 0.2 }
};

export const matrixReveal = {
  initial: { opacity: 0, filter: "blur(10px)" },
  animate: { opacity: 1, filter: "blur(0px)" },
  transition: { duration: 0.8 }
};

export const glowPulse = {
  animate: {
    boxShadow: [
      "0 0 10px rgba(0, 255, 65, 0.2)",
      "0 0 20px rgba(0, 255, 65, 0.4)",
      "0 0 10px rgba(0, 255, 65, 0.2)"
    ]
  },
  transition: {
    duration: 2,
    repeat: Infinity,
    ease: "linear"
  }
};