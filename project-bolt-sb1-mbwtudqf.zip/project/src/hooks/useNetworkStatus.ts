import { useState, useEffect } from 'react';

export const useNetworkStatus = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [speed, setSpeed] = useState<'slow' | 'medium' | 'fast'>('medium');

  useEffect(() => {
    const updateStatus = () => setIsOnline(navigator.onLine);
    
    const checkSpeed = async () => {
      const start = performance.now();
      try {
        await fetch('/ping');
        const duration = performance.now() - start;
        
        setSpeed(
          duration < 100 ? 'fast' :
          duration < 300 ? 'medium' : 'slow'
        );
      } catch {
        setSpeed('slow');
      }
    };

    window.addEventListener('online', updateStatus);
    window.addEventListener('offline', updateStatus);
    
    const interval = setInterval(checkSpeed, 30000);

    return () => {
      window.removeEventListener('online', updateStatus);
      window.removeEventListener('offline', updateStatus);
      clearInterval(interval);
    };
  }, []);

  return { isOnline, speed };
};