import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface ProtocolProgress {
  completedSteps: string[];
  timeSpent: number;
  lastAttempt: string | null;
  successRate: number;
}

export const useProtocolProgress = (protocolId: string, userId: string) => {
  const [progress, setProgress] = useState<ProtocolProgress>({
    completedSteps: [],
    timeSpent: 0,
    lastAttempt: null,
    successRate: 0
  });

  useEffect(() => {
    const fetchProgress = async () => {
      const { data, error } = await supabase
        .from('protocol_progress')
        .select('*')
        .eq('protocol_id', protocolId)
        .eq('user_id', userId)
        .single();

      if (!error && data) {
        setProgress(data);
      }
    };

    fetchProgress();
  }, [protocolId, userId]);

  const updateProgress = async (updates: Partial<ProtocolProgress>) => {
    const { error } = await supabase
      .from('protocol_progress')
      .upsert({
        protocol_id: protocolId,
        user_id: userId,
        ...progress,
        ...updates,
        updated_at: new Date().toISOString()
      });

    if (!error) {
      setProgress(prev => ({ ...prev, ...updates }));
    }
  };

  return { progress, updateProgress };
};