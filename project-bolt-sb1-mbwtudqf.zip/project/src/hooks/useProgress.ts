import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface Progress {
  completedProtocols: string[];
  totalTime: number;
  successRate: number;
}

export const useProgress = (userId: string) => {
  const [progress, setProgress] = useState<Progress>({
    completedProtocols: [],
    totalTime: 0,
    successRate: 0
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProgress = async () => {
      try {
        const { data, error } = await supabase
          .from('user_progress')
          .select('*')
          .eq('user_id', userId)
          .single();

        if (error) throw error;

        if (data) {
          setProgress(data);
        }
      } catch (error) {
        console.error('Error fetching progress:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProgress();
  }, [userId]);

  const updateProgress = async (protocolId: string, timeSpent: number, success: boolean) => {
    try {
      const newProgress = {
        ...progress,
        completedProtocols: [...progress.completedProtocols, protocolId],
        totalTime: progress.totalTime + timeSpent,
        successRate: (progress.successRate * progress.completedProtocols.length + (success ? 1 : 0)) / 
                    (progress.completedProtocols.length + 1)
      };

      const { error } = await supabase
        .from('user_progress')
        .upsert({ user_id: userId, ...newProgress });

      if (error) throw error;

      setProgress(newProgress);
    } catch (error) {
      console.error('Error updating progress:', error);
    }
  };

  return { progress, loading, updateProgress };
};