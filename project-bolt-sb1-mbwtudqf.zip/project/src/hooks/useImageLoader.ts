import { useState, useEffect } from 'react';

export const useImageLoader = (src: string) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const image = new Image();
    
    image.onload = () => {
      setIsLoaded(true);
    };
    
    image.onerror = (e) => {
      setError(e instanceof Error ? e : new Error('Failed to load image'));
    };

    image.src = src;

    return () => {
      image.onload = null;
      image.onerror = null;
    };
  }, [src]);

  return { isLoaded, error };
};