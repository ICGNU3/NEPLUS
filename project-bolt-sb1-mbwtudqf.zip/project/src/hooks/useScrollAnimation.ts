import { useEffect, useState } from 'react';
import { useIntersectionObserver } from './useIntersectionObserver';
import { withTransition } from '../utils/animations';

export const useScrollAnimation = (threshold = 0.1) => {
  const [ref, isVisible] = useIntersectionObserver({ threshold });
  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    if (isVisible && !hasAnimated) {
      setHasAnimated(true);
    }
  }, [isVisible, hasAnimated]);

  const animation = withTransition({
    opacity: hasAnimated ? 1 : 0,
    y: hasAnimated ? 0 : 20
  });

  return [ref, animation] as const;
};