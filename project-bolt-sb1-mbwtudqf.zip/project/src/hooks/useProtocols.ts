import { useState, useEffect } from 'react';
import { Terminal, Cpu, Network, Code, Shield, Zap } from 'lucide-react';
import type { Protocol } from '../types/protocols';
import { supabase } from '../lib/supabase';

export const useProtocols = () => {
  const [protocols, setProtocols] = useState<Protocol[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProtocols = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Not authenticated');

        const { data, error } = await supabase
          .from('protocols')
          .select('*')
          .order('difficulty');

        if (error) throw error;

        // Map icons to protocols
        const iconMap = { Terminal, Cpu, Network, Code, Shield, Zap };
        
        const protocolsWithIcons = (data || []).map(protocol => ({
          ...protocol,
          icon: iconMap[protocol.icon_name as keyof typeof iconMap] || Terminal
        }));

        setProtocols(protocolsWithIcons);
      } catch (err) {
        console.error('Error fetching protocols:', err);
        setError('Failed to load protocols');
      } finally {
        setLoading(false);
      }
    };

    fetchProtocols();
  }, []);

  return { protocols, loading, error };
};