import { useEffect } from 'react';
import { NAV_ITEMS } from '../constants/navigation';

export const useKeyboardNavigation = () => {
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.altKey && e.key >= '1' && e.key <= '5') {
        const index = parseInt(e.key) - 1;
        const item = NAV_ITEMS[index];
        
        if (item) {
          const element = document.getElementById(item.targetId);
          element?.scrollIntoView({ behavior: 'smooth' });
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);
};