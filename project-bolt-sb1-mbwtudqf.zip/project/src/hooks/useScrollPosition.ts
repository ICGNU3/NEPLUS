import { useState, useEffect } from 'react';

export const useScrollPosition = (threshold = 0) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const checkScroll = () => {
      setIsVisible(window.pageYOffset > threshold);
    };

    window.addEventListener('scroll', checkScroll);
    return () => window.removeEventListener('scroll', checkScroll);
  }, [threshold]);

  return { isVisible };
};