import { useState, useCallback } from 'react';
import { useAnimationFrame } from './useAnimationFrame';

interface MotionConfig {
  stiffness?: number;
  damping?: number;
  precision?: number;
}

export const useMotionValue = (
  initialValue: number,
  config: MotionConfig = {}
) => {
  const [value, setValue] = useState(initialValue);
  const [target, setTarget] = useState(initialValue);
  
  const { 
    stiffness = 100,
    damping = 10,
    precision = 0.001
  } = config;

  const animate = useCallback((deltaTime: number) => {
    const delta = target - value;
    const velocity = delta * stiffness;
    const newValue = value + (velocity * deltaTime) / 1000;
    
    if (Math.abs(delta) < precision) {
      setValue(target);
      return;
    }
    
    setValue(newValue);
  }, [value, target, stiffness, precision]);

  useAnimationFrame(animate);

  return [value, setTarget] as const;
};