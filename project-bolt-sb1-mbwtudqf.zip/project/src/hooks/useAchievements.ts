import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface Achievement {
  id: string;
  title: string;
  description: string;
  points: number;
  unlocked: boolean;
}

export const useAchievements = (userId: string) => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAchievements = async () => {
      try {
        const { data, error } = await supabase
          .from('achievements')
          .select('*')
          .eq('user_id', userId);

        if (error) throw error;
        setAchievements(data || []);
      } catch (error) {
        console.error('Error fetching achievements:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAchievements();
  }, [userId]);

  const unlockAchievement = async (achievementId: string) => {
    try {
      const { error } = await supabase
        .from('user_achievements')
        .insert([{ user_id: userId, achievement_id: achievementId }]);

      if (error) throw error;

      setAchievements(prev => 
        prev.map(a => 
          a.id === achievementId ? { ...a, unlocked: true } : a
        )
      );
    } catch (error) {
      console.error('Error unlocking achievement:', error);
    }
  };

  return { achievements, loading, unlockAchievement };
};