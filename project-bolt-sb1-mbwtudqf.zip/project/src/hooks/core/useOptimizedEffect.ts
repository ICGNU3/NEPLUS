import { useEffect, DependencyList } from 'react';
import { useSystemStatus } from './useSystemStatus';
import { CORE_CONFIG } from '../../effects/core/config';

export const useOptimizedEffect = (
  effect: () => void | (() => void),
  deps?: DependencyList
) => {
  const { isOptimized } = useSystemStatus();

  useEffect(() => {
    if (!isOptimized) {
      const cleanup = effect();
      return cleanup;
    }

    const timeoutId = setTimeout(effect, CORE_CONFIG.interaction.hoverDelay);
    return () => clearTimeout(timeoutId);
  }, [isOptimized, ...(deps || [])]);
};