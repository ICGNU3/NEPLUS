import { create } from 'zustand';
import { CORE_CONFIG } from '../../effects/core/config';

interface SystemState {
  fps: number;
  memory: number;
  loadTime: number;
  isOptimized: boolean;
  updateMetrics: (metrics: Partial<SystemState>) => void;
  optimizePerformance: () => void;
}

export const useSystemStatus = create<SystemState>((set) => ({
  fps: 60,
  memory: 0,
  loadTime: 0,
  isOptimized: false,
  updateMetrics: (metrics) => set((state) => ({ ...state, ...metrics })),
  optimizePerformance: () => {
    const maxFPS = CORE_CONFIG.performance.maxFPS;
    set((state) => ({
      ...state,
      isOptimized: true,
      fps: Math.min(state.fps, maxFPS)
    }));
  }
}));