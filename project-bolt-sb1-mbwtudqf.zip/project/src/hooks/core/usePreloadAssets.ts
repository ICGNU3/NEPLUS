import { useEffect } from 'react';

const CRITICAL_ASSETS = [
  '/fonts/JetBrainsMono-Regular.woff2',
  '/fonts/JetBrainsMono-Bold.woff2'
];

export const usePreloadAssets = () => {
  useEffect(() => {
    const preloadLink = document.createElement('link');
    preloadLink.rel = 'preload';
    preloadLink.as = 'font';
    preloadLink.type = 'font/woff2';
    preloadLink.crossOrigin = 'anonymous';

    CRITICAL_ASSETS.forEach(asset => {
      const link = preloadLink.cloneNode() as HTMLLinkElement;
      link.href = asset;
      document.head.appendChild(link);
    });
  }, []);
};