import { useEffect } from 'react';
import { useSystemStatus } from './useSystemStatus';
import { CORE_CONFIG } from '../../effects/core/config';

export const usePerformanceMonitor = () => {
  const { updateMetrics, optimizePerformance } = useSystemStatus();

  useEffect(() => {
    let frames = 0;
    let lastTime = performance.now();
    let rafId: number;

    const measure = () => {
      const now = performance.now();
      frames++;

      if (now >= lastTime + 1000) {
        const fps = Math.round((frames * 1000) / (now - lastTime));
        const memory = (performance as any).memory?.usedJSHeapSize / 1048576 || 0;

        updateMetrics({ fps, memory });

        if (fps < CORE_CONFIG.performance.maxFPS * 0.8) {
          optimizePerformance();
        }

        frames = 0;
        lastTime = now;
      }

      rafId = requestAnimationFrame(measure);
    };

    measure();

    return () => cancelAnimationFrame(rafId);
  }, [updateMetrics, optimizePerformance]);
};