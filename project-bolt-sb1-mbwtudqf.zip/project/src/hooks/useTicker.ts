import { useState, useEffect, useCallback } from 'react';
import { fetchTickerData } from '../services/api/ticker';
import type { TickerState } from '../types/ticker';

export const useTicker = (refreshInterval = 30000) => {
  const [state, setState] = useState<TickerState>({
    data: [],
    error: null,
    loading: true
  });

  const updateData = useCallback(async () => {
    try {
      const { data, error } = await fetchTickerData();
      setState(prev => ({
        ...prev,
        data,
        error,
        loading: false
      }));
    } catch (err) {
      setState(prev => ({
        ...prev,
        error: {
          message: 'Failed to update ticker data',
          code: 'TICKER_UPDATE_ERROR'
        },
        loading: false
      }));
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    let intervalId: number;

    const init = async () => {
      if (!mounted) return;
      await updateData();
      intervalId = window.setInterval(updateData, refreshInterval);
    };

    init();

    return () => {
      mounted = false;
      if (intervalId) clearInterval(intervalId);
    };
  }, [updateData, refreshInterval]);

  return state;
};