import { useState } from 'react';
import { subscribeToNewsletter } from '../services/newsletter';

interface NewsletterState {
  isOpen: boolean;
  loading: boolean;
  error: string | null;
}

export const useNewsletter = () => {
  const [state, setState] = useState<NewsletterState>({
    isOpen: false,
    loading: false,
    error: null
  });

  const showSubscribeModal = () => setState(prev => ({ ...prev, isOpen: true }));
  const hideSubscribeModal = () => setState(prev => ({ ...prev, isOpen: false, error: null }));

  const subscribe = async (email: string) => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      const result = await subscribeToNewsletter(email);
      
      if (!result.success) {
        setState(prev => ({ 
          ...prev, 
          loading: false, 
          error: result.error || 'Subscription failed' 
        }));
        return false;
      }

      setState(prev => ({ ...prev, loading: false, isOpen: false }));
      return true;
    } catch (error) {
      setState(prev => ({ 
        ...prev, 
        loading: false, 
        error: 'Failed to establish neural link. Please try again.' 
      }));
      return false;
    }
  };

  return {
    ...state,
    showSubscribeModal,
    hideSubscribeModal,
    subscribe
  };
};