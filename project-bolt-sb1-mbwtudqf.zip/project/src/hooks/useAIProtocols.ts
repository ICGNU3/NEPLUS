import { useState } from 'react';
import { generateProtocol } from '../services/ai/protocolGenerator';
import type { Protocol } from '../types/protocols';

export const useAIProtocols = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateCustomProtocol = async (
    difficulty: 'basic' | 'intermediate' | 'advanced',
    userProgress: any
  ): Promise<Protocol | null> => {
    try {
      setLoading(true);
      setError(null);
      const protocol = await generateProtocol(difficulty, userProgress);
      return protocol;
    } catch (err) {
      setError('Failed to generate protocol');
      return null;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    generateCustomProtocol
  };
};