import { useState, useMemo } from 'react';
import type { Protocol } from '../types/protocols';

export const useProtocolFilters = (protocols: Protocol[]) => {
  const [search, setSearch] = useState('');
  const [difficulty, setDifficulty] = useState('');
  const [showCompleted, setShowCompleted] = useState(true);

  const filteredProtocols = useMemo(() => {
    return protocols.filter(protocol => {
      // Search filter
      const matchesSearch = search === '' || 
        protocol.title.toLowerCase().includes(search.toLowerCase()) ||
        protocol.description.toLowerCase().includes(search.toLowerCase());

      // Difficulty filter
      const matchesDifficulty = difficulty === '' || 
        protocol.difficulty === difficulty;

      // Completed filter
      const matchesCompleted = showCompleted || !protocol.completed;

      return matchesSearch && matchesDifficulty && matchesCompleted;
    });
  }, [protocols, search, difficulty, showCompleted]);

  return {
    search,
    setSearch,
    difficulty,
    setDifficulty,
    showCompleted,
    setShowCompleted,
    filteredProtocols
  };
};