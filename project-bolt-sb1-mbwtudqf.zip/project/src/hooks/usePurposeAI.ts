import { useState } from 'react';
import { PurposeAI } from '../services/purposeAI';
import { BirthData, UserPreferences, UserValues, LifeGoals, PurposeMap } from '../types/purpose';

export const usePurposeAI = () => {
  const [loading, setLoading] = useState(false);
  const [purposeMap, setPurposeMap] = useState<PurposeMap | null>(null);
  const purposeAI = new PurposeAI();

  const generateInsights = async (
    birthData: BirthData,
    preferences: UserPreferences,
    values: UserValues,
    goals: LifeGoals
  ) => {
    try {
      setLoading(true);
      const map = await purposeAI.generatePurposeMap(birthData, preferences, values, goals);
      setPurposeMap(map);
      return map;
    } catch (error) {
      console.error('Error generating purpose insights:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    purposeMap,
    generateInsights,
    purposeAI
  };
};