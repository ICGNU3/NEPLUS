export interface NewsletterResponse {
  success: boolean;
  data?: {
    message: string;
  };
  error?: string;
}

export interface NewsletterSubscriber {
  id: string;
  email: string;
  subscribed_at: string;
  status: 'active' | 'unsubscribed';
}

export interface NewsletterState {
  isOpen: boolean;
  loading: boolean;
  error: string | null;
}

export interface NewsletterStore extends NewsletterState {
  showSubscribeModal: () => void;
  hideSubscribeModal: () => void;
  subscribe: (email: string) => Promise<boolean>;
}