export interface BirthData {
  date: string;
  time: string;
  location: string;
}

export interface UserPreferences {
  interests: string[];
  passions: string[];
  challenges: string[];
}

export interface UserValues {
  personal: string[];
  professional: string[];
  social: string[];
}

export interface LifeGoals {
  shortTerm: string[];
  longTerm: string[];
}

export interface PurposeInsight {
  system: 'numerology' | 'humanDesign' | 'geneKeys' | 'mayanDreamspell' | 'ikigai';
  category: string;
  insight: string;
  suggestion: string;
}

export interface PurposeMap {
  lifePath: PurposeInsight[];
  energyType: PurposeInsight[];
  giftAndShadow: PurposeInsight[];
  creativeFlow: PurposeInsight[];
  lifeAlignment: PurposeInsight[];
}