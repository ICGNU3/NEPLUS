import { LucideIcon } from 'lucide-react';

export interface SupportCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
}