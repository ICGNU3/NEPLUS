export interface TickerData {
  id: string;
  symbol: string;
  name: string;
  price: number;
  priceChange: number;
  volume: number;
  marketCap: number;
}

export interface TickerError {
  message: string;
  code: string;
}

export interface TickerState {
  data: TickerData[];
  error: TickerError | null;
  loading: boolean;
}