import { LucideIcon } from 'lucide-react';

export interface Protocol {
  id: string;
  title: string;
  description: string;
  difficulty: 'basic' | 'intermediate' | 'advanced';
  unlocked: boolean;
  completed: boolean;
  icon: LucideIcon;
  steps?: string[];
  requirements?: string[];
}

export interface ProtocolProgress {
  completedSteps: string[];
  timeSpent: number;
  lastAttempt: string | null;
  successRate: number;
}