export const CORE_CONFIG = {
  performance: {
    maxFPS: 60,
    batchSize: 100,
    throttleDelay: 16,
    renderDistance: 1000
  },
  interaction: {
    hoverDelay: 100,
    clickDelay: 50,
    scrollThrottle: 100,
    resizeDebounce: 250
  },
  animation: {
    duration: 300,
    easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
    staggerDelay: 50
  }
} as const;