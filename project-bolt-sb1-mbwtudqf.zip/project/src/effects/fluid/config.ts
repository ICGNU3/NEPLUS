import { COLORS } from '../../constants/theme';

export const FLUID_CONFIG = {
  particleCount: {
    multiplier: 20000,
    min: 75,
    max: 250
  },
  colors: {
    primary: `${COLORS.matrix.primary}66`, // 40% opacity
    secondary: `${COLORS.matrix.light}4D`, // 30% opacity
    transparent: `${COLORS.matrix.primary}00`,
    connection: `${COLORS.matrix.primary}14` // 8% opacity
  },
  interaction: {
    radius: 250,
    force: 0.03,
    damping: 0.92,
    hoverScale: 1.2
  },
  particle: {
    minSize: 1,
    maxSize: 4,
    connectionDistance: 150,
    pulseSpeed: 0.01,
    pulseRange: { min: 0.8, max: 1.2 }
  },
  motion: {
    baseSpeed: 0.2,
    turbulence: 0.5,
    flowField: true
  }
} as const;