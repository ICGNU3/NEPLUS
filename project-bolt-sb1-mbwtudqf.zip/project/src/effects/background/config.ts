export const BACKGROUND_CONFIG = {
  fadeSpeed: 0.15,
  blurAmount: '1.5px',
  baseOpacity: 0.92,
  noiseIntensity: 0.03
} as const;