import { COLORS } from '../../constants/theme';

export const GLOW_CONFIG = {
  intensity: 0.4,
  radius: 20,
  color: COLORS.matrix.primary,
  blur: 15
} as const;