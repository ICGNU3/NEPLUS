/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        matrix: {
          primary: '#00ff41',
          light: '#39ff14',
          dark: '#0D2818',
          black: '#0C1714'
        }
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'monospace']
      },
      animation: {
        'matrix-fade': 'matrix-fade 2s ease-out forwards'
      },
      keyframes: {
        'matrix-fade': {
          '0%': { opacity: 0, transform: 'translateY(20px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' }
        }
      }
    }
  },
  plugins: []
};