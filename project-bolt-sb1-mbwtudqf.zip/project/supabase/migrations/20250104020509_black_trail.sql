/*
  # Protocol System Implementation

  1. New Tables
    - `protocols` - Stores protocol definitions and requirements
    - `protocol_progress` - Tracks user progress through protocols
    - `protocol_steps` - Defines steps for each protocol
    - `protocol_requirements` - Defines prerequisites for protocols

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Protect protocol data integrity

  3. Changes
    - Add protocol tracking system
    - Add progress tracking
    - Add completion tracking
*/

-- Protocols table
CREATE TABLE IF NOT EXISTS public.protocols (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  difficulty text NOT NULL CHECK (difficulty IN ('basic', 'intermediate', 'advanced')),
  icon_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Protocol steps table
CREATE TABLE IF NOT EXISTS public.protocol_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol_id uuid REFERENCES protocols(id) ON DELETE CASCADE,
  step_number integer NOT NULL,
  instruction text NOT NULL,
  expected_output text,
  created_at timestamptz DEFAULT now()
);

-- Protocol requirements table
CREATE TABLE IF NOT EXISTS public.protocol_requirements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol_id uuid REFERENCES protocols(id) ON DELETE CASCADE,
  required_protocol_id uuid REFERENCES protocols(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT no_self_requirement CHECK (protocol_id != required_protocol_id)
);

-- Protocol progress table
CREATE TABLE IF NOT EXISTS public.protocol_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  protocol_id uuid REFERENCES protocols(id) ON DELETE CASCADE,
  completed_steps text[] DEFAULT '{}',
  time_spent integer DEFAULT 0,
  last_attempt timestamptz,
  success_rate numeric DEFAULT 0,
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id, protocol_id)
);

-- Enable RLS
ALTER TABLE protocols ENABLE ROW LEVEL SECURITY;
ALTER TABLE protocol_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE protocol_requirements ENABLE ROW LEVEL SECURITY;
ALTER TABLE protocol_progress ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view protocols"
  ON protocols FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can view protocol steps"
  ON protocol_steps FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can view protocol requirements"
  ON protocol_requirements FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can view own progress"
  ON protocol_progress FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own progress"
  ON protocol_progress FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own progress"
  ON protocol_progress FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert initial protocols
INSERT INTO protocols (title, description, difficulty, icon_name) VALUES
('System Access Override', 'Learn to bypass standard system access protocols and gain elevated permissions.', 'basic', 'Terminal'),
('Neural Network Manipulation', 'Master the art of neural pathway modification and consciousness expansion.', 'intermediate', 'Brain'),
('Reality Distortion Field', 'Create and maintain stable reality distortion fields for local environment manipulation.', 'advanced', 'Zap'),
('Quantum Encryption Breaking', 'Advanced techniques for breaking quantum-encrypted security systems.', 'advanced', 'Lock'),
('Time Dilation Protocol', 'Manipulate local time fields to achieve temporal advantage.', 'advanced', 'Clock'),
('Matrix Code Injection', 'Insert custom code directly into the base reality matrix.', 'intermediate', 'Code');

-- Insert protocol steps
INSERT INTO protocol_steps (protocol_id, step_number, instruction, expected_output)
SELECT 
  id,
  1,
  'Initialize system access sequence with command: access --protocol-id [ID] --level root',
  'Access sequence initialized. Awaiting authentication...'
FROM protocols
WHERE title = 'System Access Override';

-- Insert protocol requirements
INSERT INTO protocol_requirements (protocol_id, required_protocol_id)
SELECT 
  a.id,
  b.id
FROM protocols a
CROSS JOIN protocols b
WHERE a.title = 'Neural Network Manipulation'
AND b.title = 'System Access Override';