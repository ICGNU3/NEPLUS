/*
  # Create purpose maps table

  1. New Tables
    - `purpose_maps`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `birth_data` (jsonb)
      - `preferences` (jsonb)
      - `values` (jsonb)
      - `goals` (jsonb)
      - `insights` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS public.purpose_maps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  birth_data jsonb NOT NULL,
  preferences jsonb NOT NULL,
  values jsonb NOT NULL,
  goals jsonb NOT NULL,
  insights jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.purpose_maps ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own purpose maps"
  ON public.purpose_maps
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own purpose maps"
  ON public.purpose_maps
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create trigger for updated_at
CREATE TRIGGER purpose_maps_updated_at
  BEFORE UPDATE ON public.purpose_maps
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();